/**
 * 
 */
package com.sterlite.access.bng.bo;

/**
 * @author ravi.divvela
 *
 */
public class OnDemandAccessData {
	
	private String pppoeOuterUnitNo; 
	private Integer ppoeInnerUnitStart;
	private Integer ppoeInnerUnitStop;
	/**
	 * @return the pppoeOuterUnitNo
	 */
	public String getPppoeOuterUnitNo() {
		return pppoeOuterUnitNo;
	}
	/**
	 * @param pppoeOuterUnitNo the pppoeOuterUnitNo to set
	 */
	public void setPppoeOuterUnitNo(String pppoeOuterUnitNo) {
		this.pppoeOuterUnitNo = pppoeOuterUnitNo;
	}
	/**
	 * @return the ppoeInnerUnitStart
	 */
	public Integer getPpoeInnerUnitStart() {
		return ppoeInnerUnitStart;
	}
	/**
	 * @param ppoeInnerUnitStart the ppoeInnerUnitStart to set
	 */
	public void setPpoeInnerUnitStart(Integer ppoeInnerUnitStart) {
		this.ppoeInnerUnitStart = ppoeInnerUnitStart;
	}
	/**
	 * @return the ppoeInnerUnitStop
	 */
	public Integer getPpoeInnerUnitStop() {
		return ppoeInnerUnitStop;
	}
	/**
	 * @param ppoeInnerUnitStop the ppoeInnerUnitStop to set
	 */
	public void setPpoeInnerUnitStop(Integer ppoeInnerUnitStop) {
		this.ppoeInnerUnitStop = ppoeInnerUnitStop;
	}
//
	public OnDemandAccessData(String pppoeOuterUnitNo, Integer ppoeInnerUnitStart, Integer ppoeInnerUnitStop) {
		this.pppoeOuterUnitNo = pppoeOuterUnitNo;
		this.ppoeInnerUnitStart = ppoeInnerUnitStart;
		this.ppoeInnerUnitStop = ppoeInnerUnitStop;
	}
	public OnDemandAccessData() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OnDemandAccessData [pppoeOuterUnitNo=" + pppoeOuterUnitNo + ", ppoeInnerUnitStart=" + ppoeInnerUnitStart
				+ ", ppoeInnerUnitStop=" + ppoeInnerUnitStop + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pppoeOuterUnitNo == null) ? 0 : pppoeOuterUnitNo.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OnDemandAccessData other = (OnDemandAccessData) obj;
		if (pppoeOuterUnitNo == null) {
			if (other.pppoeOuterUnitNo != null)
				return false;
		} else if (!pppoeOuterUnitNo.equals(other.pppoeOuterUnitNo))
			return false;
		return true;
	}

	
	//
	/*public static Comparator<OnDemandAccessData> FruitNameComparator = new Comparator<OnDemandAccessData>() {

		public int compare(OnDemandAccessData fruit1, OnDemandAccessData fruit2) {

			String fruitName1 = fruit1.getPppoeOuterUnitNo();
			String fruitName2 = fruit2.getPppoeOuterUnitNo();

			//ascending order
			return fruitName1.compareTo(fruitName2);

			//descending order
			//return fruitName2.compareTo(fruitName1);
		}
	};
	

	@Override
	public int compareTo(OnDemandAccessData o) {
		return 0;
	}*/
	
	
}
