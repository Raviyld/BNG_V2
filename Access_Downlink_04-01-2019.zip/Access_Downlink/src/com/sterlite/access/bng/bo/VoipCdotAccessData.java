/**
 * 
 */
package com.sterlite.access.bng.bo;

/**
 * @author ravi.divvela
 *
 */
public class VoipCdotAccessData {
	private String voipOuterVlanNo;
	private String voipInnerVlan;
	private Integer voipUnitNo;
	private String voipIpAddress;
	private String voipBdNo;
	/**
	 * @return the voipOuterVlanNo
	 */
	public String getVoipOuterVlanNo() {
		return voipOuterVlanNo;
	}
	/**
	 * @param voipOuterVlanNo the voipOuterVlanNo to set
	 */
	public void setVoipOuterVlanNo(String voipOuterVlanNo) {
		this.voipOuterVlanNo = voipOuterVlanNo;
	}
	/**
	 * @return the voipInnerVlan
	 */
	public String getVoipInnerVlan() {
		return voipInnerVlan;
	}
	/**
	 * @param voipInnerVlan the voipInnerVlan to set
	 */
	public void setVoipInnerVlan(String voipInnerVlan) {
		this.voipInnerVlan = voipInnerVlan;
	}
	/**
	 * @return the voipUnitNo
	 */
	public Integer getVoipUnitNo() {
		return voipUnitNo;
	}
	/**
	 * @param voipUnitNo the voipUnitNo to set
	 */
	public void setVoipUnitNo(Integer voipUnitNo) {
		this.voipUnitNo = voipUnitNo;
	}
	/**
	 * @return the voipIpAddress
	 */
	public String getVoipIpAddress() {
		return voipIpAddress;
	}
	/**
	 * @param voipIpAddress the voipIpAddress to set
	 */
	public void setVoipIpAddress(String voipIpAddress) {
		this.voipIpAddress = voipIpAddress;
	}
	/**
	 * @return the voipBdNo
	 */
	public String getVoipBdNo() {
		return voipBdNo;
	}
	/**
	 * @param voipBdNo the voipBdNo to set
	 */
	public void setVoipBdNo(String voipBdNo) {
		this.voipBdNo = voipBdNo;
	}
	/**
	 * @param voipOuterVlanNo
	 * @param voipInnerVlan
	 * @param voipUnitNo
	 * @param voipIpAddress
	 * @param voipBdNo
	 */
	public VoipCdotAccessData(String voipOuterVlanNo, String voipInnerVlan, Integer voipUnitNo, String voipIpAddress,
			String voipBdNo) {
		this.voipOuterVlanNo = voipOuterVlanNo;
		this.voipInnerVlan = voipInnerVlan;
		this.voipUnitNo = voipUnitNo;
		this.voipIpAddress = voipIpAddress;
		this.voipBdNo = voipBdNo;
	}
	/**
	 * 
	 */
	public VoipCdotAccessData() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "VoipCdotAccessData [voipOuterVlanNo=" + voipOuterVlanNo + ", voipInnerVlan=" + voipInnerVlan
				+ ", voipUnitNo=" + voipUnitNo + ", voipIpAddress=" + voipIpAddress + ", voipBdNo=" + voipBdNo + "]";
	}
	
}
