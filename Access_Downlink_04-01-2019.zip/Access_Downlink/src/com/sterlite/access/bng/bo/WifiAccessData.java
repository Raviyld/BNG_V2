/**
 * 
 */
package com.sterlite.access.bng.bo;

/**
 * @author ravi.divvela
 *
 */
public class WifiAccessData {
	private String wifiVlanNo;
	private String wifiInterfaceIp;
	private String wifiContextName;
	/**
	 * @return the wifiVlanNo
	 */
	public String getWifiVlanNo() {
		return wifiVlanNo;
	}
	/**
	 * @param wifiVlanNo the wifiVlanNo to set
	 */
	public void setWifiVlanNo(String wifiVlanNo) {
		this.wifiVlanNo = wifiVlanNo;
	}
	/**
	 * @return the wifiInterfaceIp
	 */
	public String getWifiInterfaceIp() {
		return wifiInterfaceIp;
	}
	/**
	 * @param wifiInterfaceIp the wifiInterfaceIp to set
	 */
	public void setWifiInterfaceIp(String wifiInterfaceIp) {
		this.wifiInterfaceIp = wifiInterfaceIp;
	}
	/**
	 * @param wifiVlanNo
	 * @param wifiInterfaceIp
	 */
	public WifiAccessData(String wifiVlanNo, String wifiInterfaceIp) {
		this.wifiVlanNo = wifiVlanNo;
		this.wifiInterfaceIp = wifiInterfaceIp;
	}
	/**
	 * @return the wifiContextName
	 */
	public String getWifiContextName() {
		return wifiContextName;
	}
	/**
	 * @param wifiContextName the wifiContextName to set
	 */
	public void setWifiContextName(String wifiContextName) {
		this.wifiContextName = wifiContextName;
	}
	/**
	 * 
	 */
	public WifiAccessData() {
	}
	/**
	 * @param wifiVlanNo
	 * @param wifiInterfaceIp
	 * @param wifiContextName
	 */
	public WifiAccessData(String wifiVlanNo, String wifiInterfaceIp, String wifiContextName) {
		super();
		this.wifiVlanNo = wifiVlanNo;
		this.wifiInterfaceIp = wifiInterfaceIp;
		this.wifiContextName = wifiContextName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WifiAccessData [wifiVlanNo=" + wifiVlanNo + ", wifiInterfaceIp=" + wifiInterfaceIp + "]";
	}
	
}
