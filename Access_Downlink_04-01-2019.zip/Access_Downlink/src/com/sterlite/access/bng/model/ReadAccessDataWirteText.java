/**
 * 
 */
package com.sterlite.access.bng.model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.sterlite.access.bng.bo.ColonAccessData;
import com.sterlite.access.bng.bo.OnDemandAccessData;
import com.sterlite.access.bng.bo.SingleAccessData;
import com.sterlite.access.bng.bo.VoipCdotAccessData;
import com.sterlite.access.bng.bo.WifiAccessData;

/**
 * @author ravi.divvela
 *
 */
public class ReadAccessDataWirteText {

	/**
	 * @param args
	 */
	
// 	Read CFG/TXT file and hold each and every line in to Map - readedCFGLines
	private Map<Integer, String> readedCFGLines = new HashMap<Integer, String>();
	public boolean ReadCFGLines(String cfgFilePath){
		//System.out.println("cfgFilePath: " + cfgFilePath);
		String cfgFile = cfgFilePath.substring(cfgFilePath.lastIndexOf(".")+1);
		//System.out.println("cfgFile: " + cfgFile);
		if(cfgFile.equals("cfg") || cfgFile.equals("txt") || cfgFile.equals("log")){
			try {
				//System.out.println("try bolck ");
				List<String> allLines = Files.readAllLines(Paths.get(cfgFilePath));
				int i = 0;
				for (String line : allLines) {
					i++;
					readedCFGLines.put(i, line); // Adding each line by line in to map(key is line no, value is line)
				}
				readCFgTxt = true;
				//System.out.println("ReadCFGLines readCFgTxt: " + readCFgTxt);
			} catch (IOException e) {
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
				System.out.println("No Such File In That Location, Please Provide Exact File Name&Location..! ");
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
				e.printStackTrace();
				System.exit(1);
			}
		}// End if cfg/txt/log 
		else{
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.out.println("Given File Extension: '"+ cfgFile + "', Please Provide CFG/TXT/LOG File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.exit(1);
		}// End else
		return readCFgTxt;
	}
	
// 	Read CFG GET Context to Context Line No's
	private String NAME_PORT = "port";
	private String NAME_ETHERNET = "ethernet";
	private TreeMap<Integer, String> portEthernetsWithLineNo = new TreeMap<Integer, String>();
	public void ReadMapToGetPortEthernetLineNo(){
		// To find the number of Contexts in the CFG/TXT file and added it to (contextsWithLineNo - map)
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			int previousLineNo = 0;
			int nextLineNo = 0;
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==3){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(NAME_PORT) && NAME_ETHERNET.equals(currentLineWords[clNo+1])){
						//System.out.println(currentLineNo + "  words length: " + currentLineWords.length);
						//Swap lineNo's
						if(previousLineNo!=0){
							nextLineNo = previousLineNo;
						}
						previousLineNo = currentLineNo;// Don't change
						previousLineNo = previousLineNo + nextLineNo;
						nextLineNo = previousLineNo - nextLineNo;
						previousLineNo = previousLineNo - nextLineNo;
						portEthernetsWithLineNo.put(nextLineNo, currentLineWords[clNo+1]+ " " + currentLineWords[clNo+2]);
					}// End If Context
				}// End For currentLineWords.length
			}// End If length==2
		}//End For - added map values end
		//System.out.println("Contexts: " + contextsWithLineNo);
	}// END ReadCFGToGetContextLineNo()

// 	Read CFG GET Context to Context Line No's
	private String context = "context";
	private TreeMap<Integer, String> contextsWithLineNo = new TreeMap<Integer, String>();
	public void ReadMapToGetContextLineNo(){
		// To find the number of Contexts in the CFG/TXT file and added it to (contextsWithLineNo - map)
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			int previousLineNo = 0;
			int nextLineNo = 0;
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(context)){
						//Swap lineNo's
						if(previousLineNo!=0){
							nextLineNo = previousLineNo;
						}
						previousLineNo = currentLineNo;// Don't change
						previousLineNo = previousLineNo + nextLineNo;
						nextLineNo = previousLineNo - nextLineNo;
						previousLineNo = previousLineNo - nextLineNo;
						contextsWithLineNo.put(nextLineNo, currentLineWords[clNo+1]);
					}// End If Context
				}// End For currentLineWords.length
			}// End If length==2
		}// End For - added map values end
		//System.out.println("Contexts: " + contextsWithLineNo);
	}// END ReadCFGToGetContextLineNo()
	
/*	------------------------------------------------	*/
	
//	Next port Ethernet start No Return
	public Integer getNextPortLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = portEthernetsWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}// End getNextPortLineNo()
	
//	Next Context start No Return
	public Integer getNextContextLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = contextsWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}// End getNextContextLineNo()
	
/*	------------------------------------------------	*/
//	PortMapping Details get from properties file for ethernet value added it into list "interfacePropertiesMap"
	private Map<String, String> interfacePropertiesMap = new HashMap<String, String>();
	public boolean ReadInterfacePropertiesFile(String interfaceFilePath){
		String propertiesFile = interfaceFilePath.substring(interfaceFilePath.lastIndexOf(".")+1);
		//System.out.println("propertiesFile: " + propertiesFile);
		if(!propertiesFile.equals("properties")){
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Please Provide Exact " + "\"." + "properties\" File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.exit(1);
		}
		else{
			Properties properties = new Properties();
			InputStream input = null;
			try {
	    		input = new FileInputStream(interfaceFilePath);
				properties.load(input);
				Enumeration<?> e = properties.propertyNames();
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					String value = properties.getProperty(key);
					interfacePropertiesMap.put(key, value);
					//System.out.println("Key : " + key + ", Value : " + value);
				}
				if(interfacePropertiesMap.size()!=0){
					readProperties = true;
				}else{
					System.out.println();
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.out.println("Given Propertie file Not Containing any Mapping Details/NoData ...!");
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.exit(1);
				}
			}catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						System.out.println();
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.out.println("No Such File In That Location, Please Provide Exact File Name&Location..! ");
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.exit(1);
					}// End catch
				}// End if
			}// End finally
		}// End else
		return readProperties;
	}
	
//	LoopBack Details get from properties file for loopBack value
	public String getLoopBackDetails(String contextName){
		Properties properties = new Properties();
		InputStream input = null;
		try {
			String filename = "LoopBack.properties";
    		input = ReadAccessDataWirteText.class.getClassLoader().getResourceAsStream(filename);
			properties.load(input);
			//System.out.println("loopback: " + contextName);
			loopBack = properties.getProperty(contextName);
			if(loopBack==null){
				loopBack="";
			}
		}catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return loopBack;
	}// End getLoopBackDetails()
	
/*	------------------------------------------------	*/
	
//	Variables
	private String fileNamePortEthernet = null;
	private String fileNamePortEthernetValue = null;
	private String loopBack = "";
	private String newPortEthernet = null;
	private String outerUnitNo = null;
	private String bindValue = null;
	private String innerUnitStart = null;
	private String innerUnitStop = null;
	private String singleContextName = null;
	private String bindIpAddress = null;
	private String pppoeOuterUnitNo = null; 
	private Integer ppoeInnerUnitStart;
	private Integer ppoeInnerUnitStop;
	private List<String> ipHosts = new ArrayList<String>();
	private String colonContextName;
	private String sourceIpHost;
	private String voipOuterVlanNo = null;
	private String voipInnerVlan = null;
	private Integer voipUnitNo = 0;
	private String voipIpAddress = null;
	// Static variables
	private String NAME_DOT1Q = "dot1q";
	private String NAME_PVC = "pvc";
	private String NAME_DESCRIPTION = "description";
	private String NAME_STARS = "***";
	private String NAME_BIND = "bind";
	private String NAME_ONDEMAND = "on-demand";
	private String NAME_INTERFACE = "interface";
	private String NAME_IP = "ip";
	private String NAME_HOST = "host";
	private String NAME_ADDRESS = "address";
	private String NAME_VOIP_CDOT = "voip-cdot";
	private String NAME_PROFILE = "profile";
	private String NAME_QOS_MAP = "qos-map";
	private String NAME_ENCAPSULATION = "encapsulation";
	private String NAME_PPPOE = "pppoe";
	
	private List<SingleAccessData> dot1qPVCSingleList = new ArrayList<SingleAccessData>();
	private List<OnDemandAccessData> dot1qPVCOnDemandList = new ArrayList<OnDemandAccessData>();
	private List<ColonAccessData> colonAccessDataList = new ArrayList<ColonAccessData>();
	private List<VoipCdotAccessData> voipCdotAccessDataList = new ArrayList<VoipCdotAccessData>();
	private List<String> dot1qPVCProfileList = new ArrayList<String>();
	
//	ReadMap With in the portEthernet
	public void ReadMapWithInPortEthernet(String portEthernet, Integer startPortLineNo){
		//System.out.println("portEthernet: " + portEthernet + "  :startPortLineNo:  " + startPortLineNo +"\n");
		Integer endPortLineNno = 0;
		endPortLineNno = getNextPortLineNo(startPortLineNo); 
		voipUnitNo = 15000;
		// Reading file line by line from portEthernet start lineNo to end lineNo
		for(int inPortNo=startPortLineNo+1; inPortNo <endPortLineNno ; inPortNo++ ){
			String[] inPortWords = readedCFGLines.get(inPortNo).split(" ");
			//System.out.println(inPortNo + " inPortWords length: " + inPortWords.length);
			//CASE-1: 'dot1q pvc 75' Single Value
			if(inPortWords.length==4){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					outerUnitNo = null;
					String inWord = inPortWords[inWordNo];
					//System.out.println(inPortNo + " inWord: " + inWord);
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1])){
						//System.out.println(inPortNo + " :if InWord: " + inWord + " : " + inPortWords[inWordNo+1] + " : " + inPortWords[inWordNo+2]);
						outerUnitNo = inPortWords[inWordNo+2];
						//Description Reading
						String[] descriptionWords = readedCFGLines.get(inPortNo+1).split(" ");
						StringBuilder tempDescriptionWord = new StringBuilder();
						tempDescriptionWord.append(readedCFGLines.get(inPortNo+1).toString());
						String finalDescriptionWord = null;
						for(int descNo=0; descNo<descriptionWords.length; descNo++){
							String descriptionWord = null;
							String starRemoveWord = descriptionWords[descNo];
							//System.out.println("descriptionWord: " + descriptionWord);
							// now find in this words *** also once check and remove *'s
							descriptionWord = starRemoveWord.replace("*", "");
							//System.out.println("descriptionWord: " + descriptionWord);
							if(descriptionWord.equals(NAME_DESCRIPTION)){
								tempDescriptionWord = tempDescriptionWord.delete(0, 17);
								finalDescriptionWord = tempDescriptionWord.toString().trim();
							}// End if
						}// End for DescriptionWord
						
						//BindValue read
						String[] bindWords = readedCFGLines.get(inPortNo+2).split(" ");
						for(int bindNo=0; bindNo<bindWords.length; bindNo++){
							String bindWord = bindWords[bindNo];
							//System.out.println("\n 166 bindWord " + bindWord);
							if(bindWord.equals(NAME_BIND) && NAME_INTERFACE.equals(bindWords[bindNo+1])){
								bindValue = bindWords[bindNo+2];
								singleContextName = bindWords[bindNo+3];
								bindIpAddress = getIpAddressInContext(bindValue, singleContextName);
								//System.out.println("bindValue: " + bindValue + " :contextName: " + contextName);
							}// End if NAME_BIND, NAME_INTERFACE
						}// End for BindValue read
						
						//System.out.println("bindValue: " + bindValue + "  ipAddress: " + ipAddress);
						if(bindIpAddress!=null){
							if(!singleContextName.equals("voip-sai") && !singleContextName.equals("wimax")){
								SingleAccessData singleAccessData = new SingleAccessData(outerUnitNo, finalDescriptionWord, innerUnitStart, innerUnitStop, bindValue, singleContextName, bindIpAddress);
								dot1qPVCSingleList.add(singleAccessData);
							}// End if
						}// End if adding values to dot1qPVCSingleList
						
					}// NAME_DOT1Q, NAME_PVC
					resetVariables();
				}
			}// End If inPortWords.length==4
			
			//CASE-2: 'dot1q pvc on-demand' Values// onDemand value
			else if(inPortWords.length>4){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					pppoeOuterUnitNo = null;
					String inWord = inPortWords[inWordNo];
					//System.out.println(inPortNo + " : inWord:294: " + inWord + " : " + inPortWords[inWordNo+1]);
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) && NAME_ONDEMAND.equals(inPortWords[inWordNo+2])){
						//System.out.println(inPortNo + " :if InWord: " + inWord + " : " + inPortWords[inWordNo+1] + " : " + inPortWords[inWordNo+2]);
						String[] outerUnitNo_InnerUnitStart = inPortWords[inWordNo+3].split(":");
						pppoeOuterUnitNo = outerUnitNo_InnerUnitStart[0];
						ppoeInnerUnitStart = Integer.parseInt(outerUnitNo_InnerUnitStart[1]);
						String innerUnitStop = inPortWords[inWordNo+5];
						if(innerUnitStop.equals("vpn") || innerUnitStop.equals("qos-map")){
							ppoeInnerUnitStop = ppoeInnerUnitStart;
						}
						else{
							ppoeInnerUnitStop = Integer.parseInt(innerUnitStop);
						}
						//pppoeOuterUnitNo, ppoeInnerUnitStart, ppoeInnerUnitStop, finalDescriptionWord, managementVlan, managementVlanIp
						//System.out.println("pppoeOuterUnitNo: " + pppoeOuterUnitNo + " " + " finalDescriptionWord: " + finalDescriptionWord);
						OnDemandAccessData OnDemandData = new OnDemandAccessData(pppoeOuterUnitNo, ppoeInnerUnitStart, ppoeInnerUnitStop/*, finalDescriptionWord, managementVlan, managementVlanIp*/);
						//dot1qPVCOnDemandList
						dot1qPVCOnDemandList.add(OnDemandData);
						
					}// End if NAME_DOT1Q, NAME_PVC, NAME_ONDEMAND
					
					resetVariables();
				}
			}//End else if inPortWords.length>4
			
			//CASE-3: dot1q pvc 706 profile qos-map encapsulation pppoe// Profile value
			if(inPortWords.length==8){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					pppoeOuterUnitNo = null;
					String inWord = inPortWords[inWordNo];
					//dot1q pvc 706 profile qos-map encapsulation pppoe
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) 
						&& NAME_PROFILE.equals(inPortWords[inWordNo+3]) && NAME_QOS_MAP.equals(inPortWords[inWordNo+4]) 
						&& NAME_ENCAPSULATION.equals(inPortWords[inWordNo+5]) && NAME_PPPOE.equals(inPortWords[inWordNo+6])){
						//inPortWords[inWordNo+2]; 
						//System.out.println(inPortWords.length + " profileAccessDataList: " + inPortWords[inWordNo+2]);
						dot1qPVCProfileList.add(inPortWords[inWordNo+2]);
						//inPortWords[inWordNo+3],inPortWords[inWordNo+4],inPortWords[inWordNo+5],inPortWords[inWordNo+6]
					}// End if
				}// End for
			}// End if inPortWords.length==8
			
			//CASE-4: 'dot1q pvc 75:5466' // pvcColonValue
			String finalDescriptionWord = null;
			if(inPortWords.length==5){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					outerUnitNo = null;
					String inWord = inPortWords[inWordNo];
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1])){
						//System.out.println(inPortNo + " inWord 5: " + inPortWords[inWordNo+2] + "\t length: " + inPortWords.length);
						String pvcColonValue = inPortWords[inWordNo+2].trim();
						if(pvcColonValue.contains(":")){
							//System.out.println(inPortNo + " -s: " + pvcColonValue);
							String[] outerUnitNo_InnerUnitStart = pvcColonValue.split(":");
							outerUnitNo = outerUnitNo_InnerUnitStart[0];
							innerUnitStart = outerUnitNo_InnerUnitStart[1];
							// Context Name
							String[] colonContextWords = readedCFGLines.get(inPortNo+1).split(" ");
							for(int contextNo=0; contextNo<colonContextWords.length; contextNo++){
								String colonContextWord = colonContextWords[contextNo];
								if(colonContextWord.equals(NAME_BIND) && NAME_INTERFACE.equals(colonContextWords[contextNo+1]) && !NAME_VOIP_CDOT.equals(colonContextWords[contextNo+3])){ 
									colonContextName = colonContextWords[contextNo+3];
									//System.out.println(inPortNo+1+ " :339 context Name: " + colonContextName);
								}// End if NAME_BIND, NAME_INTERFACE
							}// End for Context Name
							
							//IP host
							int n = inPortNo+2;
							for(int r=inPortNo+2; r<=n; r++){
								String[] ipHostNextWords = readedCFGLines.get(r).split(" ");
								for(int ipHostNextNo=0; ipHostNextNo<ipHostNextWords.length; ipHostNextNo++){
									String ipHostNextWord = ipHostNextWords[ipHostNextNo];
									if(ipHostNextWord.equals(NAME_IP) && NAME_HOST.equals(ipHostNextWords[ipHostNextNo+1])){
										//System.out.println(inPortNo + " :ip Host: " + ipHostNextWords[ipHostNextNo+2]);
										String ipHostNext = ipHostNextWords[ipHostNextNo+2];
										//System.out.println("ipHostNext: " + ipHostNext);
										ipHosts.add(ipHostNext);
										String subLow = ipHostNext.substring(0, ipHostNext.lastIndexOf('.'));
										sourceIpHost = subLow+"."+"1";
										n++;
									}// End if NAME_IP, NAME_HOST
								}// End for ipHostNextWords.lenght
							}// End for inPortNo
							
							//Description Reading
							String[] descriptionWords = readedCFGLines.get(inPortNo-4).split(" ");
							StringBuilder tempDescriptionWord = new StringBuilder();
							tempDescriptionWord.append(readedCFGLines.get(inPortNo-4).toString());
							for(int descNo=0; descNo<descriptionWords.length; descNo++){
								String descriptionWord = null;
								String starRemoveWord = descriptionWords[descNo];
								//System.out.println("descriptionWord: " + descriptionWord);
								// now find in this words *** also once check and remove *'s
								descriptionWord = starRemoveWord.replace("*", "");
								//System.out.println("descriptionWord: " + descriptionWord);
								if(descriptionWord.equals(NAME_DESCRIPTION) && NAME_STARS.equals(descriptionWords[descNo+1])){
									tempDescriptionWord = tempDescriptionWord.delete(0, 17);
									finalDescriptionWord = tempDescriptionWord.toString().substring(0, tempDescriptionWord.length()-3).trim();
								}// End if NAME_DESCRIPTION, NAME_STARS
							}// End for DescriptionWord
						}// End if pvcColonValue(:)
						// Description null
						if(finalDescriptionWord==null){
							finalDescriptionWord = "connectivity towards " + outerUnitNo;
						}
						// Adding values in to list of colonAccessDataList
						if(finalDescriptionWord!=null && ipHosts!=null && colonContextName!=null){
							String loopBackValue = getLoopBackDetails(colonContextName);
							ColonAccessData colonAccessData = new ColonAccessData(outerUnitNo, finalDescriptionWord, innerUnitStart, colonContextName, sourceIpHost, loopBackValue, ipHosts );
							//System.out.println("colonAccessData: " + colonAccessData);
							colonAccessDataList.add(colonAccessData);
							//System.out.println(inPortNo + " :ColonValue: " + outerUnitNo + " | " + finalDescriptionWord + " | " + innerUnitStart + " | " + ipHost);
						}// End if adding colonAccessDataList
						
					}// End if NAME_DOT1Q, NAME_PVC
					resetVariables();
				}
			}// End if inPortWords.length==5
			
			//CASE-5: voip-cdot values
			if(inPortWords.length==5){
				String[] voipCdotWords = readedCFGLines.get(inPortNo+1).split(" ");
				//System.out.println("else:439: " + voipCdotWords.length );
				for(int voipNo=0; voipNo<voipCdotWords.length; voipNo++){
					
					String voipCdotWord = voipCdotWords[voipNo];
					if(voipCdotWord.equals(NAME_BIND) && NAME_INTERFACE.equals(voipCdotWords[voipNo+1]) && NAME_VOIP_CDOT.equals(voipCdotWords[voipNo+3]) ){ 
						//System.out.println(inPortNo+1 + " Bind Value: "+voipCdotWords[voipNo+2] + " : " + voipCdotWords[voipNo+3]);
						String[] voipCdotDot1qPvcWords = readedCFGLines.get(inPortNo).split(" ");
						for(int pvcNo=0; pvcNo<voipCdotDot1qPvcWords.length; pvcNo++){
							String voipCdotDot1qPvcWord = voipCdotDot1qPvcWords[pvcNo];
							if(voipCdotDot1qPvcWord.equals(NAME_DOT1Q) && NAME_PVC.equals(voipCdotDot1qPvcWords[pvcNo+1])){
								//System.out.println("484: " + voipCdotDot1qPvcWords[2] + " : " + voipCdotDot1qPvcWords[3] + " : " + voipCdotDot1qPvcWords[4]);
								String pvcColonValue = voipCdotDot1qPvcWords[pvcNo+2].trim();
								if(pvcColonValue.contains(":")){
									//System.out.println(inPortNo + " -s: " + pvcColonValue);
									String[] outerUnitNo_InnerUnitStart = pvcColonValue.split(":");
									voipOuterVlanNo = outerUnitNo_InnerUnitStart[0];
									voipInnerVlan = outerUnitNo_InnerUnitStart[1];
									//System.out.println("494: " + voipCdotWords[voipNo+2] + " : " + voipCdotWords[voipNo+3]);
									voipIpAddress = getIpAddressInContextVoipCdot(voipCdotWords[voipNo+2], voipCdotWords[voipNo+3]);
									
									VoipCdotAccessData voipCdotAccessData = new VoipCdotAccessData(voipOuterVlanNo, voipInnerVlan, voipUnitNo, voipIpAddress, voipInnerVlan);
									voipCdotAccessDataList.add(voipCdotAccessData);
									//System.out.println("voipCdotAccessData: " + voipCdotAccessData);
									voipUnitNo++;
									//System.out.println("voipIpAddress: " + voipIpAddress1);
									//System.out.println("");
								}// End if contains : 
							
							}// End if NAME_DOT1Q, NAME_PVC
						}// End for voipCdotDot1qPvcWords
					}// End if name_bind, name_interface, name_voip_cdot
					
					resetVariables();
				}// End for voipNo
			}//End if inPortWords.length==5
			
			//CASE-6: WIFI-Offload [dot1q pvc 4066 profile qos-map] 
			if(inPortWords.length>5){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					wifiVlanNo = null;
					wifiInterfaceIp = null;
					String inWord = inPortWords[inWordNo];
					//System.out.println("inPortNo: " + inPortNo);
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) && NAME_PROFILE.equals(inPortWords[inWordNo+3])/* && NAME_QOS_MAP.equals(inPortWords[inWordNo+4])*/ ){
						//System.out.println("502: " + "inPortNo: " + inPortNo + " :wifi offload: " + inPortWords[inWordNo+2]);
						wifiVlanNo = inPortWords[inWordNo+2];
						//BindValue read
						String[] bindWords = readedCFGLines.get(inPortNo+2).split(" ");
						for(int bindNo=0; bindNo<bindWords.length; bindNo++){
							String bindWord = bindWords[bindNo];
							//System.out.println("\n 166 bindWord " + bindWord);
							if(bindWord.equals(NAME_BIND) && NAME_INTERFACE.equals(bindWords[bindNo+1])){
								String wifiBindValue = bindWords[bindNo+2];
								String wifiContextName = bindWords[bindNo+3];
								wifiInterfaceIp = getIpAddressInContext(wifiBindValue, wifiContextName);
								//System.out.println(inPortNo+2 + " : wifiBindValue: " + wifiBindValue + " :wifiContextName: " + wifiContextName + " :wifiInterfaceIp: " + wifiInterfaceIp);
								WifiAccessData wifiAccessData = new WifiAccessData(wifiVlanNo, wifiInterfaceIp, wifiContextName);
								wifiAccessDataList.add(wifiAccessData);
							}
						}// End for BindValue read
					}// End if NAME_DOT1Q, NAME_PVC, NAME_PROFILE
				}// End For inWords
			}// End if inPortWords.length>4
		}// End if inPortNo
		
	}// End ReadMapWithInPortEthernet()
	private String wifiVlanNo = null;
	private String wifiInterfaceIp = null;
	private List<WifiAccessData> wifiAccessDataList = new ArrayList<WifiAccessData>();
	
//	getIpAddressInContext voip-cdot
	public String getIpAddressInContextVoipCdot(String voipBindValue, String voipContextName){
		String tempBindIpAddress = null;
		for(Map.Entry<Integer, String> e: contextsWithLineNo.entrySet()){
			String context = e.getValue();
			if(context.equals(voipContextName)){
				Integer startContextLineNo = 0;
				Integer endContextLineNo = 0;
				startContextLineNo = e.getKey();
				endContextLineNo = getNextContextLineNo(startContextLineNo);
				//System.out.println("Context Name Matches: " + context + " : " + e.getKey());
				//System.out.println("403 startContextLineNo: " + startContextLineNo + " endContextLineNo: " + endContextLineNo);
				for(int contextNo=startContextLineNo; contextNo<endContextLineNo; contextNo++){
					String[] interfaceIpWords = readedCFGLines.get(contextNo).split(" ");
					for(int interfaceNo=0; interfaceNo<interfaceIpWords.length; interfaceNo++){
						String interfaceIpWord = interfaceIpWords[interfaceNo];
						if(interfaceIpWord.equals(NAME_INTERFACE)){
							//System.out.println(" 409: " + interfaceIpWords[interfaceNo+1]);
							if(voipBindValue.equals(interfaceIpWords[interfaceNo+1])){
								//System.out.println(contextNo + " :542: inside bindvalue mathes: "+ voipBindValue);
								String[] ipAddressWords = readedCFGLines.get(contextNo+2).split(" ");
								for(int ipNo=0; ipNo<ipAddressWords.length; ipNo++){
									String ipAddressWord = ipAddressWords[ipNo];
									if(ipAddressWord.equals(NAME_IP) && NAME_ADDRESS.equals(ipAddressWords[ipNo+1])){
										//System.out.println("tempBindIpAddress: " + ipAddressWords[ipNo+2] + "\n");
										tempBindIpAddress = ipAddressWords[ipNo+2];
									}// End if NAME_IP, NAME_ADDRESS
								}// End for ipAddressWords.length
							}// End if voipBindValue.equals()
						}// End if NAME_INTERFACE
					}// End for interfaceIpWords.length
				}// End for contextNo
			}// End if Context
		}// End for contextsWithLineNo.set
		return tempBindIpAddress;
	}// End getIpAddressInContextVoipCdot
	
//	*********************
	
//	getIpAddressInContext
	public String getIpAddressInContext(String bindValue, String contextName){
		//System.out.println(bindValue + " :392: " + ContextName);
		String tempBindIpAddress = null;
		for(Map.Entry<Integer, String> e: contextsWithLineNo.entrySet()){
			String context = e.getValue();
			if(context.equals(contextName)){
				Integer startContextLineNo = 0;
				Integer endContextLineNo = 0;
				startContextLineNo = e.getKey();
				endContextLineNo = getNextContextLineNo(startContextLineNo);
				//System.out.println("Context Name Matches: " + context + " : " + e.getKey());
				//System.out.println("startContextLineNo: " + startContextLineNo + " endContextLineNo: " + endContextLineNo);
				for(int contextNo=startContextLineNo; contextNo<endContextLineNo; contextNo++){
					String[] interfaceIpWords = readedCFGLines.get(contextNo).split(" ");
					for(int interfaceNo=0; interfaceNo<interfaceIpWords.length; interfaceNo++){
						String interfaceIpWord = interfaceIpWords[interfaceNo];
						if(interfaceIpWord.equals(NAME_INTERFACE)){
							//System.out.println("\n " + interfaceIpWords[interfaceNo+1]);
							if(bindValue.equals(interfaceIpWords[interfaceNo+1])){
								//System.out.println(contextNo + " : inside bindvalue mathes: ");
								String[] ipAddressWords = readedCFGLines.get(contextNo+2).split(" ");
								for(int ipNo=0; ipNo<ipAddressWords.length; ipNo++){
									String ipAddressWord = ipAddressWords[ipNo];
									if(ipAddressWord.equals(NAME_IP) && NAME_ADDRESS.equals(ipAddressWords[ipNo+1])){
										//System.out.println("tempBindIpAddress: " + ipAddressWords[ipNo+2]);
										tempBindIpAddress = ipAddressWords[ipNo+2];
									}// End if NAME_IP, NAME_ADDRESS
								}// End for ipAddressWords.length
							}// End if bindValue.equals
						}// End if NAME_INTERFACE
					}
				}// End for contextNo
			}// End if Context
		}// End for contextsWithLineNo.set
		return tempBindIpAddress;
	}// End getIpAddressInContext
	
//	Clean all variables
	public void resetVariables(){
		outerUnitNo = null;
		innerUnitStart = null;
		innerUnitStop = null;
		bindValue = null;
		singleContextName = null;
		bindIpAddress = null;
		colonContextName = null;
		sourceIpHost = null;
		pppoeOuterUnitNo = null; 
		ppoeInnerUnitStart = null; 
		ppoeInnerUnitStop = null;
		voipOuterVlanNo = null;
		voipInnerVlan = null;
		voipIpAddress = null;
		wifiVlanNo = null;
		wifiInterfaceIp = null;
		ipHosts = new ArrayList<String>();
	}// End resetVariables()
	
// 	Main InvokesMethods Starts
	private boolean readCFgTxt = false;
	private boolean readProperties = false;
	private String outputFilePath = null;
	private static final DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");//yyyy/MM/dd HH:mm:ss
	public void mainInvokesMethods() {
		readCFgTxt = false;
		readProperties = false;
		outputFilePath = null;
		
		System.out.println("Enter Exact CFG/TXT/LOG File Path Location : ");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
	    String cfgFilePath = scanner.next();
	    System.out.println("Given CFG/TXT/LOG FilePath : " + cfgFilePath);
	    readCFgTxt = ReadCFGLines(cfgFilePath);
	    if(readCFgTxt){
	    	System.out.println();
		    System.out.println("Provide Port Mapping Properties File Path Location : ");
			@SuppressWarnings("resource")
			Scanner mappingScanner = new Scanner(System.in);
		    String mappingFilePath = mappingScanner.next();
		    System.out.println("Given Port Mapping Properties FilePath : " + mappingFilePath);
		    
		    readProperties = ReadInterfacePropertiesFile(mappingFilePath);
		    
		    if(readProperties){
		    	// now read output path location
		    	System.out.println();
			    System.out.println("Provide Output Path Location : ");
				@SuppressWarnings("resource")
				Scanner outputScanner = new Scanner(System.in);
			    outputFilePath = outputScanner.next();
			    Date date = new Date();
			    String todayDate =  sdf.format(date);
			    outputFilePath = outputFilePath+"\\"+todayDate+"_Downlink";
			    System.out.println("Given OutPut Path Location : " + outputFilePath);
		
				ReadMapToGetPortEthernetLineNo();
				ReadMapToGetContextLineNo();
				Set<Entry<String, String>> interfaceEntries = interfacePropertiesMap.entrySet();
				for (Entry<String, String> interfaceEntry : interfaceEntries) {
					String portEthernet = (String) interfaceEntry.getKey();// get the portEthernet value from properties file
					fileNamePortEthernetValue = (String) interfaceEntry.getValue();
					//System.out.println("portEthernet Value: " + interfaceEntry.getValue());
					newPortEthernet = portEthernet.replace("_", " ");
					// Ethernet name as file name convert with.(/)
					String[] portName = portEthernet.split("/");
					fileNamePortEthernet = portName[0]+"."+portName[1];
					
					//System.out.println("newPortEthernet: " + newPortEthernet);
					for(Map.Entry<Integer, String> e: portEthernetsWithLineNo.entrySet()){
						String entrySetPort = e.getValue();
						if(entrySetPort.equals(newPortEthernet)){
							//System.out.println("entrySetPort: " + entrySetPort + "  " + newPortEthernet + " :Key: " + e.getKey() + " :Value: " + e.getValue());
							ReadMapWithInPortEthernet(newPortEthernet, e.getKey());
							if(dot1qPVCSingleList.size()!=0)
								getDot1qPVCSingleValues();
							if(dot1qPVCOnDemandList.size()!=0)
								getDot1qPVCOnDemandValues();
							if(colonAccessDataList.size()!=0)
								getDot1qPVCColonValues();
							
							if(voipCdotAccessDataList.size()!=0)
								getDot1qPVCVoipCdotValues();
							if(dot1qPVCProfileList.size()!=0)
								getDot1qPVCProfileValues();
							if(wifiAccessDataList.size()!=0)
								getDot1qPVCWifiValues();
							
							dot1qPVCSingleList = new ArrayList<SingleAccessData>();
							dot1qPVCOnDemandList = new ArrayList<OnDemandAccessData>();
							colonAccessDataList = new ArrayList<ColonAccessData>();
							voipCdotAccessDataList = new ArrayList<VoipCdotAccessData>();
							dot1qPVCProfileList = new ArrayList<String>();
							wifiAccessDataList = new ArrayList<WifiAccessData>();
						}
					}// End for portEthernetsWithLineNo
					
				}// End if readProperties
				
			}// End for interfaceEntries
			
	    }// End if(readProperties)
	}// End mainInvokesMethods()
	
//	Static variables
	private String NAME_SET_INTERFACES = "set interfaces";
	private String NAME_UNIT = " unit ";
	private String NAME_VLAN_ID = " vlan-id ";
	private String NAME_FAMILY_INET_ADDRESS = " family inet address ";
	private String NAME_AUTO_CONFIGURE = " auto-configure stacked-vlan-ranges dynamic-profile VLAN-DEMUX ranges ";
	private String NAME_VLAN_TAGS_OUTER = " vlan-tags outer ";
	private String NAME_VLAN_TAGS_INNER = " vlan-tags inner ";
	private String NAME_FAMILY_INET_UNNUMBERED_ADDRESS = " family inet unnumbered-address ";
	private String NAME_PREFERRED_SOURCE = "preferred-source-address ";
	private String NAME_SET_ROUTING_INSTANCES = "set routing-instances ";
	private String NAME_ROUTING_OPTIONS = "routing-options static route ";
	private String NAME_BRIDGE_DOMAINS = "set bridge-domains ";
	private String NAME_DOMAIN_TYPE_BRIDGE = "domain-type bridge";
	private String NAME_ROUTING_INTERFACE = " routing-interface ";
	private String NAME_ENCAPSULATION_VLAN_BRIDGE = " encapsulation vlan-bridge";
	private String NAME_FAMILY_BRIDGE = " family bridge";
	private String NAME_FAMILY_PPPOE = "family pppoe duplicate-protection";
	private String NAME_FAMILY_PPPOE_DYNAMIC = "family pppoe dynamic-profile PPPOE";
	
//	'dot1q pvc 75' single value
	public void getDot1qPVCSingleValues(){
		//1. set interfaces ge-2/1/4 unit 2829 description "*** Connectivity to kujad DSLAM ***"
		//2. set interfaces ge-2/1/4 unit 2829 vlan-id 2829
		//3. set interfaces ge-2/1/4 unit 2829 family inet address 10.248.89.106/30
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
	    FileWriter fr = null;
        BufferedWriter br = null;
        try{
            fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"UnnubmerInterface"+".txt");
            br = new BufferedWriter(fr);
            for(int i = 0; i< dot1qPVCSingleList.size(); i++){
            	SingleAccessData singleAccessData = dot1qPVCSingleList.get(i);
    			String finalDataDesc = null;
    			String dataDesc = singleAccessData.getDescription();
    			if(dataDesc!=null){
    				finalDataDesc = dataDesc.replace("*", "").trim();
    			}
    			else{
    				finalDataDesc = dataDesc;
    			}
            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + " description " + "\"" + finalDataDesc + "\" " + System.getProperty("line.separator");
		        String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + NAME_VLAN_ID + singleAccessData.getOuterUnitNo() + System.getProperty("line.separator");
		        String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + NAME_FAMILY_INET_ADDRESS + singleAccessData.getBindIpAddress() + System.getProperty("line.separator");
		        String dataWithNewLine4 = NAME_SET_ROUTING_INSTANCES + singleAccessData.getContextName() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + singleAccessData.getOuterUnitNo() + System.getProperty("line.separator");
		        String dataWithNewLine5 = System.getProperty("line.separator");
            	
                br.write(dataWithNewLine1);
                br.write(dataWithNewLine2);
                br.write(dataWithNewLine3);
                br.write(dataWithNewLine4);
                br.write(dataWithNewLine5);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}// End getDot1qPVCSingleValues()
	
//	'dot1q pvc OnDemand' List logic
	public void getDot1qPVCOnDemandValues(){
		//1. set interfaces ge-3/1/3 auto-configure stacked-vlan-ranges dynamic-profile VLAN-DEMUX ranges 3767-3767,128-1499
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
        FileWriter fr = null;
        BufferedWriter br = null;
         try{
        	fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"PPPOE-OnDemand"+".txt");
            br = new BufferedWriter(fr);
            String outerUnitNo = null;
            Integer innerUnitStart = 0;
            Integer innerUnitStop = 0;
            
            //Removing duplicate 'PppoeOuterUnitNo' while adding this list
            HashSet<OnDemandAccessData> dot1qPVCOnDemandSetList = new HashSet<OnDemandAccessData>();
            for(int i = 0; i< dot1qPVCOnDemandList.size(); i++){
            	OnDemandAccessData onDemandData = dot1qPVCOnDemandList.get(i);
            	//System.out.println("824: " + onDemandData);
            	if(outerUnitNo==null){
            		outerUnitNo = onDemandData.getPppoeOuterUnitNo();
            		innerUnitStart = onDemandData.getPpoeInnerUnitStart();
            		innerUnitStop = onDemandData.getPpoeInnerUnitStop();
            		//System.out.println("outerUnitNo:if: " + outerUnitNo + " : " + innerUnitStart + " : " + innerUnitStop);
            	}
            	else{
            		if(onDemandData.getPppoeOuterUnitNo().equals(outerUnitNo)){
            			if(onDemandData.getPpoeInnerUnitStart() < innerUnitStart){
            				innerUnitStart = onDemandData.getPpoeInnerUnitStart();
            				//System.out.println("837: " + innerUnitStart);
            			}
            			if(onDemandData.getPpoeInnerUnitStop() > innerUnitStop){
            				innerUnitStop = onDemandData.getPpoeInnerUnitStop();
            				//System.out.println("841: " + innerUnitStop);
            			}
            			//System.out.println("outerUnitNo:else : " + outerUnitNo + " : " + innerUnitStart + " : " + innerUnitStop);
            		}
            		else if(!onDemandData.getPppoeOuterUnitNo().equals(outerUnitNo)){
            			if(innerUnitStop<1199){
                    		innerUnitStop = 1199;
            			}
                    	//System.out.println("outerUnitNo: " + outerUnitNo + " : " + innerUnitStart + " : " + innerUnitStop);
                    	OnDemandAccessData setData = new OnDemandAccessData(outerUnitNo, innerUnitStart, innerUnitStop);
                    	dot1qPVCOnDemandSetList.add(setData);
            			outerUnitNo = null;
            			innerUnitStart = 0;
                        innerUnitStop = 0;
            			outerUnitNo = onDemandData.getPppoeOuterUnitNo();
                		innerUnitStart = onDemandData.getPpoeInnerUnitStart();
                		innerUnitStop = onDemandData.getPpoeInnerUnitStop();
                		//System.out.println("outerUnitNo:if: " + outerUnitNo + " : " + innerUnitStart + " : " + innerUnitStop);
            		}
            	}// End else outerUnitNo
            	
            	/*if(innerUnitStop<1199){
            		innerUnitStop = 1199;
    			}
            	//System.out.println("outerUnitNo: " + outerUnitNo + " : " + innerUnitStart + " : " + innerUnitStop);
            	OnDemandAccessData setData = new OnDemandAccessData(outerUnitNo, innerUnitStart, innerUnitStop);
            	dot1qPVCOnDemandSetList.add(setData);*/
            	
            }// End for dot1qPVCOnDemandList
            
			br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " flexible-vlan-tagging" + System.getProperty("line.separator"));
			br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " auto-configure stacked-vlan-ranges dynamic-profile VLAN-DEMUX accept pppoe" + System.getProperty("line.separator"));
			br.write(System.getProperty("line.separator"));
            for(OnDemandAccessData onDemandSetData: dot1qPVCOnDemandSetList){
            	//System.out.println("864:onDemandSetData: " + onDemandSetData);
            	String dataWithNewLine = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_AUTO_CONFIGURE + onDemandSetData.getPppoeOuterUnitNo() + "-" +onDemandSetData.getPppoeOuterUnitNo() 
	        	+ "," + onDemandSetData.getPpoeInnerUnitStart() + "-" + onDemandSetData.getPpoeInnerUnitStop() + System.getProperty("line.separator");
                br.write(dataWithNewLine);
            }// End for dot1qPVCOnDemandSetList
            
			
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
            	br.write(System.getProperty("line.separator"));
            	br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " auto-configure remove-when-no-subscribers" + System.getProperty("line.separator"));
				br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " encapsulation flexible-ethernet-services" + System.getProperty("line.separator"));
            
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}//End getDot1qPVCOnDemandValues()
	
//	'dot1q pvc 3051:108' List logic
	public void getDot1qPVCColonValues(){
		//1. set interfaces ge-2/1/4 unit 2829(2200) description "*** Connectivity to kujad DSLAM ***"
		//2. set interfaces ge-2/1/4 unit 2829 vlan-tags outer 2829
		//3. set interfaces ge-2/1/4 unit 2829 vlan-tags inner 112
		//4. set interfaces ge-2/1/4 unit 2829 family inet unnumbered-address lo0.2
		//5. set interfaces ge-2/1/4 unit 2829 family inet unnumbered-address preferred-source-address 10.226.130.1
		//6. set routing-instances mgmt interface ge-2/1/4.2829
		//7. set routing-instances mgmt routing-options static route 10.226.138.91/32 qualified-next-hop ge-2/1/4.2829
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
        FileWriter fr = null;
        BufferedWriter br = null;
        try{
        	fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"Mgmt"+".txt");
            br = new BufferedWriter(fr);
            for(int i = 0; i<colonAccessDataList.size(); i++){
            	ColonAccessData colonAccessData = colonAccessDataList.get(i);
    			String finalDataDesc = null;
    			String dataDesc = colonAccessData.getDescription();
    			if(dataDesc!=null){
    				finalDataDesc = dataDesc.replace("*", "").trim();
    			}
    			else{
    				finalDataDesc = dataDesc;
    			}
            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + " " + NAME_DESCRIPTION + " \"" + finalDataDesc + "\" " + System.getProperty("line.separator");
                String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_VLAN_TAGS_OUTER + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
                String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_VLAN_TAGS_INNER + colonAccessData.getInnerUnitStart() + System.getProperty("line.separator");
                String dataWithNewLine4 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + "lo0."+ colonAccessData.getLoopBack() + System.getProperty("line.separator");
                String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + NAME_PREFERRED_SOURCE + colonAccessData.getSourceIpHost() + System.getProperty("line.separator");
                String dataWithNewLine6 = NAME_SET_ROUTING_INSTANCES + colonAccessData.getContextName() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
                String ipHostValues = null;
                
                String dataWithNewLine8 = System.getProperty("line.separator");
                br.write(dataWithNewLine1);
                br.write(dataWithNewLine2);
                br.write(dataWithNewLine3);
                br.write(dataWithNewLine4);
                br.write(dataWithNewLine5);
                br.write(dataWithNewLine6);
                for(int lineNo=0; lineNo<colonAccessData.getIpHosts().size(); lineNo++){
        			String singleIpHostValue = colonAccessData.getIpHosts().get(lineNo);
        			ipHostValues = singleIpHostValue + "/32" ;
        			String dataWithNewLine7 = NAME_SET_ROUTING_INSTANCES + colonAccessData.getContextName() + " " + NAME_ROUTING_OPTIONS + ipHostValues + " qualified-next-hop " + fileNamePortEthernetValue + "." + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
        			br.write(dataWithNewLine7);
                }
                br.write(dataWithNewLine8);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}//End getDot1qPVCColonValues()
	
//	voipCdotAccessDataList
	public void getDot1qPVCVoipCdotValues(){
		//1. set interfaces irb unit 1821(voipInnerVlan=1820) family inet address 10.109.96.1/23(voipIpAddress=10.92.54.1/24)
		//2. set bridge-domains BD_1821(voipInnerVlan=1820) domain-type bridge
		//3. set bridge-domains BD_1821(voipInnerVlan=1820) vlan-id 1821(voipInnerVlan=1820)
		//4. set bridge-domains BD_1821(voipInnerVlan=1820) routing-interface irb.1821(voipInnerVlan=1820)
		//5. set interfaces ge-3/1/2 unit 15007 description "*** ATA-CDOT 3302:1820 VOIP ***"
		//6. set bridge-domains BD_1820 interface ge-3/1/2.15007
		//7. set interfaces ge-3/1/2 unit 15007 encapsulation vlan-bridge
		//8. set interfaces ge-3/1/2 unit 15007 vlan-tags outer 3302
		//9. set interfaces ge-3/1/2 unit 15007 vlan-tags inner 1820
		//10. set interfaces ge-3/1/2 unit 15007 encapsulation vlan-bridge
		//11. set interfaces ge-3/1/2 unit 15007 family bridge
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
        FileWriter fr = null;
        BufferedWriter br = null;
        try{
        	fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"VOIP-CDOT"+".txt");
            br = new BufferedWriter(fr);
            Set<String> voipInnerVlanSet = new HashSet<String>();
            for(int i = 0; i<voipCdotAccessDataList.size(); i++){
            	VoipCdotAccessData voipCdotAccessData = voipCdotAccessDataList.get(i);
            	String dataWithNewLine1 = NAME_SET_INTERFACES + " irb" + NAME_UNIT + voipCdotAccessData.getVoipInnerVlan() + NAME_FAMILY_INET_ADDRESS + voipCdotAccessData.getVoipIpAddress() + System.getProperty("line.separator");
                String dataWithNewLine2 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + " " + NAME_DOMAIN_TYPE_BRIDGE + System.getProperty("line.separator");
                String dataWithNewLine3 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + NAME_VLAN_ID + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
                String dataWithNewLine4 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + NAME_ROUTING_INTERFACE + "irb." + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
                String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + " " + NAME_DESCRIPTION + " \"VOIP-CDOT " + voipCdotAccessData.getVoipOuterVlanNo() + ":" + voipCdotAccessData.getVoipInnerVlan() + "\"" + System.getProperty("line.separator");
                String dataWithNewLine6 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + voipCdotAccessData.getVoipUnitNo() + System.getProperty("line.separator");
                String dataWithNewLine7 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
                String dataWithNewLine8 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_VLAN_TAGS_OUTER + voipCdotAccessData.getVoipOuterVlanNo() + System.getProperty("line.separator");
                String dataWithNewLine9 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_VLAN_TAGS_INNER + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
                String dataWithNewLine10 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
                String dataWithNewLine11 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_FAMILY_BRIDGE + System.getProperty("line.separator");
                String dataWithNewLine12 = System.getProperty("line.separator");
                
                if(voipInnerVlanSet.contains(voipCdotAccessData.getVoipInnerVlan())){
            		br.write(dataWithNewLine5);
                    br.write(dataWithNewLine6);
                    br.write(dataWithNewLine7);
                    br.write(dataWithNewLine8);
                    br.write(dataWithNewLine9);
                    br.write(dataWithNewLine10);
                    br.write(dataWithNewLine11);
                    br.write(dataWithNewLine12);
            	}
            	else{
            		voipInnerVlanSet.add(voipCdotAccessData.getVoipInnerVlan());
            		br.write(dataWithNewLine1);
                    br.write(dataWithNewLine2);
                    br.write(dataWithNewLine3);
                    br.write(dataWithNewLine4);
                    br.write(dataWithNewLine5);
                    br.write(dataWithNewLine6);
                    br.write(dataWithNewLine7);
                    br.write(dataWithNewLine8);
                    br.write(dataWithNewLine9);
                    br.write(dataWithNewLine10);
                    br.write(dataWithNewLine11);
                    br.write(dataWithNewLine12);
            	}
            }// End For
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}// End getDot1qPVCVoipCdotValues()
	
//	'dot1q pvc 712 profile qos-map encapsulation pppoe' 
	public void getDot1qPVCProfileValues(){
		//1. set interfaces ge-2/1/0 unit 701 vlan-id 701
		//2. set interfaces ge-2/1/0 unit 701 family pppoe duplicate-protection
		//3. set interfaces ge-2/1/0 unit 701 family pppoe dynamic-profile PPPOE
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
	    FileWriter fr = null;
        BufferedWriter br = null;
        try{
            fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"PPPOE-OnDemand-singleVlan"+".txt");
            br = new BufferedWriter(fr);
            for(int i = 0; i< dot1qPVCProfileList.size(); i++){
            	String profileVlanNo = dot1qPVCProfileList.get(i);
            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo +  NAME_VLAN_ID + profileVlanNo + System.getProperty("line.separator");
		        String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo + " " + NAME_FAMILY_PPPOE + System.getProperty("line.separator");
		        String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo + " " + NAME_FAMILY_PPPOE_DYNAMIC + System.getProperty("line.separator");
		        String dataWithNewLine4 = System.getProperty("line.separator");
            	
                br.write(dataWithNewLine1);
                br.write(dataWithNewLine2);
                br.write(dataWithNewLine3);
                br.write(dataWithNewLine4);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}// End getDot1qPVCProfileValues()
	
//	CASE-6: 'dot1q pvc 4066 profile qos-map' 
	public void getDot1qPVCWifiValues(){
		//1. 1. set interfaces irb unit 4066(wifiVlanNo=4066) family inet address 10.172.44.1/22(wifiInterfaceIp=10.172.44.1/22)
		//2. set bridge-domains BD_4066(wifiVlanNo=4066) domain-type bridge
		//3. set bridge-domains BD_4066(wifiVlanNo=4066) vlan-id 4066(wifiVlanNo=4066)
		//4. set bridge-domains BD_4066(wifiVlanNo=4066) routing-interface irb.4066(wifiVlanNo=4066)
		//5. set interfaces ge-3/1/2 unit 4066 description "*** WIFI-Offload ***"
		//6. set bridge-domains BD_4066 interface ge-3/1/2.4066
		//7. set interfaces ge-3/1/2 unit 4066 encapsulation vlan-bridge
		//8. set interfaces ge-3/1/2 unit 4066 family bridge
		String outputPath = outputFilePath + "\\" + fileNamePortEthernet;
	    File file = new File(outputPath);
	    file.mkdirs();
	    FileWriter fr = null;
        BufferedWriter br = null;
        try{
            fr = new FileWriter(outputPath+"\\"+fileNamePortEthernet+"_"+"Wifi"+".txt");
            br = new BufferedWriter(fr);
            for(int i = 0; i< wifiAccessDataList.size(); i++){
            	WifiAccessData wifiAccessData = wifiAccessDataList.get(i);
                if(wifiAccessData.getWifiVlanNo().equals("4063")){
                	//1.set interfaces ge-2/1/1 unit 4063 vlan-id 4063
                	//2.set interfaces ge-2/1/1 unit 4063 family inet unnumbered-address lo0.32
                	//3.set interfaces ge-2/1/1 unit 4063 family inet unnumbered-address preferred-source-address 100.64.40.1
                	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_VLAN_ID + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
                	String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + "lo0." + getLoopBackDetails(wifiAccessData.getWifiContextName()) + System.getProperty("line.separator");
                	String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + NAME_PREFERRED_SOURCE + wifiAccessData.getWifiInterfaceIp() + System.getProperty("line.separator");
                	String dataWithNewLine4 = System.getProperty("line.separator");
                	br.write(dataWithNewLine1);
                    br.write(dataWithNewLine2);
                    br.write(dataWithNewLine3);
                    br.write(dataWithNewLine4);
                }// End if 4063
            	else{
            		String dataWithNewLine1 = NAME_SET_INTERFACES + " irb" + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_ADDRESS + wifiAccessData.getWifiInterfaceIp() + System.getProperty("line.separator");
                	String dataWithNewLine2 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + " " + NAME_DOMAIN_TYPE_BRIDGE + System.getProperty("line.separator");
                	String dataWithNewLine3 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + NAME_VLAN_ID + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
                	String dataWithNewLine4 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + NAME_ROUTING_INTERFACE + "irb." + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
                	String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + " " + NAME_DESCRIPTION + " \"WIFI-Offload" + "\"" + System.getProperty("line.separator");
                	String dataWithNewLine6 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
                    String dataWithNewLine7 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
                    String dataWithNewLine8 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_BRIDGE + System.getProperty("line.separator");
                    String dataWithNewLine9 = System.getProperty("line.separator");
                    
                    br.write(dataWithNewLine1);
                    br.write(dataWithNewLine2);
                    br.write(dataWithNewLine3);
                    br.write(dataWithNewLine4);
                    br.write(dataWithNewLine5);
                    br.write(dataWithNewLine6);
                    br.write(dataWithNewLine7);
                    br.write(dataWithNewLine8);
                    br.write(dataWithNewLine9);
            	}// End else
            }// End for
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                br.close();
                fr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }// End finally
	}// End getDot1qPVCWifiValues()
	

// 	************************ Main Method **************************** 		//	
	public static void main(String[] args) {
		ReadAccessDataWirteText readAccessDataWirteJson = new ReadAccessDataWirteText();
		readAccessDataWirteJson.mainInvokesMethods();
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("Successfully Access Data Generated ...! ");
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("!...	Thank You	...! ");
	}// End Main Method

//	 **************************************************** 		//	

}// End main class
