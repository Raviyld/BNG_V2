/**
 * 
 */
package com.sterlite.baseconfig;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;



/**
 * @author ravi.divvela
 *
 */
public class BaseConfigAutomation {

	/**
	 * @param args
	 */
//	HostName Values get from properties file, added it into list "hostNamePropertiesMap"
	private Map<String, String> hostNamePropertiesMap = new HashMap<String, String>();
	public void ReadHostNamePropertiesFile(String hostNameFilePath){
		//System.out.println("ReadInterfacePropertiesFile(): " + interfaceFilePath);
		String propertiesFile = hostNameFilePath.substring(hostNameFilePath.lastIndexOf(".")+1);
		//System.out.println("propertiesFile: " + propertiesFile);
		if(!propertiesFile.equals("properties")){
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Please Provide Exact " + "\"." + "properties\" File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.exit(1);
		}
		else{
			Properties properties = new Properties();
			InputStream input = null;
			try {
	    		input = new FileInputStream(hostNameFilePath);
				properties.load(input);
				//System.out.println("input: " + input);
				Enumeration<?> e = properties.propertyNames();
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					String value = properties.getProperty(key);
					hostNamePropertiesMap.put(key, value);
					//System.out.println("Key : " + key + ", Value : " + value);
				}
				if(hostNamePropertiesMap.size()!=0){
					//readProperties = true;
				}else{
					System.out.println();
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.out.println("Given Propertie file Not Containing any Base Details/NoData ...!");
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.exit(1);
				}
			}catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						System.out.println();
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.out.println("No Such File In That Location, Please Provide Exact File Name&Location..!");
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.exit(1);
					}// End Catch
				}// End if input!=null
			}// End finally
		}// End else
	}// End ReadHostNamePropertiesFile
	
	
//	Get Properties values
	public String getPropertyName(String Sterlite_HostName){
		//System.out.println("getPropertyName() Sterlite_HostName: " + Sterlite_HostName);
		String returnValue = null;
		if(hostNamePropertiesMap.containsKey(Sterlite_HostName)){
			//System.out.println("Property Value: " + hostNamePropertiesMap.get(Sterlite_HostName));
			returnValue = hostNamePropertiesMap.get(Sterlite_HostName);
		}
		return returnValue;
	}// End getPropertyName
	
	
//	File Read and Write logic
	public void ReadBaseConfigAndWrite(){
		//Static Base Config file
		InputStream file = BaseConfigAutomation.class.getClassLoader().getResourceAsStream("BaseConfig.txt");
		
	    File outputFile = new File(outputFilePath);
	    outputFile.mkdirs();
        
        FileWriter fr = null;
        BufferedWriter br = null;
        //
        List<String> readedBaseConfigLines = new ArrayList<String>();
        //Read Base Config file and Store it in list readedBaseConfigLines
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(file);
		while (scannerFile.hasNextLine()) {
			readedBaseConfigLines.add(scannerFile.nextLine());
		}
		//System.out.println("readedBaseConfigLines: " + readedBaseConfigLines.size());
		try {
			// Output File name Sterlite_NAS_Identifier
			String NAME_NAS_IDENTIFIER = getPropertyName("Sterlite_NAS_Identifier");
			fr = new FileWriter(outputFile + "\\BaseConfig_" + NAME_NAS_IDENTIFIER+".txt");
			//System.out.println("try outputFilePath: " + outputFile + " : " + NAME_NAS_IDENTIFIER);
			br = new BufferedWriter(fr);
			//Read Lines from list of base config
			for(String s: readedBaseConfigLines){
				if(s.contains("Sterlite_HostName")){
					String lineWord1 = getPropertyName("Sterlite_HostName");
					s = s.replace("Sterlite_HostName", lineWord1);
					//System.out.println("Sterlite_HostName: " + s);
				}
				if(s.contains("Sterlite_Name_Server1")){
					String lineWord1 = getPropertyName("Sterlite_Name_Server1");
					s = s.replace("Sterlite_Name_Server1", lineWord1);
					//System.out.println("Sterlite_Name_Server1: " + s);
				}
				if(s.contains("Sterlite_Name_Server2")){
					String lineWord1 = getPropertyName("Sterlite_Name_Server2");
					s = s.replace("Sterlite_Name_Server2", lineWord1);
					//System.out.println("Sterlite_Name_Server2: " + s);
				}
				if(s.contains("Sterlite_MGMT_RILOOPBACK_ADDRESS")){
					String lineWord1 = getPropertyName("Sterlite_MGMT_RILOOPBACK_ADDRESS");
					s = s.replace("Sterlite_MGMT_RILOOPBACK_ADDRESS", lineWord1);
					//System.out.println("Sterlite_MGMT_RILOOPBACK_ADDRESS: " + s);
				}
				if(s.contains("Sterlite_NTPServer_ip")){
					String lineWord1 = getPropertyName("Sterlite_NTPServer_ip");
					s = s.replace("Sterlite_NTPServer_ip", lineWord1);
					//System.out.println("Sterlite_NTPServer_ip: " + s);
				}
				if(s.contains("Sterlite_BSNL.in_RILOOPBACK_ADDRESS")){
					String lineWord1 = getPropertyName("Sterlite_BSNL.in_RILOOPBACK_ADDRESS");
					s = s.replace("Sterlite_BSNL.in_RILOOPBACK_ADDRESS", lineWord1);
					//System.out.println("Sterlite_BSNL.in_RILOOPBACK_ADDRESS: " + s);
				}
				if(s.contains("Sterlite_LB_Radius_Server1")){
					String lineWord1 = getPropertyName("Sterlite_LB_Radius_Server1");
					s = s.replace("Sterlite_LB_Radius_Server1", lineWord1);
					//System.out.println("Sterlite_LB_Radius_Server1: " + s);
				}
				if(s.contains("Sterlite_LB_Radius_Server2")){
					String lineWord1 = getPropertyName("Sterlite_LB_Radius_Server2");
					s = s.replace("Sterlite_LB_Radius_Server2", lineWord1);
					//System.out.println("Sterlite_LB_Radius_Server2: " + s);
				}
				if(s.contains("Sterlite_NAS_Identifier")){
					String lineWord1 = getPropertyName("Sterlite_NAS_Identifier");
					s = s.replace("Sterlite_NAS_Identifier", lineWord1);
					//System.out.println("Sterlite_NAS_Identifier: " + s);
				}
				if(s.contains("Sterlite_LOCAL_LOOPBACK_ADDRESS")){
					String lineWord1 = getPropertyName("Sterlite_LOCAL_LOOPBACK_ADDRESS");
					s = s.replace("Sterlite_LOCAL_LOOPBACK_ADDRESS", lineWord1);
					//System.out.println("Sterlite_LOCAL_LOOPBACK_ADDRESS: " + s);
				}
				if(s.contains("Sterlite_Primary_PcrfIP")){
					String lineWord1 = getPropertyName("Sterlite_Primary_PcrfIP");
					s = s.replace("Sterlite_Primary_PcrfIP", lineWord1);
					//System.out.println("Sterlite_Primary_PcrfIP: " + s);
				}
				if(s.contains("Sterlite_Secondry_PcrfIp")){
					String lineWord1 = getPropertyName("Sterlite_Secondry_PcrfIp");
					s = s.replace("Sterlite_Secondry_PcrfIp", lineWord1);
					//System.out.println("Sterlite_Secondry_PcrfIp: " + s);
				}
				if(s.contains("Sterlite_Primary_OCSIP")){
					String lineWord1 = getPropertyName("Sterlite_Primary_OCSIP");
					s = s.replace("Sterlite_Primary_OCSIP", lineWord1);
					//System.out.println("Sterlite_Primary_OCSIP: " + s);
				}
				if(s.contains("Sterlite_Secondry_OCSIP")){
					String lineWord1 = getPropertyName("Sterlite_Secondry_OCSIP");
					s = s.replace("Sterlite_Secondry_OCSIP", lineWord1);
					//System.out.println("Sterlite_Secondry_OCSIP: " + s);
				}
				if(s.contains("Sterlite_BGP_AS_NO")){
					String lineWord1 = getPropertyName("Sterlite_BGP_AS_NO");
					s = s.replace("Sterlite_BGP_AS_NO", lineWord1);
					//System.out.println("Sterlite_BGP_AS_NO: " + s);
				}
				if(s.contains("Sterlite_Local_RI_1_Interface")){
					String lineWord1 = getPropertyName("Sterlite_Local_RI_1_Interface");
					s = s.replace("Sterlite_Local_RI_1_Interface", lineWord1);
					//System.out.println("Sterlite_Local_RI_1_Interface: " + s);
				}
				if(s.contains("Sterlite_Local_RI_1_Vlan")){
					String lineWord1 = getPropertyName("Sterlite_Local_RI_1_Vlan");
					s = s.replace("Sterlite_Local_RI_1_Vlan", lineWord1);
					//System.out.println("Sterlite_Local_RI_1_Vlan: " + s);
				}
				if(s.contains("Sterlite_Local_RI_1_Desc")){
					String lineWord1 = getPropertyName("Sterlite_Local_RI_1_Desc");
					s = s.replace("Sterlite_Local_RI_1_Desc", lineWord1);
					//System.out.println("Sterlite_Local_RI_1_Desc: " + s);
				}
				if(s.contains("Sterlite_Local_RI_1_Interface_Ip_Address")){
					String lineWord1 = getPropertyName("Sterlite_Local_RI_1_Interface_Ip_Address");
					s = s.replace("Sterlite_Local_RI_1_Interface_Ip_Address", lineWord1);
					//System.out.println("Sterlite_Local_RI_1_Interface_Ip_Address: " + s);
				}
				if(s.contains("Sterlite_Local_RI_1_Neighbor")){
					String lineWord1 = getPropertyName("Sterlite_Local_RI_1_Neighbor");
					s = s.replace("Sterlite_Local_RI_1_Neighbor", lineWord1);
					//System.out.println("Sterlite_Local_RI_1_Neighbor: " + s);
				}
				// Write It in File
				br.write(s);
		    	br.write(System.getProperty("line.separator"));
		    	//br.write(System.getProperty("line.separator"));
			}
			
			// loop for more than one interfaces up to 10
			for(int i=2; i<=10; i++){
				String ri = "ri"+i+"Interface";
				String riInterface = ri;
				//System.out.println("riInterface: "+ riInterface);
				//Sterlite_Local_RI_3_Interface, Sterlite_Local_RI_3_Desc, Sterlite_Local_RI_3_Vlan, Sterlite_Local_RI_3_Interface_Ip_Address, Sterlite_Local_RI_3_Neighbor
				riInterface = "Sterlite_Local_RI_"+i+"_Interface";
				String riDesc = "Sterlite_Local_RI_"+i+"_Desc";
				String riVlan = "Sterlite_Local_RI_"+i+"_Vlan";
				String riIpAddress = "Sterlite_Local_RI_"+i+"_Interface_Ip_Address";
				String riNeighbor = "Sterlite_Local_RI_"+i+"_Neighbor";
				String riInterfaceValue = getPropertyName(riInterface);
				//System.out.println(riInterface+ " : " + riDesc + " : " + riVlan + " : " + riIpAddress + " : " + riNeighbor);
				//Sterlite_Local_RI_3_Interface, Sterlite_Local_RI_3_Desc, Sterlite_Local_RI_3_Vlan, Sterlite_Local_RI_3_Interface_Ip_Address, Sterlite_Local_RI_3_Neighbor
				if(riInterfaceValue!=null){
					br.write(System.getProperty("line.separator"));
					String riVlanValue = getPropertyName(riVlan);
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue +  " description  \"" + getPropertyName(riDesc) + "\" " + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " vlan-tagging" + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue + " vlan-id " + riVlanValue + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue +  " family inet address " + getPropertyName(riIpAddress) + "/30" + System.getProperty("line.separator"));
					br.write("set routing-instances local interface " + riInterfaceValue + "." + riVlanValue + System.getProperty("line.separator"));
					br.write("set routing-instances local protocols bgp group local_ebgp neighbor " + getPropertyName(riNeighbor) + System.getProperty("line.separator"));
		        	//br.write(System.getProperty("line.separator"));
		        	riInterfaceValue = null;
				}// End riInterfaceValue!=null
			}//End for loop more interfaces
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try{
				br.close();
		        fr.close();
		        readedBaseConfigLines = null;
		        //ri2Interface = null;
			}catch(Exception e){
				e.printStackTrace();
			}
		}//End Finally 
	}//End ReadBaseConfigAndWrite()
	
	
//	Execute all methods logic 
	//private boolean readProperties = false;
	private String outputFilePath = null;
	private static final DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");//yyyy/MM/dd HH:mm:ss
	public void mainInvokeMethods() {
		outputFilePath = null;
		System.out.println("Provide Base Config Properties File Path Location : ");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
	    String cfgFilePath = scanner.next();
	    System.out.println("Given Base Config Properties FilePath : " + cfgFilePath);
	    ReadHostNamePropertiesFile(cfgFilePath);
	    
	    System.out.println();
	    System.out.println("Provide Output Path Location : ");
		@SuppressWarnings("resource")
		Scanner outputScanner = new Scanner(System.in);
	    outputFilePath = outputScanner.next();
	    Date date = new Date();
	    String todayDate =  sdf.format(date);
	    outputFilePath = outputFilePath+"\\"+todayDate+"_BaseConfig";
	    System.out.println("Given OutPut Path Location : " + outputFilePath);
	    
	    ReadBaseConfigAndWrite();
	    System.out.println();
	    //System.out.println("hostNamePropertiesMap: " + hostNamePropertiesMap);
	}// End mainInvokeMethods
	
	public static void main(String[] args) {
		BaseConfigAutomation baseConfigAutomation = new BaseConfigAutomation();
		baseConfigAutomation.mainInvokeMethods();
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("Successfully Base Config Data Generated ...! ");
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("!...	Thank You	...! ");
	}// End Main

}// End Class
