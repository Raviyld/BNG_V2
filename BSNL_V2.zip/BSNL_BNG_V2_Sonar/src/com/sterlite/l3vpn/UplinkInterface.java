/**
 * 
 */
package com.sterlite.l3vpn;

/**
 * @author ravi.divvela
 *
 */
public class UplinkInterface {
	private String uplink_interface;//interface
	private String uplink_portValue;
	private String uplink_unit_no;//3715
	private String uplink_vlan_id;
	private String wan_ip_address;
	/**
	 * @return the uplink_interface
	 */
	public String getUplink_interface() {
		return uplink_interface;
	}
	/**
	 * @param uplink_interface the uplink_interface to set
	 */
	public void setUplink_interface(String uplink_interface) {
		this.uplink_interface = uplink_interface;
	}
	/**
	 * @return the uplink_portValue
	 */
	public String getUplink_portValue() {
		return uplink_portValue;
	}
	/**
	 * @param uplink_portValue the uplink_portValue to set
	 */
	public void setUplink_portValue(String uplink_portValue) {
		this.uplink_portValue = uplink_portValue;
	}
	/**
	 * @return the uplink_unit_no
	 */
	public String getUplink_unit_no() {
		return uplink_unit_no;
	}
	/**
	 * @param uplink_unit_no the uplink_unit_no to set
	 */
	public void setUplink_unit_no(String uplink_unit_no) {
		this.uplink_unit_no = uplink_unit_no;
	}
	/**
	 * @return the uplink_vlan_id
	 */
	public String getUplink_vlan_id() {
		return uplink_vlan_id;
	}
	/**
	 * @param uplink_vlan_id the uplink_vlan_id to set
	 */
	public void setUplink_vlan_id(String uplink_vlan_id) {
		this.uplink_vlan_id = uplink_vlan_id;
	}
	/**
	 * @return the wan_ip_address
	 */
	public String getWan_ip_address() {
		return wan_ip_address;
	}
	/**
	 * @param wan_ip_address the wan_ip_address to set
	 */
	public void setWan_ip_address(String wan_ip_address) {
		this.wan_ip_address = wan_ip_address;
	}
	//
	public UplinkInterface(String uplink_interface, String uplink_portValue, String uplink_unit_no,	String uplink_vlan_id, String wan_ip_address) {
		this.uplink_interface = uplink_interface;
		this.uplink_portValue = uplink_portValue;
		this.uplink_unit_no = uplink_unit_no;
		this.uplink_vlan_id = uplink_vlan_id;
		this.wan_ip_address = wan_ip_address;
	}
	public UplinkInterface() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UplinkInterface [uplink_interface=" + uplink_interface + ", uplink_portValue=" + uplink_portValue
				+ ", uplink_unit_no=" + uplink_unit_no + ", uplink_vlan_id=" + uplink_vlan_id + ", wan_ip_address="
				+ wan_ip_address + "]";
	}
	
}
