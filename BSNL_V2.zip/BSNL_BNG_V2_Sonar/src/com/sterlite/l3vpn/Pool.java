/**
 * 
 */
package com.sterlite.l3vpn;

import java.io.Serializable;

/**
 * @author ravi.divvela
 *
 */
public class Pool implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ri_name_pool;
	private String ri_address_pool;
	private String ri_pool_first_ip = "";
	private String ri_pool_low = "";
	private String ri_pool_high = "";
//	
	public String getRi_name_pool() {
		return ri_name_pool;
	}
	public void setRi_name_pool(String ri_name_pool) {
		this.ri_name_pool = ri_name_pool;
	}
	public String getRi_address_pool() {
		return ri_address_pool;
	}
	public void setRi_address_pool(String ri_address_pool) {
		this.ri_address_pool = ri_address_pool;
	}
	public String getRi_pool_first_ip() {
		return ri_pool_first_ip;
	}
	public void setRi_pool_first_ip(String ri_pool_first_ip) {
		this.ri_pool_first_ip = ri_pool_first_ip;
	}
	public String getRi_pool_low() {
		return ri_pool_low;
	}
	public void setRi_pool_low(String ri_pool_low) {
		this.ri_pool_low = ri_pool_low;
	}
	public String getRi_pool_high() {
		return ri_pool_high;
	}
	public void setRi_pool_high(String ri_pool_high) {
		this.ri_pool_high = ri_pool_high;
	}
	//	
	public Pool() {
	}
	public Pool(String ri_name_pool, String ri_address_pool, String ri_pool_first_ip, String ri_pool_low,
			String ri_pool_high) {
		super();
		this.ri_name_pool = ri_name_pool;
		this.ri_address_pool = ri_address_pool;
		this.ri_pool_first_ip = ri_pool_first_ip;
		this.ri_pool_low = ri_pool_low;
		this.ri_pool_high = ri_pool_high;
	}
	@Override
	public String toString() {
		return "Pool [ri_name_pool=" + ri_name_pool + ", ri_address_pool=" + ri_address_pool + ", ri_pool_first_ip="
				+ ri_pool_first_ip + ", ri_pool_low=" + ri_pool_low + ", ri_pool_high=" + ri_pool_high + "]";
	}
	
}
