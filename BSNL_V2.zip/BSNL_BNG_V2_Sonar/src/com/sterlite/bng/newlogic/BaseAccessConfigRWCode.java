/**
 * 
 */
package com.sterlite.bng.newlogic;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.sterlite.bng.access.bo.ColonAccessData;
import com.sterlite.bng.access.bo.OnDemandAccessData;
import com.sterlite.bng.access.bo.SingleAccessData;
import com.sterlite.bng.access.bo.VoipCdotAccessData;
import com.sterlite.bng.access.bo.WifiAccessData;
import com.sterlite.l3vpn.Pool;
import com.sterlite.l3vpn.SubnetIpAddressUtils;
import com.sterlite.l3vpn.UplinkInterface;

/**
 * @author ravi.divvela
 *
 */
public class BaseAccessConfigRWCode {
	/**
	 * @param args
	 */
	private static Logger log = Logger.getLogger(BaseAccessConfigRWCode.class);
	private static String drawLine = "---------- ---------- ---------- ---------- ---------- ---------- ----------";
// 	All methods handling this method only
	private String hostName;
	public void mainInvokeMethod(String inputPropertiesPath, String configurationFilePath){
		log.info("MainInvokeMethod Method Started:");
		//Read input properties file data
		hostName = null;
		readInputPropertiesFile(inputPropertiesPath);
		hostName = getPropertyName("Sterlite_HostName");
		log.info("HostName: " + hostName);
		
	//Base configuration Flow start
		log.info("Base Configuration Starts");
		// Find output path location @ reading input file: java 8 
		String outPutPath = outputPropertiesMap.entrySet().stream().filter(map -> "Output_Path".equals(map.getKey())).map(map -> map.getValue()).collect(Collectors.joining());
	    Date date = new Date();
	    String todayDate = new SimpleDateFormat("dd-MM-yyyy").format(date);
	    outPutPath = outPutPath + "\\" + todayDate + "\\";
	    log.info("Output Path: " + outPutPath);
	    File outPutFile = new File(outPutPath);
	    outPutFile.mkdirs();
	    try {
	    	//File Created at the location
			fr = new FileWriter(outPutPath + "\\" + hostName + "_" + todayDate +".txt");
		} catch (IOException e1) {
			log.error("File Creation Catch Block: " + e1);
		}
	    //Read & Write base config data into file
	    br = new BufferedWriter(fr);
	    readBaseConfigAndWrite();
	    log.info("");
	    log.info("Base Configuration Read & Write Flow Ends");
	    log.info("'" + drawLine + "'");
	    log.info("Successfully Base Configuration Data Generated ...! ");
	    log.info("'" + drawLine + "'");
	    log.info("");
    //Base Configuration Flow End
		
    //Access Flow Start
		log.info("Access Flow Starts");
		readCFgTxt = false;
		//Read configuration data and added in map(readedCFGLines)
	    readCFgTxt = readCFGLines(configurationFilePath);
	    if(readCFgTxt){
			getPortToPortEthernetLineNo();
			getContextToContextLineNo();
			Set<Entry<String, String>> downlinkEntries = downlinkPropertiesMap.entrySet();
			for (Entry<String, String> downlinkEntry: downlinkEntries) {
				String portEthernet = (String) downlinkEntry.getKey();// get the portEthernet value from properties file
				portEthernet = portEthernet.replace("Downlink_", "");
				fileNamePortEthernetValue = (String) downlinkEntry.getValue();
				String newPortEthernet = portEthernet.replace("_", " ");
				// Ethernet name as file name convert with.(/)
				for(Map.Entry<Integer, String> e: portEthernetsWithLineNo.entrySet()){
					String entrySetPort = e.getValue();
					if(entrySetPort.equals(newPortEthernet)){
						readWithInPortEthernet(newPortEthernet, e.getKey());
						writeDataInFile();
						dot1qPVCSingleList = new ArrayList<>();
						dot1qPVCOnDemandList = new ArrayList<>();
						colonAccessDataList = new ArrayList<>();
						voipCdotAccessDataList = new ArrayList<>();
						dot1qPVCProfileList = new ArrayList<>();
						wifiAccessDataList = new ArrayList<>();
					}
				}// End for portEthernetsWithLineNo
			}// End if readProperties
			log.info("");
		    log.info("'" + drawLine + "'");
		    log.info("Successfully Access Data Generated ...! ");
		    log.info("'" + drawLine + "'");
		    log.info("Access Read & Write Flow Ends");
		    log.info("");
    //Access Flow End
		    
    //L3VPN Flow Start
		readL3vpnTextFile();
		writeL3vpnData();
	//L3VPN Flow End
		//MGMT logic Starts
			readMgmtTextFile();
			writeMgmtData();
		//MGMT logic End
		//BSNL.IN Logic Starts
			readBsnlInTextFile();
			writeBsnlInData();
		//BSNL.IN Logic Ends
		//voip-cdot Logic Starts
			readVoipCdotTextFile();
			writeVoipCdotData();
		//voip-cdot Logic Ends
		//WIFI-Offload Logic Starts
			readWifiOffloadTextFile();
			writeWifiOffloadData();
		//WIFI-Offload Logic Ends
		//Wifi-Data Logic Starts
			readWifiDataTextFile();
			writeWifiDataData();
		//Wifi-Data Logic Ends
		//Prepaid Logic Starts
			readPrepaidTextFile();
			writePrepaidData();
		//Prepaid Logic Ends
		//ftth.lfmt.in Logic Starts
			readedFtthLfmtInTextFile();
			writeFtthLfmtInData();
		//ftth.lfmt.in Logic Ends
		//ftth.bsnl.in Logic Starts
			readedFtthBsnlInTextFile();
			writeFtthBsnlInData();
		//ftth.bsnl.in Logic Ends
		//wifi-mgmt Logic Starts
			readedWifiMgmtTextFile();
			writeWifiMgmtData();
		//wifi-mgmt Logic Ends
		//bb-ill Logic Starts
			readedBbIllTextFile();
			writeBbIllData();
		//bb-ill Logic Ends
		//BWSP-WIFI Logic Starts: 19-6-19
			readedBWSPWIFITextFile();
			writeBwspWifiData();
		//BWSP-WIFI Logic Ends
		//NOFN Logic Starts: 20-6-19
			readedNofnTextFile();
			writeNofnData();
		//NOFN Logic Ends
		//bbnlinband-ll Logic Starts
			readedBbnlinbandllTextFile();
			writeBbnlinbandllData();
		//bbnlinband-ll Logic Ends
		//iptax Logic Starts
			readedIptaxTextFile();
			writeIptaxData();
		//iptax Logic Ends	
			
		//iptax-mgmt Logic Starts: 21-6-19
			readedIptaxMgmtTextFile();
			writeIptaxMgmtData();
		//iptax-mgmt Logic Ends
			
		//l2tpvpn Logic Starts
			contexts.forEach(context -> {
				if("l2tpvpn".equals(context)){
					readedL2tpvpnTextFile();
					writeL2tpvpnData();
				}
			} );  
		//l2tpvpn Logic Ends	
			
			
			log.info("");
		    log.info("'" + drawLine + "'");
		    log.info("Successfully L3VPN Data Generated ...! ");
		    log.info("'" + drawLine + "'");
		    log.info("L3VPN Read & Write Flow Ends");
		    log.info("");
		}//End if readCFgTxt = true
	    try {
            br.close();
            fr.close();
            log.info("Buffered Writer & File Writer Closed. ");
        } catch (IOException e) {
        	log.error("File Close Catch Block: " + e);
        }//end Catch br.close
	
	}//End mainInvokeMethod()
	
//			**********************************				//
	
	//Input values stores @ below maps
	private Map<String, String> baseConfigPropertiesMap = new HashMap<>();
	private Map<String, String> downlinkPropertiesMap = new HashMap<>();
	private Map<String, String> uplinkPropertiesMap = new HashMap<>();
	private Map<String, String> outputPropertiesMap = new HashMap<>();
	File file;
    FileWriter fr = null;
    BufferedWriter br = null;
    private Properties properties = new Properties();
	private InputStream inputStream;
 
    public void readInputPropertiesFile(String inputPropertiesPath){
		try {
			log.info("Reading InputPath File... " + inputPropertiesPath);
    		inputStream = new FileInputStream(inputPropertiesPath);
			properties.load(inputStream);
			Enumeration<?> e = properties.propertyNames();
			if(e.hasMoreElements()){
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					String value = properties.getProperty(key);
					if(key.contains("Sterlite_")){
						baseConfigPropertiesMap.put(key, value);
					}
					if(key.contains("Downlink_")){
						downlinkPropertiesMap.put(key, value);
					}
					if(key.contains("Uplink_")){
						uplinkPropertiesMap.put(key, value);
					}
					if(key.contains("Output_Path")){
						outputPropertiesMap.put(key, value);
					}
				}//End while 
			}
			else{
				log.info("");
			    log.info("'" + drawLine + "'");
			    log.info("Given Propertie file Not Containing any Details/NoData ...!");
			    log.info("'" + drawLine + "'");
				System.exit(1);
			}
			log.info("End Reading InputPath File...  ");
		}catch (IOException ex) {
			log.error("Input Properties Read Catch Block: " + ex);
		} 
		finally {
			if (inputStream != null) {
				try {
					log.info("Input Properties Read Finally Close Block.");
					inputStream.close();
				} catch (IOException e) {
					log.info("");
				    log.info("'" + drawLine + "'");
				    log.info("No Such Propertie File In That Location, Please Provide Exact File Name&Location..!");
				    log.info("'" + drawLine + "'");
				    
					System.exit(1);
				}// End Catch
			}// End if input!=null
		}// End finally
	}// End ReadHostNamePropertiesFile

    
//			**********************************				//
    
//	******** Base Configuration 	********	//
//	Return Base Properties value
	public String getPropertyName(String sterliteBasePropertyKey){
		String returnValue = null;
		if(baseConfigPropertiesMap.containsKey(sterliteBasePropertyKey)){
			returnValue = baseConfigPropertiesMap.get(sterliteBasePropertyKey);
		}
		return returnValue;
	}// End getPropertyName()
	
//			**********************************				//
	
//	File Read and Write logic for Base Configuration
	public void readBaseConfigAndWrite(){
		
		log.info("Starts Read Base Configuration And Write");
		inputStream = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("BaseConfig.txt");
	    List<String> readedBaseConfigLines = new ArrayList<>();
	    //Read Base Configuration file and Store it in list@ readedBaseConfigLines
		Scanner scannerFile = new Scanner(inputStream);
		while (scannerFile.hasNextLine()) {
			readedBaseConfigLines.add(scannerFile.nextLine());
		}
		log.info("Base Configuration Text Lines: " + readedBaseConfigLines.size());
		try {
			//Read Lines one by one from list of base Configuration
			for(String s: readedBaseConfigLines){
				if(s.contains("Sterlite_HostName")){
					s = s.replace("Sterlite_HostName", getPropertyName("Sterlite_HostName"));
				}
				if(s.contains("Sterlite_Name_Server1")){
					s = s.replace("Sterlite_Name_Server1", getPropertyName("Sterlite_Name_Server1"));
				}
				if(s.contains("Sterlite_Name_Server2")){
					s = s.replace("Sterlite_Name_Server2", getPropertyName("Sterlite_Name_Server2"));
				}
				if(s.contains("Sterlite_MGMT_RILOOPBACK_ADDRESS")){
					s = s.replace("Sterlite_MGMT_RILOOPBACK_ADDRESS", getPropertyName("Sterlite_MGMT_RILOOPBACK_ADDRESS"));
				}
				if(s.contains("Sterlite_NTPServer_ip")){
					s = s.replace("Sterlite_NTPServer_ip", getPropertyName("Sterlite_NTPServer_ip"));
				}
				if(s.contains("Sterlite_BSNL.in_RILOOPBACK_ADDRESS")){
					s = s.replace("Sterlite_BSNL.in_RILOOPBACK_ADDRESS", getPropertyName("Sterlite_BSNL.in_RILOOPBACK_ADDRESS"));
				}
				if(s.contains("Sterlite_LB_Radius_Server1")){
					s = s.replace("Sterlite_LB_Radius_Server1", getPropertyName("Sterlite_LB_Radius_Server1"));
				}
				if(s.contains("Sterlite_LB_Radius_Server2")){
					s = s.replace("Sterlite_LB_Radius_Server2", getPropertyName("Sterlite_LB_Radius_Server2"));
				}
				if(s.contains("sterlite_NAS_Identifier")){
					s = s.replace("Sterlite_NAS_Identifier", getPropertyName("Sterlite_NAS_Identifier"));
				}
				if(s.contains("Sterlite_LOCAL_LOOPBACK_ADDRESS")){
					s = s.replace("Sterlite_LOCAL_LOOPBACK_ADDRESS", getPropertyName("Sterlite_LOCAL_LOOPBACK_ADDRESS"));
				}
				if(s.contains("Sterlite_Primary_PcrfIP")){
					s = s.replace("Sterlite_Primary_PcrfIP", getPropertyName("Sterlite_Primary_PcrfIP"));
				}
				if(s.contains("Sterlite_Secondry_PcrfIp")){
					s = s.replace("Sterlite_Secondry_PcrfIp", getPropertyName("Sterlite_Secondry_PcrfIp"));
				}
				if(s.contains("Sterlite_Primary_OCSIP")){
					s = s.replace("Sterlite_Primary_OCSIP", getPropertyName("Sterlite_Primary_OCSIP"));
				}
				if(s.contains("Sterlite_Secondry_OCSIP")){
					s = s.replace("Sterlite_Secondry_OCSIP", getPropertyName("Sterlite_Secondry_OCSIP"));
				}
				if(s.contains("Sterlite_BGP_AS_NO")){
					s = s.replace("Sterlite_BGP_AS_NO", getPropertyName("Sterlite_BGP_AS_NO"));
				}
				if(s.contains("Sterlite_Local_RI_1_Interface")){
					s = s.replace("Sterlite_Local_RI_1_Interface", getPropertyName("Sterlite_Local_RI_1_Interface"));
				}
				if(s.contains("Sterlite_Local_RI_1_Vlan")){
					s = s.replace("Sterlite_Local_RI_1_Vlan", getPropertyName("Sterlite_Local_RI_1_Vlan"));
				}
				if(s.contains("Sterlite_Local_RI_1_Desc")){
					s = s.replace("Sterlite_Local_RI_1_Desc", getPropertyName("Sterlite_Local_RI_1_Desc"));
				}
				if(s.contains("Sterlite_Local_RI_1_Interface_Ip_Address")){
					s = s.replace("Sterlite_Local_RI_1_Interface_Ip_Address", getPropertyName("Sterlite_Local_RI_1_Interface_Ip_Address"));
				}
				if(s.contains("Sterlite_Local_RI_1_Neighbor")){
					s = s.replace("Sterlite_Local_RI_1_Neighbor", getPropertyName("Sterlite_Local_RI_1_Neighbor"));
				}
				// Write It in File
				br.write(s);
		    	br.write(System.getProperty("line.separator"));
			}//End for readedBaseConfigLines 
			 
			// loop for more than one interfaces up to 10
			for(int i=2; i<=10; i++){
				String ri = "ri"+i+"Interface";
				String riInterface = ri;
				//Sterlite_Local_RI_3_Interface, Sterlite_Local_RI_3_Desc, Sterlite_Local_RI_3_Vlan, Sterlite_Local_RI_3_Interface_Ip_Address, Sterlite_Local_RI_3_Neighbor
				riInterface = "Sterlite_Local_RI_"+i+"_Interface";
				String riDesc = "Sterlite_Local_RI_"+i+"_Desc";
				String riVlan = "Sterlite_Local_RI_"+i+"_Vlan";
				String riIpAddress = "Sterlite_Local_RI_"+i+"_Interface_Ip_Address";
				String riNeighbor = "Sterlite_Local_RI_"+i+"_Neighbor";
				String riInterfaceValue = getPropertyName(riInterface);
				//Sterlite_Local_RI_3_Interface, Sterlite_Local_RI_3_Desc, Sterlite_Local_RI_3_Vlan, Sterlite_Local_RI_3_Interface_Ip_Address, Sterlite_Local_RI_3_Neighbor
				if(riInterfaceValue!=null){
					br.write(System.getProperty("line.separator"));
					String riVlanValue = getPropertyName(riVlan);
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue +  " description  \"" + getPropertyName(riDesc) + "\" " + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " vlan-tagging" + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue + " vlan-id " + riVlanValue + System.getProperty("line.separator"));
					br.write("set interfaces " + riInterfaceValue + " unit " + riVlanValue +  " family inet address " + getPropertyName(riIpAddress) + "/30" + System.getProperty("line.separator"));
					br.write("set routing-instances local interface " + riInterfaceValue + "." + riVlanValue + System.getProperty("line.separator"));
					br.write("set routing-instances local protocols bgp group local_ebgp neighbor " + getPropertyName(riNeighbor) + System.getProperty("line.separator"));
		        	riInterfaceValue = null;
				}// End riInterfaceValue!=null
			}//End for loop more interfaces
			log.info("Ends Read Base Configuration And Write");
		} catch (IOException e) {
			log.error("Base Configuration Read And Wirte Catch: " +e);
		}
		finally {
			if (inputStream != null) {
				try {
					log.info("Base Configuration inputStream Close.");
					inputStream.close();
				} catch (IOException e) {
					log.info("");
				    log.info("'" + drawLine + "'");
				    log.info("No Such Propertie File In That Location, Please Provide Exact File Name&Location..!");
				    log.info("'" + drawLine + "'");
				    
					System.exit(1);
				}// End Catch
			}// End if input!=null
		}
	}//End ReadBaseConfigAndWrite()
	
//	******** Base Configuration End	********	//
	
//			**********************************				//
	
//	******** Access Start	********	//	
//	Variables
	private boolean readCFgTxt = false;
	private boolean domainOperationIn = false;
	
	private String fileNamePortEthernetValue = null;
	private String loopBack = "";
	private String outerUnitNo = null;
	private String bindValue = null;
	private String innerUnitStart = null;
	private String innerUnitStop = null;
	private String singleContextName = null;
	private String bindIpAddress = null;
	private String pppoeOuterUnitNo = null; 
	private Integer ppoeInnerUnitStart;
	private Integer ppoeInnerUnitStop;
	private String colonContextName;
	private String sourceIpHost;
	private String voipOuterVlanNo = null;
	private String voipInnerVlan = null;
	private Integer voipUnitNo = 0;
	private String voipIpAddress = null;
	private String wifiVlanNo = null;
	private String wifiInterfaceIp = null;
	private String ppbbIpAddress;
	
	// Static variables
	private static final String NAME_DOT1Q = "dot1q";
	private static final String NAME_PVC = "pvc";
	private static final String NAME_DESCRIPTION = "description";
	private static final String NAME_STARS = "***";
	private static final String NAME_BIND = "bind";
	private static final String NAME_ONDEMAND = "on-demand";
	private static final String NAME_INTERFACE = "interface";
	private static final String NAME_IP = "ip";
	private static final String NAME_HOST = "host";
	private static final String NAME_ADDRESS = "address";
	private static final String NAME_VOIP_CDOT = "voip-cdot";
	private static final String NAME_PROFILE = "profile";
	private static final String NAME_QOS_MAP = "qos-map";
	private static final String NAME_ENCAPSULATION = "encapsulation";
	private static final String NAME_PPPOE = "pppoe";
	private static final String NAME_SET_INTERFACES = "set interfaces";
	private static final String NAME_UNIT = " unit ";
	private static final String NAME_VLAN_ID = " vlan-id ";
	private static final String NAME_FAMILY_INET_ADDRESS = " family inet address ";
	private static final String NAME_AUTO_CONFIGURE = " auto-configure stacked-vlan-ranges dynamic-profile VLAN-DEMUX ranges ";
	private static final String NAME_VLAN_TAGS_OUTER = " vlan-tags outer ";
	private static final String NAME_VLAN_TAGS_INNER = " vlan-tags inner ";
	private static final String NAME_FAMILY_INET_UNNUMBERED_ADDRESS = " family inet unnumbered-address ";
	private static final String NAME_PREFERRED_SOURCE = "preferred-source-address ";
	private static final String NAME_SET_ROUTING_INSTANCES = "set routing-instances ";
	private static final String NAME_ROUTING_OPTIONS = "routing-options static route ";
	private static final String NAME_BRIDGE_DOMAINS = "set bridge-domains ";
	private static final String NAME_DOMAIN_TYPE_BRIDGE = "domain-type bridge";
	private static final String NAME_ROUTING_INTERFACE = " routing-interface ";
	private static final String NAME_ENCAPSULATION_VLAN_BRIDGE = " encapsulation vlan-bridge";
	private static final String NAME_FAMILY_BRIDGE = " family bridge";
	private static final String NAME_FAMILY_PPPOE = "family pppoe duplicate-protection";
	private static final String NAME_FAMILY_PPPOE_DYNAMIC = "family pppoe dynamic-profile PPPOE";
	private static final String NAME_PORT = "port";
	private static final String NAME_ETHERNET = "ethernet";
	private static final String NAME_CONTEXT = "context";
	private static final String NAME_ROUTER = "router";
	private static final String NAME_BGP = "bgp";
	private static final String NAME_POOL = "pool";
	private static final String NAME_DOMAIN = "domain";
	private static final String NAME_OSPF = "ospf";
	private static final String NAME_ROUTE_MAP = "route-map";
	private static final String NAME_PERMIT = "permit";
	private static final String NAME_PERFIX_LIST = "prefix-list";
	
	
	private List<String> ipHosts = new ArrayList<>();
	private List<String> routeFilters = new ArrayList<>();
	private List<String> mgmtInterfaces = new ArrayList<>();
	private List<String> domains = new ArrayList<>();
	private List<String> bsnlInInterfaces = new ArrayList<>();
	private List<Pool> pools = new ArrayList<>();
	private List<SingleAccessData> dot1qPVCSingleList = new ArrayList<>();
	private List<OnDemandAccessData> dot1qPVCOnDemandList = new ArrayList<>();
	private List<ColonAccessData> colonAccessDataList = new ArrayList<>();
	private List<VoipCdotAccessData> voipCdotAccessDataList = new ArrayList<>();
	private List<String> dot1qPVCProfileList = new ArrayList<>();
	private TreeMap<Integer, String> contextsWithLineNo = new TreeMap<>();
	private List<String> contexts = new ArrayList<>();
	private List<String> l3vpnContexts = new ArrayList<>();
	private TreeMap<Integer, String> portEthernetsWithLineNo = new TreeMap<>();
	private Map<Integer, String> readedCFGLines = new HashMap<>();
	private List<WifiAccessData> wifiAccessDataList = new ArrayList<>();
	private List<String> readedL3vpnLines = new ArrayList<>();
	private List<String> quadWifiIpAddress = new ArrayList<>();
	private List<String> nofnIpAddress = new ArrayList<>();
	private List<String> bbnlinbandllIpAddress = new ArrayList<>();
	//l2tpvpn loopback
	private List<String> l2tpvpnIpAddress = new ArrayList<>();
	private List<String> l2tpvpnLoopbackIpAddress = new ArrayList<>();
	private List<String> l2tpvpnLoopbackBsnlInIpAddress = new ArrayList<>();
	private List<String> staticPoolIpAddress = new ArrayList<>();
	
// 	Read CFG/TXT/LOG file and added each and every line in to Map - readedCFGLines
	public boolean readCFGLines(String cfgFilePath){
		log.info("Read Configuration File Lines...");
		try {
			List<String> allLines = Files.readAllLines(Paths.get(cfgFilePath));
			int i = 0;
			for (String line : allLines) {
				i++;
				readedCFGLines.put(i, line); // Adding each line by line in to map(key is line no, value is line)
			}
			readCFgTxt = true;
			log.info("Readed Configuration File Lines... " + readedCFGLines.size());
			log.info("");
		} catch (IOException e) {
			log.info("");
		    log.info("'" + drawLine + "'");
		    log.info("No Configuration File In That Location, Please Provide Exact File Name&Location..!");
		    log.info("'" + drawLine + "'");
		    
			log.error("Read Configuration File Catch Block: " + e);
			System.exit(1);
		}
		return readCFgTxt;
	}//End readCFGLines()
	
//			**********************************				//
	
// 	Read Configuration for Context to Context Line No's finding
	public void getPortToPortEthernetLineNo(){
		//To find of Port Ethernet in the Configuration file and added it to Map contextsWithLineNo
		log.info("Read Port to Port Ethernet LineNo() Starts"); 
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			int previousLineNo = 0;
			int nextLineNo = 0;
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==3){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(NAME_PORT) && NAME_ETHERNET.equals(currentLineWords[clNo+1])){
						//Swap lineNo's
						if(previousLineNo!=0){
							nextLineNo = previousLineNo;
						}
						previousLineNo = currentLineNo;// Don't change
						previousLineNo = previousLineNo + nextLineNo;
						nextLineNo = previousLineNo - nextLineNo;
						previousLineNo = previousLineNo - nextLineNo;
						portEthernetsWithLineNo.put(nextLineNo, currentLineWords[clNo+1]+ " " + currentLineWords[clNo+2]);
					}// End If Context
				}// End For currentLineWords.length
			}// End If length==2
		}//End For - added map values end
		log.info("Read Port to Port Ethernet LineNo() Ends"); 
	}// END ReadCFGToGetContextLineNo()
	
//			**********************************				//
	
// 	Read CFG GET Context to Context Line No's
	public void getContextToContextLineNo(){
		log.info("Read Context to Context LineNo() Starts"); 
		// To find the number of Contexts in the CFG/TXT file and added it to (contextsWithLineNo - map)
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			int previousLineNo = 0;
			int nextLineNo = 0;
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(NAME_CONTEXT)){
						contexts.add(currentLineWords[clNo+1]);
						//Swap lineNo's
						if(previousLineNo!=0){
							nextLineNo = previousLineNo;
						}
						previousLineNo = currentLineNo;// Don't change
						previousLineNo = previousLineNo + nextLineNo;
						nextLineNo = previousLineNo - nextLineNo;
						previousLineNo = previousLineNo - nextLineNo;
						contextsWithLineNo.put(nextLineNo, currentLineWords[clNo+1]);
					}// End If Context
				}// End For currentLineWords.length
			}// End If length==2
		}// End For - added map values end
		
		//Remove context(local, redirect form contexts list
		//Not in l3vpn service contexts
		List<String> removeContexts = new ArrayList<>(Arrays.asList(
			"3G-Ericsson", "3g-huawei", "bb-ill", "bbnl.in", "bbnlinband-ll", "BBOWIFI", "bsnl.in", "BWSP-Access-Point-Management", "BWSP-WIFI", 
			"ftth.bsnl.in", "ftth.lfmt.in", "iptax", "iptax-mgmt", "iptax-sstp", "iptv-aksh", "l2tpvpn", "mgmt", "ngn-oam", "oam-ngn", "ngn-signal","signal-ngn", 
			"ngn-voip", "NOFN", "ppbb.bsnl.in", "rttc", "vip-cdot", "voip-cdot", "voip-ITI", "voip-ngn", "voip-ngn.in", "voip-sai", "wifi_trimax", 
			"wifi-data", "WIFI-KSITM", "wifi-mgmt", "WIFI-Offload", "wimax", "wimax.cctns.in", "wimax.sbi.in", "wimax-gemini", "wimax-icom", 
			"wimax-icommgmt", "wimaxmgmt", "wimax-vmc", "wimax-vmcmgmt", "redirect", "local", "appolice.gov.in\\", "bsnl.in'", "bsnl20.in", "static", "testems", "vpntest.in" ));
		
		l3vpnContexts.addAll(contexts);
		l3vpnContexts.removeAll(removeContexts);
		
		log.info("Read Context to Context LineNo() Ends");
	}// END ReadCFGToGetContextLineNo()
	
//			**********************************				//
	
// bsnl.in logic (30-6-19)Prefix List to prefix List split
	private TreeMap<Integer, String> ipPrefixListWithLineNo = new TreeMap<>();
	public void getPrefixListToPrefixListLineNo(Integer contextStartNo, Integer contextEndNo){
		log.info("getPrefixListToPrefixListLineNo Starts"); 
		for (int prefixLineNo = contextStartNo; prefixLineNo <= contextEndNo; prefixLineNo++) {
			String currentLine = readedCFGLines.get(prefixLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==4){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(NAME_IP) && currentLineWords[clNo+1].equals(NAME_PREFIXLIST)){
						ipPrefixListWithLineNo.put(prefixLineNo, currentLineWords[clNo+2]);
					}
				}//End for clNo
			}//End if currentLineWords.length
		}//End for prefixLineNo
		log.info("getPrefixListToPrefixListLineNo Ends"); 
	}//End getPrefixListToPrefixListLineNo
	
//	Next PrefixList start No Return
	public Integer getNextPrefixListLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = ipPrefixListWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}// End getNextPrefixListLineNo()
	
//	Read Permit Ip Address with in the PrefixList, endContextLineNo
	public void getPermitIpAddressInPrefixList(String prefixList, Integer endContextLineNo){
		bsnlinSeqPermitList = new ArrayList<>();
		for(Map.Entry<Integer, String> e: ipPrefixListWithLineNo.entrySet()){
			String prefixListValue = e.getValue();
			if(prefixListValue.equals(prefixList)){
				Integer startPrefixLineNo = 0;
				Integer endPrefixLineNo = 0;
				startPrefixLineNo = e.getKey();
				endPrefixLineNo = getNextPrefixListLineNo(startPrefixLineNo);
				if(endPrefixLineNo==0){
					endPrefixLineNo = endContextLineNo;
				}
				
				for(int prefixNo=startPrefixLineNo; prefixNo<endPrefixLineNo; prefixNo++){
					String[] prefixListWords = readedCFGLines.get(prefixNo).split(" ");
					for(int prefixListWordNo=0; prefixListWordNo<prefixListWords.length; prefixListWordNo++){
						String prefixListWord = prefixListWords[prefixListWordNo];
						if(prefixListWord.equals(NAME_SEQ) && prefixListWords[prefixListWordNo+2].equals(NAME_PERMIT) && !prefixListWords[prefixListWordNo+3].equals("0.0.0.0/0")){
							bsnlinSeqPermitList.add(prefixListWords[prefixListWordNo+3]);
						}

					}
				}// End for contextNo
				
			}// End if prefixListValue
			
		}// End for contextsWithLineNo.set
	}// End getIpAddressInContext
	
	
	
	//////////////////////////////
//30-6-19 bsnl.in logic
	
//	LoopBack Details Read from properties file and return context loopBack value
	public String getLoopBackDetails(String contextName){
		try {
    		inputStream = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("LoopBack.properties");
			properties.load(inputStream);
			loopBack = properties.getProperty(contextName);
			if(loopBack==null){
				loopBack="";
			}
		}catch (IOException ex) {
			log.info("Loopback Details Catch Block: " + ex);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					log.info("Loopback Details Finnaly Catch Block: " + e);
				}
			}
		}
		return loopBack;
	}// End getLoopBackDetails()
	
//			**********************************				//
	
//	Next port Ethernet start No Return
	public Integer getNextPortLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = portEthernetsWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}// End getNextPortLineNo()
	
//			**********************************				//
	
//	Next Context start No Return
	public Integer getNextContextLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = contextsWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}// End getNextContextLineNo()
	
//			**********************************				//
	
//	Read With in the Port Ethernet Only
	public void readWithInPortEthernet(String portEthernet, Integer startPortLineNo){
		Integer endPortLineNno = getNextPortLineNo(startPortLineNo); 
		log.info("Read with in Port Ethernet: " + portEthernet + "  -|- startPortLineNo: " + startPortLineNo + " - " + endPortLineNno);
		
		voipUnitNo = 15000;
		// Reading file(readedCFGLines) line by line from portEthernet start lineNo to end lineNo
		for(int inPortNo=startPortLineNo+1; inPortNo <endPortLineNno ; inPortNo++ ){
			String[] inPortWords = readedCFGLines.get(inPortNo).split(" ");
			//CASE-1: 'dot1q pvc 75' Single Value
			if(inPortWords.length==4){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					outerUnitNo = null;
					String inWord = inPortWords[inWordNo];
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1])){
						outerUnitNo = inPortWords[inWordNo+2];
						//Description Reading
						String[] descriptionWords = readedCFGLines.get(inPortNo+1).split(" ");
						StringBuilder tempDescriptionWord = new StringBuilder();
						tempDescriptionWord.append(readedCFGLines.get(inPortNo+1));
						String finalDescriptionWord = null;
						for(int descNo=0; descNo<descriptionWords.length; descNo++){
							String descriptionWord = null;
							String starRemoveWord = descriptionWords[descNo];
							// now find in this words *** also once check and remove *'s
							descriptionWord = starRemoveWord.replace("*", "");
							if(descriptionWord.equals(NAME_DESCRIPTION)){
								tempDescriptionWord = tempDescriptionWord.delete(0, 17);
								finalDescriptionWord = tempDescriptionWord.toString().trim();
							}// End if
						}// End for DescriptionWord
						
						//BindValue read
						String[] bindWords = readedCFGLines.get(inPortNo+2).split(" ");
						for(int bindNo=0; bindNo<bindWords.length; bindNo++){
							String bindWord = bindWords[bindNo];
							if(bindWord.equals(NAME_BIND) && NAME_INTERFACE.equals(bindWords[bindNo+1])){
								bindValue = bindWords[bindNo+2];
								singleContextName = bindWords[bindNo+3];
								bindIpAddress = getIpAddressInContext(bindValue, singleContextName);
							}// End if NAME_BIND, NAME_INTERFACE
						}// End for BindValue read
						
						if(bindIpAddress!=null){
							if(!singleContextName.equals("voip-sai") && !singleContextName.equals("wimax")){
								SingleAccessData singleAccessData = new SingleAccessData(outerUnitNo, finalDescriptionWord, innerUnitStart, innerUnitStop, bindValue, singleContextName, bindIpAddress);
								dot1qPVCSingleList.add(singleAccessData);
							}// End if
						}// End if adding values to dot1qPVCSingleList
						
					}// NAME_DOT1Q, NAME_PVC
					resetVariables();
				}
			}// End If inPortWords.length==4
			
			//CASE-2: 'dot1q pvc on-demand' Values// onDemand value
			else if(inPortWords.length>4){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					pppoeOuterUnitNo = null;
					String inWord = inPortWords[inWordNo];
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) && NAME_ONDEMAND.equals(inPortWords[inWordNo+2])){
						String[] outerUnitNoInnerUnitStart = inPortWords[inWordNo+3].split(":");
						pppoeOuterUnitNo = outerUnitNoInnerUnitStart[0];
						ppoeInnerUnitStart = Integer.parseInt(outerUnitNoInnerUnitStart[1]);
						if(inPortWords[inWordNo+5].equals("vpn") || inPortWords[inWordNo+5].equals("qos-map")){
							ppoeInnerUnitStop = ppoeInnerUnitStart;
						}
						else{
							ppoeInnerUnitStop = Integer.parseInt(inPortWords[inWordNo+5]);
						}
						//pppoeOuterUnitNo, ppoeInnerUnitStart, ppoeInnerUnitStop, finalDescriptionWord, managementVlan, managementVlanIp
						OnDemandAccessData onDemandData = new OnDemandAccessData(pppoeOuterUnitNo, ppoeInnerUnitStart, ppoeInnerUnitStop);
						dot1qPVCOnDemandList.add(onDemandData);
						
					}// End if NAME_DOT1Q, NAME_PVC, NAME_ONDEMAND
					
					resetVariables();
				}
			}//End else if inPortWords.length>4
			
			//CASE-3: dot1q pvc 706 profile qos-map encapsulation pppoe// Profile value
			if(inPortWords.length==8){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					pppoeOuterUnitNo = null;
					String inWord = inPortWords[inWordNo];
					//dot1q pvc 706 profile qos-map encapsulation pppoe
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) 
						&& NAME_PROFILE.equals(inPortWords[inWordNo+3]) && NAME_QOS_MAP.equals(inPortWords[inWordNo+4]) 
						&& NAME_ENCAPSULATION.equals(inPortWords[inWordNo+5]) && NAME_PPPOE.equals(inPortWords[inWordNo+6])){
						dot1qPVCProfileList.add(inPortWords[inWordNo+2]);
					}// End if
				}// End for
			}// End if inPortWords.length==8
			
			//CASE-4: 'dot1q pvc 75:5466' // pvcColonValue
			String finalDescriptionWord = null;
			if(inPortWords.length==5){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					outerUnitNo = null;
					String inWord = inPortWords[inWordNo];
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1])){
						String pvcColonValue = inPortWords[inWordNo+2].trim();
						if(pvcColonValue.contains(":")){
							String[] outerUnitNoInnerUnitStart = pvcColonValue.split(":");
							outerUnitNo = outerUnitNoInnerUnitStart[0];
							innerUnitStart = outerUnitNoInnerUnitStart[1];
							// Context Name
							String[] colonContextWords = readedCFGLines.get(inPortNo+1).split(" ");
							for(int contextNo=0; contextNo<colonContextWords.length; contextNo++){
								String colonContextWord = colonContextWords[contextNo];
								if(colonContextWord.equals(NAME_BIND) && NAME_INTERFACE.equals(colonContextWords[contextNo+1]) && !NAME_VOIP_CDOT.equals(colonContextWords[contextNo+3])){ 
									colonContextName = colonContextWords[contextNo+3];
								}// End if NAME_BIND, NAME_INTERFACE
							}// End for Context Name
							
							//IP host
							int n = inPortNo+2;
							for(int r=inPortNo+2; r<=n; r++){
								String[] ipHostNextWords = readedCFGLines.get(r).split(" ");
								for(int ipHostNextNo=0; ipHostNextNo<ipHostNextWords.length; ipHostNextNo++){
									String ipHostNextWord = ipHostNextWords[ipHostNextNo];
									if(ipHostNextWord.equals(NAME_IP) && NAME_HOST.equals(ipHostNextWords[ipHostNextNo+1])){
										String ipHostNext = ipHostNextWords[ipHostNextNo+2];
										ipHosts.add(ipHostNext);
										String subLow = ipHostNext.substring(0, ipHostNext.lastIndexOf('.'));
										sourceIpHost = subLow+"."+"1";
										n++;
									}// End if NAME_IP, NAME_HOST
								}// End for ipHostNextWords.lenght
							}// End for inPortNo
							
							//Description Reading
							String[] descriptionWords = readedCFGLines.get(inPortNo-4).split(" ");
							StringBuilder tempDescriptionWord = new StringBuilder();
							tempDescriptionWord.append(readedCFGLines.get(inPortNo-4));
							for(int descNo=0; descNo<descriptionWords.length; descNo++){
								String descriptionWord = null;
								String starRemoveWord = descriptionWords[descNo];
								// now find in this words *** also once check and remove *'s
								descriptionWord = starRemoveWord.replace("*", "");
								if(descriptionWord.equals(NAME_DESCRIPTION) && NAME_STARS.equals(descriptionWords[descNo+1])){
									tempDescriptionWord = tempDescriptionWord.delete(0, 17);
									finalDescriptionWord = tempDescriptionWord.toString().substring(0, tempDescriptionWord.length()-3).trim();
								}// End if NAME_DESCRIPTION, NAME_STARS
							}// End for DescriptionWord
						}// End if pvcColonValue(:)
						// Description null
						if(finalDescriptionWord==null){
							finalDescriptionWord = "connectivity towards " + outerUnitNo;
						}
						// Adding values in to list of colonAccessDataList
						if(finalDescriptionWord!=null && ipHosts!=null && colonContextName!=null){
							String loopBackValue = getLoopBackDetails(colonContextName);
							ColonAccessData colonAccessData = new ColonAccessData(outerUnitNo, finalDescriptionWord, innerUnitStart, colonContextName, sourceIpHost, loopBackValue, ipHosts );
							colonAccessDataList.add(colonAccessData);
						}// End if adding colonAccessDataList
						
					}// End if NAME_DOT1Q, NAME_PVC
					resetVariables();
				}
			}// End if inPortWords.length==5
			
			//CASE-5: voip-cdot values
			if(inPortWords.length==5){
				String[] voipCdotWords = readedCFGLines.get(inPortNo+1).split(" ");
				for(int voipNo=0; voipNo<voipCdotWords.length; voipNo++){
					
					String voipCdotWord = voipCdotWords[voipNo];
					if(voipCdotWord.equals(NAME_BIND) && NAME_INTERFACE.equals(voipCdotWords[voipNo+1]) && NAME_VOIP_CDOT.equals(voipCdotWords[voipNo+3]) ){ 
						String[] voipCdotDot1qPvcWords = readedCFGLines.get(inPortNo).split(" ");
						for(int pvcNo=0; pvcNo<voipCdotDot1qPvcWords.length; pvcNo++){
							String voipCdotDot1qPvcWord = voipCdotDot1qPvcWords[pvcNo];
							if(voipCdotDot1qPvcWord.equals(NAME_DOT1Q) && NAME_PVC.equals(voipCdotDot1qPvcWords[pvcNo+1])){
								String pvcColonValue = voipCdotDot1qPvcWords[pvcNo+2].trim();
								if(pvcColonValue.contains(":")){
									String[] outerUnitNoInnerUnitStart = pvcColonValue.split(":");
									voipOuterVlanNo = outerUnitNoInnerUnitStart[0];
									voipInnerVlan = outerUnitNoInnerUnitStart[1];
									voipIpAddress = getIpAddressInContext(voipCdotWords[voipNo+2], voipCdotWords[voipNo+3]);
									
									VoipCdotAccessData voipCdotAccessData = new VoipCdotAccessData(voipOuterVlanNo, voipInnerVlan, voipUnitNo, voipIpAddress, voipInnerVlan);
									voipCdotAccessDataList.add(voipCdotAccessData);
									voipUnitNo++;
								}// End if contains : 
							
							}// End if NAME_DOT1Q, NAME_PVC
						}// End for voipCdotDot1qPvcWords
					}// End if name_bind, name_interface, name_voip_cdot
					
					resetVariables();
				}// End for voipNo
			}//End if inPortWords.length==5
			
			//CASE-6: WIFI-Offload [dot1q pvc 4066 profile qos-map] 
			if(inPortWords.length>5){
				for(int inWordNo=0; inWordNo<inPortWords.length; inWordNo++){
					wifiVlanNo = null;
					wifiInterfaceIp = null;
					String inWord = inPortWords[inWordNo];
					if(inWord.equals(NAME_DOT1Q) && NAME_PVC.equals(inPortWords[inWordNo+1]) && NAME_PROFILE.equals(inPortWords[inWordNo+3])/* && NAME_QOS_MAP.equals(inPortWords[inWordNo+4])*/ ){
						wifiVlanNo = inPortWords[inWordNo+2];
						//BindValue read
						String[] bindWords = readedCFGLines.get(inPortNo+2).split(" ");
						for(int bindNo=0; bindNo<bindWords.length; bindNo++){
							String bindWord = bindWords[bindNo];
							if(bindWord.equals(NAME_BIND) && NAME_INTERFACE.equals(bindWords[bindNo+1])){
								String wifiBindValue = bindWords[bindNo+2];
								String wifiContextName = bindWords[bindNo+3];
								wifiInterfaceIp = getIpAddressInContext(wifiBindValue, wifiContextName);
								WifiAccessData wifiAccessData = new WifiAccessData(wifiVlanNo, wifiInterfaceIp, wifiContextName);
								wifiAccessDataList.add(wifiAccessData);
							}
						}// End for BindValue read
					}// End if NAME_DOT1Q, NAME_PVC, NAME_PROFILE
				}// End For inWords
			}// End if inPortWords.length>4
		}// End if inPortNo
		log.info("Read with in Port Ethernet End " );
	}// End ReadMapWithInPortEthernet()
	
//			**********************************				//
	
//	Read IP Address with in the Context
	public String getIpAddressInContext(String bindValue, String contextName){
		String tempBindIpAddress = null;
		for(Map.Entry<Integer, String> e: contextsWithLineNo.entrySet()){
			String context = e.getValue();
			if(context.equals(contextName)){
				Integer startContextLineNo = 0;
				Integer endContextLineNo = 0;
				startContextLineNo = e.getKey();
				endContextLineNo = getNextContextLineNo(startContextLineNo);
				for(int contextNo=startContextLineNo; contextNo<endContextLineNo; contextNo++){
					String[] interfaceIpWords = readedCFGLines.get(contextNo).split(" ");
					for(int interfaceNo=0; interfaceNo<interfaceIpWords.length; interfaceNo++){
						String interfaceIpWord = interfaceIpWords[interfaceNo];
						if(interfaceIpWord.equals(NAME_INTERFACE)){
							if(bindValue.equals(interfaceIpWords[interfaceNo+1])){
								String[] ipAddressWords = readedCFGLines.get(contextNo+2).split(" ");
								for(int ipNo=0; ipNo<ipAddressWords.length; ipNo++){
									String ipAddressWord = ipAddressWords[ipNo];
									if(ipAddressWord.equals(NAME_IP) && NAME_ADDRESS.equals(ipAddressWords[ipNo+1])){
										tempBindIpAddress = ipAddressWords[ipNo+2];
									}// End if NAME_IP, NAME_ADDRESS
								}// End for ipAddressWords.length
							}// End if bindValue.equals
						}// End if NAME_INTERFACE
					}
				}// End for contextNo
			}// End if Context
		}// End for contextsWithLineNo.set
		return tempBindIpAddress;
	}// End getIpAddressInContext
	
//			**********************************				//
	
//	Write Data In a File
	public void writeDataInFile(){
		log.info("Write Data InFile Starts: ");
        try{
        	//1.Starts
        	br.write(System.getProperty("line.separator"));
        	br.write(System.getProperty("line.separator"));
        	
        	if(!dot1qPVCSingleList.isEmpty()){
	            for(int i = 0; i< dot1qPVCSingleList.size(); i++){
	            	SingleAccessData singleAccessData = dot1qPVCSingleList.get(i);
	    			String finalDataDesc = null;
	    			String dataDesc = singleAccessData.getDescription();
	    			if(dataDesc!=null){
	    				finalDataDesc = dataDesc.replace("*", "").trim();
	    			}
	    			else{
	    				finalDataDesc = dataDesc;
	    			}
	            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + " description " + "\"" + finalDataDesc + "\" " + System.getProperty("line.separator");
			        String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + NAME_VLAN_ID + singleAccessData.getOuterUnitNo() + System.getProperty("line.separator");
			        String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + singleAccessData.getOuterUnitNo() + NAME_FAMILY_INET_ADDRESS + singleAccessData.getBindIpAddress() + System.getProperty("line.separator");
			        String dataWithNewLine4 = NAME_SET_ROUTING_INSTANCES + singleAccessData.getContextName() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + singleAccessData.getOuterUnitNo() + System.getProperty("line.separator");
			        String dataWithNewLine5 = System.getProperty("line.separator");
	            	
	                br.write(dataWithNewLine1);
	                br.write(dataWithNewLine2);
	                br.write(dataWithNewLine3);
	                br.write(dataWithNewLine4);
	                br.write(dataWithNewLine5);
	            }
	        }
            //2.dot1q pvc onDemand
        	if(!dot1qPVCOnDemandList.isEmpty()){
	            String outerUnitNo = null;
	            Integer innerUnitStart = 0;
	            Integer innerUnitStop = 0;
	            HashSet<OnDemandAccessData> dot1qPVCOnDemandSetList = new HashSet<>();
	            for(int i = 0; i< dot1qPVCOnDemandList.size(); i++){
	            	OnDemandAccessData onDemandData = dot1qPVCOnDemandList.get(i);
	            	if(outerUnitNo==null){
	            		outerUnitNo = onDemandData.getPppoeOuterUnitNo();
	            		innerUnitStart = onDemandData.getPpoeInnerUnitStart();
	            		innerUnitStop = onDemandData.getPpoeInnerUnitStop();
	            	}
	            	else{
	            		if(onDemandData.getPppoeOuterUnitNo().equals(outerUnitNo)){
	            			if(onDemandData.getPpoeInnerUnitStart() < innerUnitStart){
	            				innerUnitStart = onDemandData.getPpoeInnerUnitStart();
	            			}
	            			if(onDemandData.getPpoeInnerUnitStop() > innerUnitStop){
	            				innerUnitStop = onDemandData.getPpoeInnerUnitStop();
	            			}
	            		}
	            		else if(!onDemandData.getPppoeOuterUnitNo().equals(outerUnitNo)){
	            			if(innerUnitStop<1199){
	                    		innerUnitStop = 1199;
	            			}
	                    	OnDemandAccessData setData = new OnDemandAccessData(outerUnitNo, innerUnitStart, innerUnitStop);
	                    	dot1qPVCOnDemandSetList.add(setData);
	            			outerUnitNo = null;
	            			innerUnitStart = 0;
	                        innerUnitStop = 0;
	            			outerUnitNo = onDemandData.getPppoeOuterUnitNo();
	                		innerUnitStart = onDemandData.getPpoeInnerUnitStart();
	                		innerUnitStop = onDemandData.getPpoeInnerUnitStop();
	            		}
	            	}// End else outerUnitNo
	            	
	            }// End for dot1qPVCOnDemandList
	          
				br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " flexible-vlan-tagging" + System.getProperty("line.separator"));
				br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " auto-configure stacked-vlan-ranges dynamic-profile VLAN-DEMUX accept pppoe" + System.getProperty("line.separator"));
				br.write(System.getProperty("line.separator"));
	            for(OnDemandAccessData onDemandSetData: dot1qPVCOnDemandSetList){
	            	String dataWithNewLine = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_AUTO_CONFIGURE + onDemandSetData.getPppoeOuterUnitNo() + "-" +onDemandSetData.getPppoeOuterUnitNo() 
		        	+ "," + onDemandSetData.getPpoeInnerUnitStart() + "-" + onDemandSetData.getPpoeInnerUnitStop() + System.getProperty("line.separator");
	                br.write(dataWithNewLine);
	            }// End for dot1qPVCOnDemandSetList
	            
	            br.write(System.getProperty("line.separator"));
            	br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " auto-configure remove-when-no-subscribers" + System.getProperty("line.separator"));
				br.write(NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + " encapsulation flexible-ethernet-services" + System.getProperty("line.separator"));
				br.write(System.getProperty("line.separator"));
        	} 
	        //2. End
            //3. Starts
        	if(!colonAccessDataList.isEmpty()){
	            for(int i = 0; i<colonAccessDataList.size(); i++){
	            	ColonAccessData colonAccessData = colonAccessDataList.get(i);
	    			String finalDataDesc = null;
	    			String dataDesc = colonAccessData.getDescription();
	    			if(dataDesc!=null){
	    				finalDataDesc = dataDesc.replace("*", "").trim();
	    			}
	    			else{
	    				finalDataDesc = dataDesc;
	    			}
	            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + " " + NAME_DESCRIPTION + " \"" + finalDataDesc + "\" " + System.getProperty("line.separator");
	                String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_VLAN_TAGS_OUTER + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
	                String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_VLAN_TAGS_INNER + colonAccessData.getInnerUnitStart() + System.getProperty("line.separator");
	                String dataWithNewLine4 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + "lo0."+ colonAccessData.getLoopBack() + System.getProperty("line.separator");
	                String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + colonAccessData.getOuterUnitNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + NAME_PREFERRED_SOURCE + colonAccessData.getSourceIpHost() + System.getProperty("line.separator");
	                String dataWithNewLine6 = NAME_SET_ROUTING_INSTANCES + colonAccessData.getContextName() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
	                String ipHostValues = null;
	                
	                String dataWithNewLine8 = System.getProperty("line.separator");
	                br.write(dataWithNewLine1);
	                br.write(dataWithNewLine2);
	                br.write(dataWithNewLine3);
	                br.write(dataWithNewLine4);
	                br.write(dataWithNewLine5);
	                br.write(dataWithNewLine6);
	                for(int lineNo=0; lineNo<colonAccessData.getIpHosts().size(); lineNo++){
	        			String singleIpHostValue = colonAccessData.getIpHosts().get(lineNo);
	        			ipHostValues = singleIpHostValue + "/32" ;
	        			String dataWithNewLine7 = NAME_SET_ROUTING_INSTANCES + colonAccessData.getContextName() + " " + NAME_ROUTING_OPTIONS + ipHostValues + " qualified-next-hop " + fileNamePortEthernetValue + "." + colonAccessData.getOuterUnitNo() + System.getProperty("line.separator");
	        			br.write(dataWithNewLine7);
	                }
	                br.write(dataWithNewLine8);
	            }
        	}
        	//3. End
            //4. Start
        	if(!voipCdotAccessDataList.isEmpty()){
	            Set<String> voipInnerVlanSet = new HashSet<>();
	            for(int i = 0; i<voipCdotAccessDataList.size(); i++){
	            	VoipCdotAccessData voipCdotAccessData = voipCdotAccessDataList.get(i);
	            	String dataWithNewLine1 = NAME_SET_INTERFACES + " irb" + NAME_UNIT + voipCdotAccessData.getVoipInnerVlan() + NAME_FAMILY_INET_ADDRESS + voipCdotAccessData.getVoipIpAddress() + System.getProperty("line.separator");
	                String dataWithNewLine2 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + " " + NAME_DOMAIN_TYPE_BRIDGE + System.getProperty("line.separator");
	                String dataWithNewLine3 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + NAME_VLAN_ID + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
	                String dataWithNewLine4 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + NAME_ROUTING_INTERFACE + "irb." + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
	                String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + " " + NAME_DESCRIPTION + " \"VOIP-CDOT " + voipCdotAccessData.getVoipOuterVlanNo() + ":" + voipCdotAccessData.getVoipInnerVlan() + "\"" + System.getProperty("line.separator");
	                String dataWithNewLine6 = NAME_BRIDGE_DOMAINS + "BD_" + voipCdotAccessData.getVoipInnerVlan() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + voipCdotAccessData.getVoipUnitNo() + System.getProperty("line.separator");
	                String dataWithNewLine7 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
	                String dataWithNewLine8 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_VLAN_TAGS_OUTER + voipCdotAccessData.getVoipOuterVlanNo() + System.getProperty("line.separator");
	                String dataWithNewLine9 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_VLAN_TAGS_INNER + voipCdotAccessData.getVoipInnerVlan() + System.getProperty("line.separator");
	                String dataWithNewLine10 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
	                String dataWithNewLine11 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + voipCdotAccessData.getVoipUnitNo() + NAME_FAMILY_BRIDGE + System.getProperty("line.separator");
	                String dataWithNewLine12 = System.getProperty("line.separator");
	                
	                if(voipInnerVlanSet.contains(voipCdotAccessData.getVoipInnerVlan())){
	            		br.write(dataWithNewLine5);
	                    br.write(dataWithNewLine6);
	                    br.write(dataWithNewLine7);
	                    br.write(dataWithNewLine8);
	                    br.write(dataWithNewLine9);
	                    br.write(dataWithNewLine10);
	                    br.write(dataWithNewLine11);
	                    br.write(dataWithNewLine12);
	            	}
	            	else{
	            		voipInnerVlanSet.add(voipCdotAccessData.getVoipInnerVlan());
	            		br.write(dataWithNewLine1);
	                    br.write(dataWithNewLine2);
	                    br.write(dataWithNewLine3);
	                    br.write(dataWithNewLine4);
	                    br.write(dataWithNewLine5);
	                    br.write(dataWithNewLine6);
	                    br.write(dataWithNewLine7);
	                    br.write(dataWithNewLine8);
	                    br.write(dataWithNewLine9);
	                    br.write(dataWithNewLine10);
	                    br.write(dataWithNewLine11);
	                    br.write(dataWithNewLine12);
	            	}
	            }// End For
        	}
        	//4. End
            //5. Start
        	if(!dot1qPVCProfileList.isEmpty()){
	            for(int i = 0; i< dot1qPVCProfileList.size(); i++){
	            	String profileVlanNo = dot1qPVCProfileList.get(i);
	            	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo +  NAME_VLAN_ID + profileVlanNo + System.getProperty("line.separator");
			        String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo + " " + NAME_FAMILY_PPPOE + System.getProperty("line.separator");
			        String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + profileVlanNo + " " + NAME_FAMILY_PPPOE_DYNAMIC + System.getProperty("line.separator");
			        String dataWithNewLine4 = System.getProperty("line.separator");
	            	
	                br.write(dataWithNewLine1);
	                br.write(dataWithNewLine2);
	                br.write(dataWithNewLine3);
	                br.write(dataWithNewLine4);
	            }
        	}
        	//5. End
            //6. Start
        	if(!wifiAccessDataList.isEmpty()){
	            for(int i = 0; i< wifiAccessDataList.size(); i++){
	            	WifiAccessData wifiAccessData = wifiAccessDataList.get(i);
	                if(wifiAccessData.getWifiVlanNo().equals("4063")){
	                	//1.set interfaces ge-2/1/1 unit 4063 vlan-id 4063
	                	//2.set interfaces ge-2/1/1 unit 4063 family inet unnumbered-address lo0.32
	                	//3.set interfaces ge-2/1/1 unit 4063 family inet unnumbered-address preferred-source-address 100.64.40.1
	                	String dataWithNewLine1 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_VLAN_ID + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
	                	String dataWithNewLine2 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + "lo0." + getLoopBackDetails(wifiAccessData.getWifiContextName()) + System.getProperty("line.separator");
	                	String dataWithNewLine3 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_UNNUMBERED_ADDRESS + NAME_PREFERRED_SOURCE + wifiAccessData.getWifiInterfaceIp() + System.getProperty("line.separator");
	                	String dataWithNewLine4 = System.getProperty("line.separator");
	                	br.write(dataWithNewLine1);
	                    br.write(dataWithNewLine2);
	                    br.write(dataWithNewLine3);
	                    br.write(dataWithNewLine4);
	                }// End if 4063
	            	else{
	            		String dataWithNewLine1 = NAME_SET_INTERFACES + " irb" + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_INET_ADDRESS + wifiAccessData.getWifiInterfaceIp() + System.getProperty("line.separator");
	                	String dataWithNewLine2 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + " " + NAME_DOMAIN_TYPE_BRIDGE + System.getProperty("line.separator");
	                	String dataWithNewLine3 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + NAME_VLAN_ID + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
	                	String dataWithNewLine4 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + NAME_ROUTING_INTERFACE + "irb." + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
	                	String dataWithNewLine5 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + " " + NAME_DESCRIPTION + " \"WIFI-Offload" + "\"" + System.getProperty("line.separator");
	                	String dataWithNewLine6 = NAME_BRIDGE_DOMAINS + "BD_" + wifiAccessData.getWifiVlanNo() + " " + NAME_INTERFACE + " " + fileNamePortEthernetValue + "." + wifiAccessData.getWifiVlanNo() + System.getProperty("line.separator");
	                    String dataWithNewLine7 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_ENCAPSULATION_VLAN_BRIDGE + System.getProperty("line.separator");
	                    String dataWithNewLine8 = NAME_SET_INTERFACES + " " + fileNamePortEthernetValue + NAME_UNIT + wifiAccessData.getWifiVlanNo() + NAME_FAMILY_BRIDGE + System.getProperty("line.separator");
	                    String dataWithNewLine9 = System.getProperty("line.separator");
	                    
	                    br.write(dataWithNewLine1);
	                    br.write(dataWithNewLine2);
	                    br.write(dataWithNewLine3);
	                    br.write(dataWithNewLine4);
	                    br.write(dataWithNewLine5);
	                    br.write(dataWithNewLine6);
	                    br.write(dataWithNewLine7);
	                    br.write(dataWithNewLine8);
	                    br.write(dataWithNewLine9);
	            	}// End else
	            }// End for
    		}
        	//6. End
        	log.info("Write Data InFile Ends: ");
        } catch (IOException e) {
        	log.info("Write Data InFile Catch Block: " + e);
        }
	}// End ()
	
//			**********************************				//
	
//	Clean all variables
	public void resetVariables(){
		outerUnitNo = null;
		innerUnitStart = null;
		innerUnitStop = null;
		bindValue = null;
		singleContextName = null;
		bindIpAddress = null;
		colonContextName = null;
		sourceIpHost = null;
		pppoeOuterUnitNo = null; 
		ppoeInnerUnitStart = null; 
		ppoeInnerUnitStop = null;
		voipOuterVlanNo = null;
		voipInnerVlan = null;
		voipIpAddress = null;
		wifiVlanNo = null;
		wifiInterfaceIp = null;
		ipHosts = new ArrayList<>();
	}// End resetVariables()
	
	
//	******** Access End	********	//	
	
//			**********************************				//

//	******** L3vpn logic Starts	********	//
	
//	File Read and Write logic
	@SuppressWarnings("resource")
	public void readL3vpnTextFile(){
		log.info("Read L3vpn Text File Starts");
		inputStream = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("L3vpn.txt");
	    //Read Base Configuration file and Store it in list@ readedBaseConfigLines
		Scanner scannerFile = new Scanner(inputStream);
		while (scannerFile.hasNextLine()) {
			readedL3vpnLines.add(scannerFile.nextLine());
		}//End while
		try{
			log.info("Read L3vpn Text File Ends & inputStream Closed");
			inputStream.close();
		}catch(Exception e){
			log.info("Read L3vpn Text File Catch Block: " + e);
		}
	}//End readL3vpnTextFile()
	
//			**********************************				//

	private boolean bsnlinPrefix = false;
	private static final String NAME_PREFIXLIST = "prefix-list";
	private static final String NAME_SEQ = "seq";
	private List<String> bsnlinSeqPermitList = new ArrayList<>();
	private Map<String, List<String>> bsnlinSeqPermitMap = new HashMap<>();
	private Map<String, String> neighborPrefixList = new HashMap<>();
	
// 	Read With in the context Only. for getting the values
	public void readWithInTheContext(String contextName){
		log.info("Read with in the Context Starts: " + contextName);
		Integer startContextLineNo = 0;
		Integer endContextLineNo = 0;
		domains = new ArrayList<>();
		domains.add(contextName);
		// To find context start and end line no's.
		for(int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo< currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(NAME_CONTEXT) && contextName.equals(currentLineWords[clNo+1])){
						startContextLineNo = currentLineNo;
						endContextLineNo = getNextContextLineNo(currentLineNo);//End Context
						if(endContextLineNo==0){
							boolean endPoint = false;
							for(int endCurrentLineNo = currentLineNo; endCurrentLineNo <= readedCFGLines.size(); endCurrentLineNo++) {
								String endCurrentLine = readedCFGLines.get(endCurrentLineNo);
								String[] endCurrentLineWords = endCurrentLine.split(" ");
								if(endCurrentLineWords.length==5 && !endPoint){
									for(int endClNo=0; endClNo< endCurrentLineWords.length; endClNo++){
										String endCurrentWord = endCurrentLineWords[endClNo];
										if(endCurrentWord.equals("End") && endCurrentLineWords[endClNo+1].equals("Context")){
											endContextLineNo = endCurrentLineNo;
											endPoint = true;
										}
									}
								}
							}//End endCurrentLineNo
						}
					}// End currentWord
				}// End currentLineWords.length
			}// End if currentLineWords.length
		}// start and end line no's
		
		for(int inContextLineNo = startContextLineNo+1; inContextLineNo < endContextLineNo; inContextLineNo++){
			String[] inContextWords = readedCFGLines.get(inContextLineNo).split(" ");
			for(int inNo=0; inNo<inContextWords.length; inNo++){
				String inContextWord = inContextWords[inNo];
				// bng_as_no
				if(inContextWord.equals(NAME_ROUTER) && NAME_BGP.equals(inContextWords[inNo+1])){
					bngAsNo = inContextWords[inNo+2];
				}
				// neighbor_ip_address multiple values
				if(inContextWord.equals(NAME_NEIGHBOR) && NAME_EXTERNAL.equals(inContextWords[inNo+2])){
					neighborIpAddress.add(inContextWords[inNo+1]);
					if(contextName.equals("bsnl.in")){
						//System.out.println("neighbor_ip_address: lineNo: " + inContextLineNo);
						for(int neighborPrefixNo = inContextLineNo+1; neighborPrefixNo <inContextLineNo+10 ; neighborPrefixNo++){
							String[] neighborPrefixWords = readedCFGLines.get(neighborPrefixNo).split(" ");
							for(int prefixOutNo=0; prefixOutNo<neighborPrefixWords.length; prefixOutNo++){
								String neighborPrefixWord = neighborPrefixWords[prefixOutNo];
								
								if(neighborPrefixWord.equals(NAME_PREFIXLIST) && "out".equals(neighborPrefixWords[prefixOutNo+2])){
									//System.out.println("neighborPrefixWords: " + neighborPrefixWords.length + " : inContextWords[inNo+1]: "+ inContextWords[inNo+1] + " : : " + neighborPrefixWords[prefixOutNo+1]);
									neighborPrefixList.put(inContextWords[inNo+1], neighborPrefixWords[prefixOutNo+1]);
								
								}
							}
						
						}//End for neighborPrefixNo
					}//End contextName.equals("bsnl.in")
					
				}//End if NAME_NEIGHBOR, NAME_EXTERNAL
				
				
				
				
				
				// wifi-data
				if(contextName.equals("wifi-data")){
					//dhcp-relay
					if(inContextWord.equals("dhcp") && inContextWords[inNo+1].equals("relay") && inContextWords[inNo+2].equals("server") ){
						dhcpServer = inContextWords[inNo+3];
					}
					//
					if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].contains("QUAD-WIFI-") && inContextWords[inNo+2].equals(NAME_MULTIBIND)){
						String[] quadWifiWords = readedCFGLines.get(inContextLineNo+2).split(" ");
						for(int quardNo=0; quardNo<quadWifiWords.length; quardNo++){
							String quadWifiWord = quadWifiWords[quardNo];
							if(quadWifiWord.equals(NAME_IP) && quadWifiWords[quardNo+1].equals(NAME_ADDRESS)){
								quadWifiIpAddress.add(quadWifiWords[quardNo+2]);
							}
						}
					}
				}
				// NOFN
				if(contextName.equals("NOFN")){
					if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].contains("DSLAM-NOFN-INCITY") && inContextWords[inNo+2].equals(NAME_MULTIBIND)){
						String[] nofnWords = readedCFGLines.get(inContextLineNo+2).split(" ");
						for(int nofnNo=0; nofnNo<nofnWords.length; nofnNo++){
							String nofnWord = nofnWords[nofnNo];
							if(nofnWord.equals(NAME_IP) && nofnWords[nofnNo+1].equals(NAME_ADDRESS)){
								nofnIpAddress.add(nofnWords[nofnNo+2]);
							}
						}
					}
				}
				// bbnlinband-ll
				if(contextName.equals("bbnlinband-ll")){
					if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].contains("bbnlinband-ll") && inContextWords[inNo+2].equals(NAME_MULTIBIND)){
						String[] bbnlinbandllWords = readedCFGLines.get(inContextLineNo+2).split(" ");
						for(int bbnlinbandllNo=0; bbnlinbandllNo<bbnlinbandllWords.length; bbnlinbandllNo++){
							String bbnlinbandllWord = bbnlinbandllWords[bbnlinbandllNo];
							if(bbnlinbandllWord.equals(NAME_IP) && bbnlinbandllWords[bbnlinbandllNo+1].equals(NAME_ADDRESS)){
								bbnlinbandllIpAddress.add(bbnlinbandllWords[bbnlinbandllNo+2]);
							}
						}
					}
				}
				
				//l2tpvpn
				if(contextName.equals("l2tpvpn")){
					if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].contains("l2tpvpn") && inContextWords[inNo+2].equals("loopback")){
						String[] l2tpvpnWords = readedCFGLines.get(inContextLineNo+2).split(" ");
						for(int l2tpvpnNo=0; l2tpvpnNo<l2tpvpnWords.length; l2tpvpnNo++){
							String l2tpvpnWord = l2tpvpnWords[l2tpvpnNo];
							if(l2tpvpnWord.equals(NAME_IP) && l2tpvpnWords[l2tpvpnNo+1].equals(NAME_ADDRESS)){
								l2tpvpnLoopbackIpAddress.add(l2tpvpnWords[l2tpvpnNo+2]);
							}
						}
					}
				}
				
				//bsnl.in for l2tpvpn related, l2tpvpnLoopback_BsnlIn_IpAddress
				if(contextName.equals("bsnl.in")){
					if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].contains("INET-LOOPBACK") && inContextWords[inNo+2].equals("loopback")){
						String[] bsnlinWords = readedCFGLines.get(inContextLineNo+2).split(" ");
						for(int bsnlinNo=0; bsnlinNo<bsnlinWords.length; bsnlinNo++){
							String l2tpvpnLoopbackBsnlInWord = bsnlinWords[bsnlinNo];
							if(l2tpvpnLoopbackBsnlInWord.equals(NAME_IP) && bsnlinWords[bsnlinNo+1].equals(NAME_ADDRESS)){
								l2tpvpnLoopbackBsnlInIpAddress.add(bsnlinWords[bsnlinNo+2]);
							}
						}
					}
					
					//28-6-19// ip prefix-list
					if(inContextWord.equals(NAME_IP) && inContextWords[inNo+1].equals(NAME_PREFIXLIST) && !bsnlinPrefix){
						getPrefixListToPrefixListLineNo(inContextLineNo, endContextLineNo);
						//ipPrefixListWithLineNo, getNextPrefixListtLineNo
						bsnlinPrefix = true;
					}//End if NAME_IP, NAME_PREFIXLIST, bsnlinPrefix
					
					if(inContextWord.equals(NAME_IP) && inContextWords[inNo+1].equals(NAME_PREFIXLIST)){
						//getPermitIpAddressInPrefixList
						getPermitIpAddressInPrefixList(inContextWords[inNo+2], endContextLineNo);
						
						if(bsnlinSeqPermitList.size()>0){
							bsnlinSeqPermitMap.put(inContextWords[inNo+2], bsnlinSeqPermitList);
						}
						
					}//End if NAME_IP, NAME_PREFIXLIST
					
					
				}//End if contextName.equals("bsnl.in")
				
				
				
				
				//domain
				if(inContextWords.length==3){
					if(inContextWord.equals(NAME_DOMAIN)){
						domains.add(inContextWords[inNo+1]);
					}
				}
			}
		}//End for
		
		//for pool values logic
		for(int inContextLineNo = startContextLineNo+1; inContextLineNo < endContextLineNo; inContextLineNo++){
			String[] inContextWords = readedCFGLines.get(inContextLineNo).split(" ");
			// String 'interface', next to next String 'multibind' based search
			if(inContextWords.length==4){
				for(int inNo=0; inNo<inContextWords.length; inNo++){
					String inContextWord = inContextWords[inNo];
					//ppbb.bsnl.in 
					if(contextName.equals("ppbb.bsnl.in")){
						if(inContextWord.equals(NAME_INTERFACE) && inContextWords[inNo+1].equals("PPBB-LOOPBACK") && inContextWords[inNo+2].equals("loopback")){
							String[] ppbbWords = readedCFGLines.get(inContextLineNo+2).split(" ");
							for(int pp=0; pp < ppbbWords.length; pp++){
								String ppbbWord = ppbbWords[pp];
								if(ppbbWord.equals(NAME_IP) && ppbbWords[pp+1].equals(NAME_ADDRESS)){
									ppbbIpAddress = ppbbWords[pp+2];
								}
							}
						}//End if interface, loopback
					}//End if ppbb.bsnl.in
					
					
					
					//String 'interface', next to next String 'multibind' based search
					if(inContextWord.equals(NAME_INTERFACE) && NAME_MULTIBIND.equals(inContextWords[inNo+2])){
						String riAddressPoolFirstIp = null;
						String riAddressPoolLow = null;
						String riAddressPoolHigh = null;
						if(inContextWords[inNo+1].contains("POOL-")){
							//	ri_name-pool - first condition and ri_name_pool - second condition 
							for(int q=inContextLineNo+1; q<inContextLineNo+7; q++){
								String[] riNamePoolWords = readedCFGLines.get(q).split(" ");
								
								for(int riPoolNo=0; riPoolNo < riNamePoolWords.length; riPoolNo++){
									String riNamePoolWord = riNamePoolWords[riPoolNo];
									// ri_address_pool
									
									if(riNamePoolWords.length==5){
										if(riNamePoolWord.equals(NAME_IP) && NAME_POOL.equals(riNamePoolWords[riPoolNo+1])){
											if(riNamePoolWords[riPoolNo+2]!="" && riNamePoolWords[riPoolNo+2]!=null){
												SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(riNamePoolWords[riPoolNo+2]);
												String subnet[] = subnetIpAddress.getInfo().getLowAddress().split("\\/");
												String subnetValue = "";
												for(int sub=0; sub<subnet.length; sub++){
													subnetValue = subnet[0];
												}
												String low[] = subnetValue.split("\\.");
												int lowValue = Integer.parseInt(low[low.length-1]);
												riAddressPoolFirstIp = subnetIpAddress.getInfo().getLowAddress();
												
												String subLow = riAddressPoolFirstIp.substring(0, riAddressPoolFirstIp.lastIndexOf('.'));
												
												riAddressPoolLow = subLow+"."+(lowValue+1);
												
												riAddressPoolHigh = subnetIpAddress.getInfo().getHighAddress();
											}
											
											pools.add(new Pool(inContextWords[inNo+1], riNamePoolWords[riPoolNo+2], riAddressPoolFirstIp, riAddressPoolLow, riAddressPoolHigh));
											riAddressPoolFirstIp = null; riAddressPoolLow = null; riAddressPoolHigh = null;
										}
									}
									else if(riNamePoolWords.length>5){
										if(riNamePoolWord.equals(NAME_IP) && NAME_POOL.equals(riNamePoolWords[riPoolNo+1])){
											if(riNamePoolWords[riPoolNo+2]!="" && riNamePoolWords[riPoolNo+2]!=null){
												SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(riNamePoolWords[riPoolNo+2]);
												String subnet[] = subnetIpAddress.getInfo().getLowAddress().split("\\/");
												String subnetValue = "";
												for(int sub=0; sub<subnet.length; sub++){
													subnetValue = subnet[0];
												}
												
												String low[] = subnetValue.split("\\.");
												int lowValue = Integer.parseInt(low[low.length-1]);
												riAddressPoolFirstIp = subnetIpAddress.getInfo().getLowAddress();
												
												String subLow = riAddressPoolFirstIp.substring(0, riAddressPoolFirstIp.lastIndexOf('.'));
												
												riAddressPoolLow = subLow+"."+(lowValue+1);
												
												riAddressPoolHigh = subnetIpAddress.getInfo().getHighAddress();
											}
											
											pools.add(new Pool(inContextWords[inNo+1], riNamePoolWords[riPoolNo+2], riAddressPoolFirstIp, riAddressPoolLow, riAddressPoolHigh));
											riAddressPoolFirstIp = null; riAddressPoolLow = null; riAddressPoolHigh = null;
										}
									}
									
								}// End for riNamePoolWords.length
								
								
							}// End ri_name-pool for both conditions
						
							
							
						}// End if "POOL-"
						
					}// End if name_Interface, name_name_multibind.
				}
				
			}
		}//End for pool values logic
		
		
		
		//ReadMapWithInContext: Mgmt router ospf
		if(contextName=="mgmt"){
			for(int inContextLineNo = startContextLineNo+1; inContextLineNo < endContextLineNo; inContextLineNo++){
				String[] inContextWords = readedCFGLines.get(inContextLineNo).split(" ");
				for(int inNo=0; inNo<inContextWords.length; inNo++){
					String inContextWord = inContextWords[inNo];
					if(inContextWord.equals(NAME_DOMAIN) && inContextWords[inNo+1].equals("operation.in")){
						domainOperationIn = true;
					}
					
					if(inContextWords.length==4){
						//Mgmt router ospf
						if(inContextWord.equals(NAME_ROUTER) && NAME_OSPF.equals(inContextWords[inNo+1])){
							//After router ospf find
							for(int routerLineNo = inContextLineNo+1; routerLineNo < inContextLineNo+10; routerLineNo++){
								String[] routerWords = readedCFGLines.get(routerLineNo).split(" ");
								for(int routerNo=0; routerNo<routerWords.length; routerNo++){
									String routerWord = routerWords[routerNo];
									//router interface find
									if(routerWords.length==5){
										if(routerWord.equals(NAME_INTERFACE)){
											mgmtInterfaces.add(routerWords[routerNo+1]);
										}
									}
									
									//Find route-map
									if(routerWord.equals("route-map")){
										String tempRoter = routerWords[routerNo+1];
										//NAME_ROUTE_MAP, NAME_PERMIT
										for(int routerMapLineNo = routerLineNo+1; routerMapLineNo < endContextLineNo; routerMapLineNo++){
											String[] routerMapWords = readedCFGLines.get(routerMapLineNo).split(" ");
											if(routerMapWords.length==5){
												for(int routerMapNo=0; routerMapNo<routerMapWords.length; routerMapNo++){
													String routerMapWord = routerMapWords[routerMapNo];
													if(routerMapWord.equals(NAME_ROUTE_MAP) && routerMapWords[routerMapNo+2].equals(NAME_PERMIT)){
														if(tempRoter.equals(routerMapWords[routerMapNo+1])){
															//NAME_PERFIX_LIST
																String[] routerPrefixListWords = readedCFGLines.get(routerMapLineNo+1).split(" ");
																for(int routerPrefixNo=0; routerPrefixNo<routerPrefixListWords.length; routerPrefixNo++){
																	String routerPrefixWord = routerPrefixListWords[routerPrefixNo];
																	if(routerPrefixWord.equals(NAME_PERFIX_LIST) ){
																		String prefixListValue = routerPrefixListWords[routerPrefixNo+1];
																		//finding PAN-TEST IP list @ above line
																		
																		for(int prefixListLineNo = (routerMapLineNo+1); prefixListLineNo > startContextLineNo+1; prefixListLineNo--){
																			String[] prefixListWords = readedCFGLines.get(prefixListLineNo).split(" ");
																			if(prefixListWords.length==4){
																				for(int prefixListNo=0; prefixListNo<prefixListWords.length; prefixListNo++){
																					String prefixListWord = prefixListWords[prefixListNo];
																					if(prefixListWord.equals(NAME_PERFIX_LIST) && prefixListWords[prefixListNo+1].equals(prefixListValue)){
																						//ip prefix-list permit
																						for(int prefixListIpLineNo = prefixListLineNo; prefixListIpLineNo < prefixListLineNo+6; prefixListIpLineNo++){
																							String[] prefixListIpWords = readedCFGLines.get(prefixListIpLineNo).split(" ");
																							
																							for(int prefixListIpNo=0; prefixListIpNo<prefixListIpWords.length; prefixListIpNo++){
																								String prefixListIpWord = prefixListIpWords[prefixListIpNo];
																								if(prefixListIpWords.length==6){
																									if(prefixListIpWord.equals(NAME_PERMIT)){
																										routeFilters.add(prefixListIpWords[prefixListIpNo+1]);
																									}
																								}
																							}
																						}
																						
																					}
																				}
																			}
																		}
																		
																	}
																}
														}
													}
													
												}
												
											}//End routerMapWords.length ==5
											
										}// End for NAME_ROUTE_MAP
										
									}
								}
							}
						
						}
					}
					
				}
				
			}
		}//End if context MGMT
		
		
	}// End ReadMapWithInContext()
	
	
	

// 	Read Over all file(CFG) for getting the values 
	private List<UplinkInterface> uplinkInterfaces = null;
	private int pvcCount = 0;
	private int portCount = 0;
	private String uplinkPvcValue = "";
	private String uplinkPortValue = "";
	
	public void readUplinkInterfaceOverAll(String contextName){
		uplinkInterfaces = new ArrayList<>();
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				
				// Finding Interfaces
				String uplink = "UPLINK-";
				String uplink0 = "UPLINK-0";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink0 + i;
							//With out wan
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
								if(uplinkInterface!=null){
									uplinkInterface.setUplink_portValue(uplinkPortValue);
									uplinkInterface.setUplink_unit_no(uplinkPvcValue);
									uplinkInterface.setUplink_vlan_id(uplinkPvcValue);
								}
								else if(uplinkInterface==null){
									UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
									uplinkInterfaces.add(upInterface);
								}
							}
						}	
						else{
							finalUplink = uplink + i;
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
								uplinkInterfaces.add(upInterface);
							}
						}
					}
				}
			}
		}
	}
	
	
	private static final String NAME_MULTIBIND = "multibind";
	private String uplinkWanIp = "";
	
//	Read wan_ip_address Values based on UPLINK value
	public void readMapForWanIpAddress(String contextName){
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				String uplink = "UPLINK-";
				String uplink0 = "UPLINK-0";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink0 + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									if(nextContextLineNo==null){
										nextContextLineNo = readedCFGLines.size();
									}
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End if
						else{
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End else
					}// End for up to 99 uplinks
				}// End if - contextName 
			}
		}
	}
//	

// 	Interface Properties 
	private String ethernetPort = null;
	public String getInterfaceDetails(String ethernetValue){
		String tempEthernet ="Uplink_" + ethernetValue;
		String newEthernet = tempEthernet.replace(" ", "_");
		ethernetPort = uplinkPropertiesMap.get(newEthernet);
		//uplinkPropertiesMap
		if(ethernetPort==null){
			ethernetPort="";
		}
		return ethernetPort;
	}
	
	
//	
	public UplinkInterface getUplinkInterface(String searchUplink){
		UplinkInterface searchedUplinkInterface = null;
		for(UplinkInterface uplink: uplinkInterfaces){
			if(searchUplink.equals(uplink.getUplink_interface())){
				searchedUplinkInterface = uplink;
			}
		}
		return searchedUplinkInterface;
	}
	
	
/*				Writing Logic					*/	
	private String bngAsNo = null;
	private String dhcpServer;
	private static final String NAME_NEIGHBOR = "neighbor";
	private static final String NAME_EXTERNAL = "external";
	private List<String> neighborIpAddress = new ArrayList<>();
	private List<String> l3vpnOutputLists = new ArrayList<>();
	
	
	public void writeL3vpnData(){
		for(String context: l3vpnContexts){
			String value = getLoopBackDetails(context);
			pools = new ArrayList<>();
			neighborIpAddress = new ArrayList<>();
			
			readWithInTheContext(context);
			readUplinkInterfaceOverAll(context);
			readMapForWanIpAddress(context);
			
			for(String readedLine: readedL3vpnLines){
				if(readedLine.contains("Sterlite_ContextName")){
					for(Pool pool: pools){
						//ri pool Name, address
						if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ri_name_pool") && readedLine.contains("Sterlite_ri_address_pool")){
							String tempNamePoolNameAddress = readedLine;
							tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ContextName", context);
							tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_name_pool", pool.getRi_name_pool());
							tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_address_pool", pool.getRi_address_pool());
							l3vpnOutputLists.add(tempNamePoolNameAddress);
						}
						//ri pool low
						if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ri_name_pool") && readedLine.contains("Sterlite_ri_pool_low")){
							String tempNamePoolLow = readedLine;
							tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ContextName", context);
							tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_name_pool", pool.getRi_name_pool());
							tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_pool_low", pool.getRi_pool_low());
							l3vpnOutputLists.add(tempNamePoolLow);
						}
						//ri pool high
						if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ri_name_pool") && readedLine.contains("Sterlite_ri_pool_high")){
							String tempNamePoolHigh = readedLine;
							tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ContextName", context);
							tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_name_pool", pool.getRi_name_pool());
							tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_pool_high", pool.getRi_pool_high());
							l3vpnOutputLists.add(tempNamePoolHigh);
						}
						//ri pool address
						if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ri_address_pool") && !readedLine.contains("Sterlite_ri_name_pool") && !readedLine.contains("Sterlite_ri_pool_low") && !readedLine.contains("Sterlite_ri_pool_high")){
							String tempNamePoolAddress = readedLine;
							tempNamePoolAddress = tempNamePoolAddress.replace("Sterlite_ContextName", context);
							tempNamePoolAddress = tempNamePoolAddress.replace("Sterlite_ri_address_pool", pool.getRi_address_pool());
							l3vpnOutputLists.add(tempNamePoolAddress);
						}
						// Sterlite_ri_address_pool
						if(!readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_LoopBack") && readedLine.contains("Sterlite_ri_address_pool")){
							String tempNameLoopBackPoolAddress = readedLine;
							tempNameLoopBackPoolAddress = tempNameLoopBackPoolAddress.replace("Sterlite_LoopBack", value);
							tempNameLoopBackPoolAddress = tempNameLoopBackPoolAddress.replace("Sterlite_ri_address_pool", pool.getRi_address_pool());
							l3vpnOutputLists.add(tempNameLoopBackPoolAddress);
						}
						
					}//End for pools
					
					// loopback
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_LoopBack")  && !readedLine.contains("Sterlite_ri_pool_first_ip")){
						readedLine = readedLine.replace("Sterlite_LoopBack", value);
						readedLine = readedLine.replace("Sterlite_ContextName", context);
						l3vpnOutputLists.add(readedLine);
					}
					//loop back, Context
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_LoopBack")){
						String tempNameLoopBackPoolFirstIp = readedLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ContextName", context);
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_LoopBack", value);
						l3vpnOutputLists.add(tempNameLoopBackPoolFirstIp);
					}
					// bng_as_no
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_Bng_As_No")){
						readedLine = readedLine.replace("Sterlite_Bng_As_No", bngAsNo);
						readedLine = readedLine.replace("Sterlite_ContextName", context);
						l3vpnOutputLists.add(readedLine);
					}
					//domains
					//set access Sterlite_Domain map Sterlite_ContextDomain aaa-routing-instance local
					//set access Sterlite_Domain map Sterlite_ContextDomain target-routing-instance Sterlite_ContextName
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ContextDomain") && readedLine.contains("Sterlite_Domain")){
						if(!domains.isEmpty()){
							String tempReadedLine;
							for(String domainName: domains){
								tempReadedLine = readedLine.replace("Sterlite_ContextName", context);
								tempReadedLine = tempReadedLine.replace("Sterlite_Domain", "domain");
								tempReadedLine = tempReadedLine.replace("Sterlite_ContextDomain", domainName);
								l3vpnOutputLists.add(tempReadedLine);
							}
						}
					}
					
					//neighbor ip address
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_Neighbour_Ip_Address")){
						String tempReadLine;
						for(String ipAddress: neighborIpAddress){
							readedLine = readedLine.replace("Sterlite_ContextName", context);
							tempReadLine = readedLine.replace("Sterlite_Neighbour_Ip_Address", ipAddress);
							l3vpnOutputLists.add(tempReadLine);
						}
					}
					
					//Sterlite_EthernetPort_Value.Sterlite_EthernetPort_UnitNo
					if(readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_EthernetPort_Value") && readedLine.contains("Sterlite_EthernetPort_UnitNo")){
						String tempInterfaceReadLine;
						for(UplinkInterface uplinkInterface: uplinkInterfaces){
							String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
							tempInterfaceReadLine = readedLine.replace("Sterlite_ContextName", context);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_Value", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_UnitNo", uplinkInterface.getUplink_unit_no());
							
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_Interface", uplinkInterface.getUplink_interface());
							
							l3vpnOutputLists.add(tempInterfaceReadLine);
						}
						readedLine = "";
					}
					
					//Context Name only
					if(readedLine.contains("Sterlite_ContextName") && !readedLine.contains("Sterlite_ri_name_pool") && !readedLine.contains("Sterlite_ri_address_pool") && !readedLine.contains("Sterlite_ri_pool_low") && !readedLine.contains("Sterlite_ri_pool_high") && !readedLine.contains("Sterlite_Neighbour_Ip_Address") && !readedLine.contains("Sterlite_ContextDomain") && !readedLine.contains("Sterlite_Domain")){
						readedLine = readedLine.replace("Sterlite_ContextName", context);
						l3vpnOutputLists.add(readedLine);
					}
					
				}//End if Sterlite_ContextName
				else{
					
					for(Pool pool: pools){
						//loop back, ri pool first ip address
						if(readedLine.contains("Sterlite_LoopBack") && readedLine.contains("Sterlite_ri_pool_first_ip")){
							String tempNameLoopBackPoolFirstIp = readedLine;
							tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_LoopBack", value);
							tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_ip", pool.getRi_pool_first_ip());
							l3vpnOutputLists.add(tempNameLoopBackPoolFirstIp);
						}
					}//End for pools
					
					//loop back
					if(readedLine.contains("Sterlite_LoopBack") && !readedLine.contains("Sterlite_ri_pool_first_ip")){
						readedLine = readedLine.replace("Sterlite_LoopBack", value);
						l3vpnOutputLists.add(readedLine);
					}
					//Static Lines
					if(!readedLine.contains("Sterlite_LoopBack") && !readedLine.contains("Sterlite_ri_pool_first_ip") && !readedLine.contains("Sterlite_EthernetPort_Value") && !readedLine.contains("Sterlite_EthernetPort_UnitNo") && !readedLine.contains("Sterlite_Ip_Address")){
						l3vpnOutputLists.add(readedLine);
					}
					//Sterlite_ContextDomain, Sterlite_Domain
					if(!readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_ContextDomain") && readedLine.contains("Sterlite_Domain") && !readedLine.contains("Sterlite_ri_pool_first_ip") && !readedLine.contains("Sterlite_EthernetPort_Value") && !readedLine.contains("Sterlite_EthernetPort_UnitNo") && !readedLine.contains("Sterlite_Ip_Address")){
						if(!domains.isEmpty()){
							//Sterlite_Domain_ContextName
							String tempReadedLine;
							for(String domainName: domains){
								tempReadedLine = readedLine.replace("Sterlite_Domain", "domain");
								tempReadedLine = tempReadedLine.replace("Sterlite_ContextDomain", domainName);
								l3vpnOutputLists.add(tempReadedLine);
							}
						}
					}
					
					
					//Sterlite_EthernetPort_Value.Sterlite_EthernetPort_UnitNo, Sterlite_Ip_Address
					if(!readedLine.contains("Sterlite_ContextName") && readedLine.contains("Sterlite_EthernetPort_Value") && readedLine.contains("Sterlite_EthernetPort_UnitNo")){
						String tempInterfaceReadLine = null;
						for(UplinkInterface uplinkInterface: uplinkInterfaces){
							String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
							
							if(readedLine.contains("Sterlite_EthernetPort_Value") && readedLine.contains("Sterlite_EthernetPort_UnitNo") && !readedLine.contains("Sterlite_Ip_Address") ){
								tempInterfaceReadLine = readedLine.replace("Sterlite_EthernetPort_Value", portValue);
								tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_UnitNo", uplinkInterface.getUplink_unit_no());
								l3vpnOutputLists.add(tempInterfaceReadLine);
							}
							if(readedLine.contains("Sterlite_EthernetPort_Value") && readedLine.contains("Sterlite_EthernetPort_UnitNo") && readedLine.contains("Sterlite_Ip_Address")){
								tempInterfaceReadLine = readedLine.replace("Sterlite_EthernetPort_Value", portValue);
								tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_UnitNo", uplinkInterface.getUplink_unit_no());
								tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Ip_Address", uplinkInterface.getWan_ip_address());
								l3vpnOutputLists.add(tempInterfaceReadLine);
							}
						}
						readedLine = "";
					}
				}//End Else - with out Sterlite_ContextName lines
				
			}
			l3vpnOutputLists.add("");
		}
		
//		Output Write at file
		l3vpnOutputLists.removeIf(con->con.equals("set access Sterlite_Domain map Sterlite_ContextDomain aaa-routing-instance local"));
		for(String l3vpnOutputList: l3vpnOutputLists){
			try {
				br.write(l3vpnOutputList);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("L3vpn output Write File Catch Block: " + e);
			}
		}//End for
		
	}
	
	
//	*************** MGMT Code ************
	
	List<String> readedMgmtLines = new ArrayList<>();
//	File Read and Write logic
	public void readMgmtTextFile(){
		//Static L3vpn Mgmt text file
		InputStream mgmtConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("mgmt.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(mgmtConfigFile);
		while (scannerFile.hasNextLine()) {
			readedMgmtLines.add(scannerFile.nextLine());
		}
	}
	
//	mgmt Uplink
	public void readMgmtUplinkInterfaceOverAll(String contextName){
		uplinkInterfaces = new ArrayList<>();
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				// Finding Interfaces
				String uplink = "MGMT-UPLINK-";
				String finalUplink ="";
				
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink + i;
							//With out wan
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
								if(uplinkInterface!=null){
									uplinkInterface.setUplink_portValue(uplinkPortValue);
									uplinkInterface.setUplink_unit_no(uplinkPvcValue);
									uplinkInterface.setUplink_vlan_id(uplinkPvcValue);
								}
								else if(uplinkInterface==null){
									UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
									uplinkInterfaces.add(upInterface);
								}
							}
						}	
						else{
							finalUplink = uplink + i;
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
								uplinkInterfaces.add(upInterface);
							}
						}
					}
				}
			}
		}
	}
	
//	Read wan_ip_address Values based on UPLINK value
	public void readMgmtMapForWanIpAddress(String contextName){
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				String uplink = "MGMT-UPLINK-";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									if(nextContextLineNo==null){
										nextContextLineNo = readedCFGLines.size();
									}
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End if
						else{
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End else
					}// End for up to 99 uplinks
				}// End if - contextName 
			}
		}
	}
//	End uplink ip address
	//private 
	private List<String> mgmtEthernetPorts = new ArrayList<>();
	public void mgmtPhysicalInterface(){
		boolean mgmtInterface = false;
		for(int mgmtInterfaceLineNo = 1; mgmtInterfaceLineNo <= readedCFGLines.size(); mgmtInterfaceLineNo++) {
			String[] mgmtInterfaceWords = readedCFGLines.get(mgmtInterfaceLineNo).split(" ");
			for(int mgmtINo=0; mgmtINo < mgmtInterfaceWords.length; mgmtINo++){
				if(mgmtInterfaceWords.length==5){
					String mgmtInterfaceWord = mgmtInterfaceWords[mgmtINo];
					if(mgmtInterfaceWord.equals(NAME_BIND) && mgmtInterfaceWords[mgmtINo+1].equals(NAME_INTERFACE) && mgmtInterfaceWords[mgmtINo+3].equals("mgmt")){
						mgmtInterface = false;
						if(mgmtInterfaces.contains(mgmtInterfaceWords[mgmtINo+2])){
							//reverse search for port Ethernet value
							for (int mgmtEthernetLineNo = mgmtInterfaceLineNo-1; mgmtEthernetLineNo < mgmtInterfaceLineNo; mgmtEthernetLineNo--) {
								String[] mgmtEthernetWords;
								try{
									mgmtEthernetWords = readedCFGLines.get(mgmtEthernetLineNo).split(" ");
								}
								catch(NullPointerException ne){
									continue;
								}
								if(mgmtEthernetWords.length==3){
									for(int mgmtENo=0; mgmtENo < mgmtEthernetWords.length; mgmtENo++){
										String currentWord = mgmtEthernetWords[mgmtENo];
										if(currentWord.equals(NAME_PORT) && NAME_ETHERNET.equals(mgmtEthernetWords[mgmtENo+1])){
											mgmtEthernetPorts.add(mgmtEthernetWords[mgmtENo+1] + " " + mgmtEthernetWords[mgmtENo+2]);
											mgmtInterface = true;
										}
									}
								}
								if(mgmtInterface){
									break;
								}
							}//End for mgmtEthernetLineNo
							
						}//End if mgmtInterface
						
					}//End if mgmtInterfaceWord
					
				}//End if mgmtInterfaceWords.length
				
			}//End for mgmtINo
			
		}//End for mgmtInterfaceLineNo, readedCFGLines
		
	}
	
	//get mgmt values and added into list (l3vpnMgmtOutputLines)
	private List<String> mgmtOutputLines = new ArrayList<>();
	public void writeMgmtData(){
		String contextMgmt = "mgmt";
		pools = new ArrayList<>();
		neighborIpAddress = new ArrayList<>();
		
		String valueMgmt = getLoopBackDetails(contextMgmt);

		readWithInTheContext(contextMgmt);
		readMgmtUplinkInterfaceOverAll(contextMgmt);
		readMgmtMapForWanIpAddress(contextMgmt);
		mgmtPhysicalInterface();
		
		for(String readedMgmtLine: readedMgmtLines){
			if(readedMgmtLine.contains(contextMgmt)){
				//mgmt Pool values 
				for(Pool pool: pools){
					//Sterlite_ri_mgmt_address_pool, name
					if(readedMgmtLine.contains("Sterlite_ri_mgmt_name_pool") && readedMgmtLine.contains("Sterlite_ri_mgmt_address_pool")){
						String tempNamePoolNameAddress = readedMgmtLine;
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_mgmt_name_pool", pool.getRi_name_pool());
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_mgmt_address_pool", pool.getRi_address_pool());
						mgmtOutputLines.add(tempNamePoolNameAddress);
					}
					//Sterlite_ri_mgmt_pool_low
					if(readedMgmtLine.contains("Sterlite_ri_mgmt_name_pool") && readedMgmtLine.contains("Sterlite_ri_mgmt_pool_low")){
						String tempNamePoolLow = readedMgmtLine;
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_mgmt_name_pool", pool.getRi_name_pool());
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_mgmt_pool_low", pool.getRi_pool_low());
						mgmtOutputLines.add(tempNamePoolLow);
					}
					//Sterlite_ri_mgmt_pool_high
					if(readedMgmtLine.contains("Sterlite_ri_mgmt_name_pool") && readedMgmtLine.contains("Sterlite_ri_mgmt_pool_high")){
						String tempNamePoolHigh = readedMgmtLine;
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_mgmt_name_pool", pool.getRi_name_pool());
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_mgmt_pool_high", pool.getRi_pool_high());
						mgmtOutputLines.add(tempNamePoolHigh);
					}
					//Sterlite_ri_mgmt_address_pool
					if(readedMgmtLine.contains("Sterlite_ri_mgmt_address_pool") && !readedMgmtLine.contains("Sterlite_ri_mgmt_name_pool")){
						String tempNamePoolAddress = readedMgmtLine;
						tempNamePoolAddress = tempNamePoolAddress.replace("Sterlite_ri_mgmt_address_pool", pool.getRi_address_pool());
						mgmtOutputLines.add(tempNamePoolAddress);
					}
					if(readedMgmtLine.contains("Sterlite_ri_pool_first_mgmtip")){
						String tempNameLoopBackPoolFirstIp = readedMgmtLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_mgmtip", pool.getRi_pool_first_ip());
						mgmtOutputLines.add(tempNameLoopBackPoolFirstIp);
					}
					
				}//End for pools
					
				//Sterlite_EthernetPort_MgmtValue.Sterlite_EthernetPort_MgmtUnitNo
				if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && !readedMgmtLine.contains("Sterlite_Uplink_MgmtInterface") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") ){
							tempInterfaceReadLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_MgmtUnitNo", uplinkInterface.getUplink_unit_no());
							mgmtOutputLines.add(tempInterfaceReadLine);
						}
						if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && readedMgmtLine.contains("Sterlite_Uplink_MgmtInterface") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") ){
							tempInterfaceReadLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_MgmtUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_MgmtInterface", uplinkInterface.getUplink_interface());
							mgmtOutputLines.add(tempInterfaceReadLine);
						}
					}//End for uplinkInterfaces
					
				}
				if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && !readedMgmtLine.contains("Sterlite_Uplink_MgmtInterface") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") ){
							tempInterfaceReadLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
							mgmtOutputLines.add(tempInterfaceReadLine);
						}
					}
					
				}
				//mgmt neighbor ip address
				if(readedMgmtLine.contains("Sterlite_Mgmt_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedMgmtLine.replace("Sterlite_Mgmt_Neighbour_Ip_Address", ipAddress);
						mgmtOutputLines.add(tempNeighborIp);
					}
				}
				// mgmt loopback
				if(readedMgmtLine.contains("Sterlite_MgmtLoopBack")){
					 String tempMgmtLoopBack = readedMgmtLine.replace("Sterlite_MgmtLoopBack", valueMgmt);
					mgmtOutputLines.add(tempMgmtLoopBack);
				}	
				// mgmt bng_as_no
				if(readedMgmtLine.contains("Sterlite_Mgmt_Bng_As_No")){
					String tempMgmtBngAsNo = readedMgmtLine.replace("Sterlite_Mgmt_Bng_As_No", bngAsNo);
					mgmtOutputLines.add(tempMgmtBngAsNo);
				}
				//MGMT uplink interface, routing-instances, route-filter
				if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("ospf")){
					String tempMgmtEthernetPortLine;
					for(String mgmtEthernetPort: mgmtEthernetPorts){
						String portValue = getInterfaceDetails(mgmtEthernetPort);
						tempMgmtEthernetPortLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
						mgmtOutputLines.add(tempMgmtEthernetPortLine);
					}
					//mgmtEthernetPorts
				}
				if(!readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("ospf")){
					mgmtOutputLines.add(readedMgmtLine);
				}
				//MGMT domain Operation_in
				if(readedMgmtLine.contains("operation.in") && domainOperationIn){
					mgmtOutputLines.add(readedMgmtLine);
				}
					
				//mgmt static lines only
				if(readedMgmtLine.contains(contextMgmt) && !readedMgmtLine.contains("operation.in") && !readedMgmtLine.contains("ospf") && !readedMgmtLine.contains("Sterlite_ri_mgmt_address_pool") && !readedMgmtLine.contains("Sterlite_ri_pool_first_mgmtip") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && !readedMgmtLine.contains("Sterlite_Uplink_MgmtInterface") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") && !readedMgmtLine.contains("Sterlite_Mgmt_Neighbour_Ip_Address") && !readedMgmtLine.contains("Sterlite_Mgmt_Bng_As_No") && !readedMgmtLine.contains("Sterlite_MgmtLoopBack") && !readedMgmtLine.contains("Sterlite_ri_mgmt_name_pool") && !readedMgmtLine.contains("Sterlite_ri_mgmt_pool_low") && !readedMgmtLine.contains("Sterlite_ri_mgmt_pool_high") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo")){
					mgmtOutputLines.add(readedMgmtLine);
				}
						
			}//End if mgmt
			else{
				//Sterlite_EthernetPort_MgmtValue.Sterlite_EthernetPort_MgmtUnitNo
				if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && !readedMgmtLine.contains("Sterlite_Uplink_MgmtInterface") && !readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") ){
							tempInterfaceReadLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_MgmtUnitNo", uplinkInterface.getUplink_unit_no());
							mgmtOutputLines.add(tempInterfaceReadLine);
						}
						
						if(readedMgmtLine.contains("Sterlite_EthernetPort_MgmtValue") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtUnitNo") && readedMgmtLine.contains("Sterlite_EthernetPort_MgmtIp_Address") ){
							tempInterfaceReadLine = readedMgmtLine.replace("Sterlite_EthernetPort_MgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_MgmtUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_MgmtIp_Address", uplinkInterface.getWan_ip_address());
							mgmtOutputLines.add(tempInterfaceReadLine);
						}
					}//End for uplinkInterfaces
					
				}//End if Sterlite_EthernetPort_MgmtValue
				
				//Sterlite_Mgmt_RouteFilter
				if(readedMgmtLine.contains("Sterlite_Mgmt_RouteFilter") && readedMgmtLine.contains("route-filter")){
					String tempMgmtRouteFilters;
					for(String mgmtRouteFilter: routeFilters){
						tempMgmtRouteFilters = readedMgmtLine.replace("Sterlite_Mgmt_RouteFilter", mgmtRouteFilter);
						mgmtOutputLines.add(tempMgmtRouteFilters);
					}
					//mgmtEthernetPorts
				}
				//Sterlite_MGMT_StaticLine
				if(readedMgmtLine.contains("Sterlite_MGMT_StaticLine")){
					String tempMgmtStaticLine = readedMgmtLine.replace("Sterlite_MGMT_StaticLine", "");
					mgmtOutputLines.add(tempMgmtStaticLine);
				}
				//MGMT domain Operation_in
				if(readedMgmtLine.contains("operation.in") && domainOperationIn){
					mgmtOutputLines.add(readedMgmtLine);
				}
			}//End else
				
			
		}//End for text file lines
			
		for(String mgmtOutputLine: mgmtOutputLines){
			try {
				br.write(mgmtOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("Mgmt File Writing Catch Block: " + e);
			}
			
		}//End for
		log.info("Mgmt File Write Ends ");	
	}
//	*************** MGMT Code End ************
	
//	*************** BSNL.IN Code ************
//	Read bsnl.in text added into list(readedL3vpnBsnlLines)
	List<String> readedBsnlInLines = new ArrayList<>();
	public void readBsnlInTextFile(){
		//Static L3vpn mgmt text file
		InputStream bsnlConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("bsnl.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(bsnlConfigFile);
		while (scannerFile.hasNextLine()) {
			readedBsnlInLines.add(scannerFile.nextLine());
		}
	}
	
//	bsnl.in Uplink
	public void readBsnlInUplinkInterfaceOverAll(String contextName){
		uplinkInterfaces = new ArrayList<>();
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				// Finding Interfaces
				String uplink = "INET-UPLINK-";
				String finalUplink ="";
				
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink + i;
							//With out wan
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
								if(uplinkInterface!=null){
									uplinkInterface.setUplink_portValue(uplinkPortValue);
									uplinkInterface.setUplink_unit_no(uplinkPvcValue);
									uplinkInterface.setUplink_vlan_id(uplinkPvcValue);
								}
								else if(uplinkInterface==null){
									UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
									uplinkInterfaces.add(upInterface);
								}
							}
						}	
						else{
							finalUplink = uplink + i;
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplinkPvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplinkPortValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface upInterface = new UplinkInterface(finalUplink, uplinkPortValue, uplinkPvcValue, uplinkPvcValue, "");
								uplinkInterfaces.add(upInterface);
							}
						}
					}
				}
			}
		}
	}
	
//	Read wan_ip_address Values based on UPLINK value
	public void readBsnlInMapForWanIpAddress(String contextName){
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				String uplink = "INET-UPLINK-";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									if(nextContextLineNo==null){
										nextContextLineNo = readedCFGLines.size();
									}
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End if
						else{
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(NAME_CONTEXT)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplinkWanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplinkWanIpWords.length; wan++){
															uplinkWanIp = uplinkWanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplinkWanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplinkWanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End else
					}// End for up to 99 uplinks
				}// End if - contextName 
			}
		}
	}
//	End uplink ip address

	//get bsnl.in values and added into list (l3vpnBsnlInOutputLines)
	private List<String> bsnlInOutputLines = new ArrayList<>();
	public void writeBsnlInData(){
		String contextBsnlIn = "bsnl.in";
		pools = new ArrayList<>();
		neighborIpAddress = new ArrayList<>();
		domains = new ArrayList<>();
		
		readWithInTheContext(contextBsnlIn);
		readBsnlInUplinkInterfaceOverAll(contextBsnlIn);
		readBsnlInMapForWanIpAddress(contextBsnlIn);
		
		//System.out.println("neighborPrefixList: " + neighborPrefixList);
		
		for(String readedBsnlInLine: readedBsnlInLines){
			//bsnl.in ri-name-pool, ri_address_pool_low, high, first values
			if(readedBsnlInLine.contains(contextBsnlIn)){
				//bsnl.in Pool values 
				for(Pool pool: pools){
					//Sterlite_ri_bsnl_address_pool, Sterlite_ri_bsnl_name_pool
					if(readedBsnlInLine.contains("Sterlite_ri_bsnl_name_pool") && readedBsnlInLine.contains("Sterlite_ri_bsnl_address_pool")){
						String tempNamePoolNameAddress = readedBsnlInLine;
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_bsnl_name_pool", pool.getRi_name_pool());
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_bsnl_address_pool", pool.getRi_address_pool());
						bsnlInOutputLines.add(tempNamePoolNameAddress);
					}
					//Sterlite_ri_bsnl_pool_low
					if(readedBsnlInLine.contains("Sterlite_ri_bsnl_name_pool") && readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_low")){
						String tempNamePoolLow = readedBsnlInLine;
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_bsnl_name_pool", pool.getRi_name_pool());
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_bsnl_pool_low", pool.getRi_pool_low());
						bsnlInOutputLines.add(tempNamePoolLow);
					}
					//Sterlite_ri_bsnl_pool_high
					if(readedBsnlInLine.contains("Sterlite_ri_bsnl_name_pool") && readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_high")){
						String tempNamePoolHigh = readedBsnlInLine;
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_bsnl_name_pool", pool.getRi_name_pool());
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_bsnl_pool_high", pool.getRi_pool_high());
						bsnlInOutputLines.add(tempNamePoolHigh);
					}
					//Sterlite_ri_bsnl_name_pool only
					if(readedBsnlInLine.contains("Sterlite_ri_bsnl_name_pool") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_address_pool") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_low") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_high")){
						String tempNamePoolName = readedBsnlInLine;
						tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_bsnl_name_pool", pool.getRi_name_pool());
						bsnlInOutputLines.add(tempNamePoolName);
					}
					
				}//End for pools
				
				//Sterlite_EthernetPort_BsnlValue.Sterlite_EthernetPort_BsnlUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedBsnlInLine.contains("Sterlite_EthernetPort_BsnlValue") && readedBsnlInLine.contains("Sterlite_EthernetPort_BsnlUnitNo") /*&& !readedL3vpnBsnlInLine.contains("Sterlite_Uplink_MgmtInterface") && !readedL3vpnBsnlInLine.contains("Sterlite_EthernetPort_MgmtIp_Address")*/ ){
						tempInterfaceReadLine = readedBsnlInLine.replace("Sterlite_EthernetPort_BsnlValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BsnlUnitNo", uplinkInterface.getUplink_unit_no());
						bsnlInOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
					
				
				//bsnl.in bng_as_no
				if(readedBsnlInLine.contains("Sterlite_bsnl_Bng_As_No")){
					String tempMgmtBngAsNo = readedBsnlInLine.replace("Sterlite_bsnl_Bng_As_No", bngAsNo);
					bsnlInOutputLines.add(tempMgmtBngAsNo);
				}
				
				//bsnl.in neighbor ip address
				if(readedBsnlInLine.contains("Sterlite_bsnl_Neighbour_Ip_Address") && readedBsnlInLine.contains("Sterlite_PrefixListNo")){
					/*for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedBsnlInLine.replace("Sterlite_bsnl_Neighbour_Ip_Address", ipAddress);
						bsnlInOutputLines.add(tempNeighborIp);
					}*/
					
					int i=1;
					for(Map.Entry<String, List<String>> entry : bsnlinSeqPermitMap.entrySet()) {
						String key = entry.getKey();
						//neighborPrefixList
						
						String tempNeighborPrefixListLine = readedBsnlInLine;
						
						for(Map.Entry<String, String> e: neighborPrefixList.entrySet()){
							String k = e.getKey();
							String v = e.getValue();
							if(key.equals(v)){
								//System.out.println("v: " + v + " k: " + k + " : i: " + i);
								
								tempNeighborPrefixListLine = readedBsnlInLine.replace("Sterlite_PrefixListNo", Integer.toString(i));
								tempNeighborPrefixListLine = tempNeighborPrefixListLine.replace("Sterlite_bsnl_Neighbour_Ip_Address", k);
								bsnlInOutputLines.add(tempNeighborPrefixListLine);
								
							}
						}
						
						//neighborPrefixList.entrySet().stream().forEach(e -> System.out.println(e.getKey() + " : " + e.getValue()) );
						
						i++;
					}
				}
				//bsnl.in domains
				if(readedBsnlInLine.contains("Sterlite_BsnlIn_Domain")){
					for(String domain: domains){
						String tempDomain;
						tempDomain = readedBsnlInLine.replace("Sterlite_BsnlIn_Domain", domain);
						bsnlInOutputLines.add(tempDomain);
					}
				}
				
				
				//bsnl.in static lines only
				if(readedBsnlInLine.contains(contextBsnlIn) && !readedBsnlInLine.contains("Sterlite_PrefixListNo") && !readedBsnlInLine.contains("Sterlite_BsnlIn_Domain") && !readedBsnlInLine.contains("Sterlite_bsnl_Neighbour_Ip_Address") && !readedBsnlInLine.contains("Sterlite_bsnl_Bng_As_No") && !readedBsnlInLine.contains("Sterlite_EthernetPort_BsnlValue") && !readedBsnlInLine.contains("Sterlite_EthernetPort_BsnlUnitNo") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_address_pool") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_name_pool") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_low") && !readedBsnlInLine.contains("Sterlite_ri_bsnl_pool_high")){
					bsnlInOutputLines.add(readedBsnlInLine);
				}
				
			}//End if readedL3vpnBsnlInLine.contains("bsnl.in")
			else {// not bsnl.in lines
				
				//bsnl.in pools
				for(Pool pool: pools){
					if(readedBsnlInLine.contains("Sterlite_ri_pool_first_bsnlip")){
						String tempNameLoopBackPoolFirstIp = readedBsnlInLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_bsnlip", pool.getRi_pool_first_ip());
						bsnlInOutputLines.add(tempNameLoopBackPoolFirstIp);
					}
				}//End pools
				
				//Sterlite_PrefixListNo Sterlite_PrefixListIpAddress
				if(readedBsnlInLine.contains("Sterlite_PrefixListNo") && readedBsnlInLine.contains("Sterlite_PrefixListIpAddress")) {
					//bsnlinSeqPermitMap
					int i=1;
					for(Map.Entry<String, List<String>> entry : bsnlinSeqPermitMap.entrySet()) {
						String key = entry.getKey();
						//neighborPrefixList
						
						String tempNeighborPrefixListLine = readedBsnlInLine;
						
						for(Map.Entry<String, String> e: neighborPrefixList.entrySet()){
							String k = e.getKey();
							String v = e.getValue();
							if(key.equals(v)){
								//System.out.println("v: " + v + " k: " + k + " : i: " + i);
								
								tempNeighborPrefixListLine = readedBsnlInLine.replace("Sterlite_PrefixListNo", Integer.toString(i));
								tempNeighborPrefixListLine = tempNeighborPrefixListLine.replace("Sterlite_bsnl_Neighbour_Ip_Address", k);
								bsnlInOutputLines.add(tempNeighborPrefixListLine);
								
							}
						}
						
						//neighborPrefixList.entrySet().stream().forEach(e -> System.out.println(e.getKey() + " : " + e.getValue()) );
						
						String tempPrefixListLine = readedBsnlInLine;
						for (String value : entry.getValue()) {
							tempPrefixListLine = readedBsnlInLine.replace("Sterlite_PrefixListNo", Integer.toString(i));
							tempPrefixListLine = tempPrefixListLine.replace("Sterlite_PrefixListIpAddress", value);
							bsnlInOutputLines.add(tempPrefixListLine);
							
						}
						i++;
					}
					
				}
				
				
				
				//bsnl.in StaticLine
				if(!readedBsnlInLine.contains(contextBsnlIn) && !readedBsnlInLine.contains("Sterlite_PrefixListNo") && !readedBsnlInLine.contains("Sterlite_PrefixListIpAddress") && !readedBsnlInLine.contains("Sterlite_ri_pool_first_bsnlip")){
					bsnlInOutputLines.add(readedBsnlInLine);
				}
			}
		}//End for readedL3vpnBsnlInLines
		
		for(String bsnlInOutputLine: bsnlInOutputLines) {
			try {
				br.write(bsnlInOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("Bsnl.in Write File Catch Block: " + e);
			}
		}
	}//End WriteL3vpnBsnlInData()
	
//	*************** BSNL.IN Code End ************
	
//	*************** VoipCdot Code Start ************
//	Read VoipCdot text added into list(readedL3vpnVoipCdotLines)
	List<String> readedVoipCdotLines = new ArrayList<>();
	public void readVoipCdotTextFile(){
		//Static L3vpn VoipCdot text file
		InputStream voipCdotConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("voip-cdot.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(voipCdotConfigFile);
		while (scannerFile.hasNextLine()) {
			readedVoipCdotLines.add(scannerFile.nextLine());
		}
	}
	
//	get VoipCdot values and added into list (l3vpnVoipCdotOutputLines)
	private List<String> voipCdotOutputLines = new ArrayList<>();
	public void writeVoipCdotData(){
		String contextVoipCdot = "voip-cdot";
		neighborIpAddress = new ArrayList<>();
		
		readWithInTheContext(contextVoipCdot);
		readUplinkInterfaceOverAll(contextVoipCdot);
		readMapForWanIpAddress(contextVoipCdot);
		for(String readedVoipCdotLine: readedVoipCdotLines){
			if(readedVoipCdotLine.contains("voip-cdot")){
				//VoipCdot bng_as_no
				if(readedVoipCdotLine.contains("Sterlite_VoipCdot_Bng_As_No")){
					String tempVoipCdotBngAsNo = readedVoipCdotLine.replace("Sterlite_VoipCdot_Bng_As_No", bngAsNo);
					voipCdotOutputLines.add(tempVoipCdotBngAsNo);
				}
				
				//VoipCdot neighbor ip address
				if(readedVoipCdotLine.contains("Sterlite_VoipCdot_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedVoipCdotLine.replace("Sterlite_VoipCdot_Neighbour_Ip_Address", ipAddress);
						voipCdotOutputLines.add(tempNeighborIp);
					}
				}
				
				//Sterlite_EthernetPort_VoipCdotValue.Sterlite_EthernetPort_VoipCdotUnitNo
				if(readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") && !readedVoipCdotLine.contains("Sterlite_Uplink_VoipCdotInterface") ){
							tempInterfaceReadLine = readedVoipCdotLine.replace("Sterlite_EthernetPort_VoipCdotValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_VoipCdotUnitNo", uplinkInterface.getUplink_unit_no());
							voipCdotOutputLines.add(tempInterfaceReadLine);
						}
						if(readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") && readedVoipCdotLine.contains("Sterlite_Uplink_VoipCdotInterface") ){
							tempInterfaceReadLine = readedVoipCdotLine.replace("Sterlite_EthernetPort_VoipCdotValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_VoipCdotUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_VoipCdotInterface",  uplinkInterface.getUplink_interface());
							voipCdotOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//VoipCdot static lines only
				if(readedVoipCdotLine.contains("voip-cdot") && !readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && !readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") && !readedVoipCdotLine.contains("Sterlite_VoipCdot_Bng_As_No") && !readedVoipCdotLine.contains("Sterlite_VoipCdot_Neighbour_Ip_Address") ){
					voipCdotOutputLines.add(readedVoipCdotLine);
				}
				
			}//End if VoipCdot contains
			else{
				//Sterlite_EthernetPort_VoipCdotValue.Sterlite_EthernetPort_VoipCdotUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") && !readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotIp_Address") ){
						tempInterfaceReadLine = readedVoipCdotLine.replace("Sterlite_EthernetPort_VoipCdotValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_VoipCdotUnitNo", uplinkInterface.getUplink_unit_no());
						voipCdotOutputLines.add(tempInterfaceReadLine);
					}
					if(readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") && readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotIp_Address") ){
						tempInterfaceReadLine = readedVoipCdotLine.replace("Sterlite_EthernetPort_VoipCdotValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_VoipCdotUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_VoipCdotIp_Address", uplinkInterface.getWan_ip_address());
						voipCdotOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				
				//VoipCdot StaticLine
				if(!readedVoipCdotLine.contains("voip-cdot") && !readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotValue") && !readedVoipCdotLine.contains("Sterlite_EthernetPort_VoipCdotUnitNo") ){
					voipCdotOutputLines.add(readedVoipCdotLine);
				}//End if StaticLines
				
			}
			
		}//End for readedL3vpnVoipCdotLines
		
		for(String voipCdotOutputLine: voipCdotOutputLines) {
			try {
				br.write(voipCdotOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("VoipCdot File Write Catch Block: " + e);
			}
		}
		
		
	}//WriteL3vpnVoipCdotData
	
//	*************** VoipCdot Code End ************
	
//	*************** WIFI-Offload Code Starts ************
//	Read WIFI-Offload text added into list(readedL3vpnVoipCdotLines)
	List<String> readedWifiOffloadLines = new ArrayList<>();
	public void readWifiOffloadTextFile(){
		//Static L3vpn VoipCdot text file
		InputStream wifiOffloadConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("wifi-offload.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(wifiOffloadConfigFile);
		while (scannerFile.hasNextLine()) {
			readedWifiOffloadLines.add(scannerFile.nextLine());
		}
	}

//	get VoipCdot values and added into list (l3vpnVoipCdotOutputLines)
	private List<String> wifiOffloadOutputLines = new ArrayList<>();
	public void writeWifiOffloadData(){
		log.info("Wifi-Offload File Write Starts");
		String contextWifiOffload = "WIFI-Offload";
		neighborIpAddress = new ArrayList<>();
		
		readWithInTheContext(contextWifiOffload);
		readUplinkInterfaceOverAll(contextWifiOffload);
		readMapForWanIpAddress(contextWifiOffload);
		
		for(String readedWifiOffloadLine: readedWifiOffloadLines){
			if(readedWifiOffloadLine.contains(contextWifiOffload)){
				//VoipCdot bng_as_no
				if(readedWifiOffloadLine.contains("Sterlite_WifiOffload_Bng_As_No")){
					String tempVoipCdotBngAsNo = readedWifiOffloadLine.replace("Sterlite_WifiOffload_Bng_As_No", bngAsNo);
					wifiOffloadOutputLines.add(tempVoipCdotBngAsNo);
				}
				
				//VoipCdot neighbor ip address
				if(readedWifiOffloadLine.contains("Sterlite_WifiOffload_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedWifiOffloadLine.replace("Sterlite_WifiOffload_Neighbour_Ip_Address", ipAddress);
						wifiOffloadOutputLines.add(tempNeighborIp);
					}
				}
				
				//Sterlite_EthernetPort_WifiOffloadValue.Sterlite_EthernetPort_WifiOffloadUnitNo
				if(readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") && !readedWifiOffloadLine.contains("Sterlite_Uplink_WifiOffloadInterface") ){
							tempInterfaceReadLine = readedWifiOffloadLine.replace("Sterlite_EthernetPort_WifiOffloadValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiOffloadUnitNo", uplinkInterface.getUplink_unit_no());
							wifiOffloadOutputLines.add(tempInterfaceReadLine);
						}
						if(readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") && readedWifiOffloadLine.contains("Sterlite_Uplink_WifiOffloadInterface") ){
							tempInterfaceReadLine = readedWifiOffloadLine.replace("Sterlite_EthernetPort_WifiOffloadValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiOffloadUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_WifiOffloadInterface",  uplinkInterface.getUplink_interface());
							wifiOffloadOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//WifiOffload static lines only
				if(readedWifiOffloadLine.contains("WIFI-Offload") && !readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && !readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") && !readedWifiOffloadLine.contains("Sterlite_WifiOffload_Bng_As_No") && !readedWifiOffloadLine.contains("Sterlite_WifiOffload_Neighbour_Ip_Address") ){
					wifiOffloadOutputLines.add(readedWifiOffloadLine);
				}
				
			}//End if WifiOffload contains
			else{
				//Sterlite_EthernetPort_WifiOffloadValue.Sterlite_EthernetPort_WifiOffloadUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") && !readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadIp_Address") ){
						tempInterfaceReadLine = readedWifiOffloadLine.replace("Sterlite_EthernetPort_WifiOffloadValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiOffloadUnitNo", uplinkInterface.getUplink_unit_no());
						wifiOffloadOutputLines.add(tempInterfaceReadLine);
					}
					if(readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") && readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadIp_Address") ){
						tempInterfaceReadLine = readedWifiOffloadLine.replace("Sterlite_EthernetPort_WifiOffloadValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiOffloadUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiOffloadIp_Address", uplinkInterface.getWan_ip_address());
						wifiOffloadOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				
				//WifiOffload StaticLine
				if(!readedWifiOffloadLine.contains("WIFI-Offload") && !readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadValue") && !readedWifiOffloadLine.contains("Sterlite_EthernetPort_WifiOffloadUnitNo") ){
					wifiOffloadOutputLines.add(readedWifiOffloadLine);
				}//End if StaticLines
				
			}
			
		}//End for l3vpnWifiOffloadOutputLines
		
		for(String wifiOffloadOutputLine: wifiOffloadOutputLines) {
			try {
				br.write(wifiOffloadOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("Wifi-Offload File Write Catch Block: " + e);
			}
		}
		log.info("Wifi-Offload File Write End");
	}//WriteL3vpnWifiOffloadData
	
//	*************** WIFI-Offload Code End ************
	
//	*************** Wifi-Data Code Starts ************
//	Read Wifi-Data text added into list(readedL3vpnVoipCdotLines)
	List<String> readedWifiDataLines = new ArrayList<>();
	public void readWifiDataTextFile(){
		//Static Wifi-Data text file
		InputStream wifiDataConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("wifi-data.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(wifiDataConfigFile);
		while (scannerFile.hasNextLine()) {
			readedWifiDataLines.add(scannerFile.nextLine());
		}
	}

//	get Wifi-Data values and added into list (l3vpnVoipCdotOutputLines)
	private List<String> wifiDataOutputLines = new ArrayList<>();
	public void writeWifiDataData(){
		log.info("Wifi-Data File Write Starts");
		String contextWifiData = "wifi-data";
		neighborIpAddress = new ArrayList<>();
		
		readWithInTheContext(contextWifiData);
		readUplinkInterfaceOverAll(contextWifiData);
		readMapForWanIpAddress(contextWifiData);
		
		for(String readedWifiDataLine: readedWifiDataLines){
			if(readedWifiDataLine.contains(contextWifiData)){
				//WifiData bng_as_no
				if(readedWifiDataLine.contains("Sterlite_WifiData_Bng_As_No")){
					String tempBngAsNo = readedWifiDataLine.replace("Sterlite_WifiData_Bng_As_No", bngAsNo);
					wifiDataOutputLines.add(tempBngAsNo);
				}
				//WifiData dhcpServer
				if(readedWifiDataLine.contains("Sterlite_WifiData_DhcpServer_IpAddress")){
					try{
						String tempWifiDataDhcpServer = readedWifiDataLine.replace("Sterlite_WifiData_DhcpServer_IpAddress", dhcpServer);
						wifiDataOutputLines.add(tempWifiDataDhcpServer);
					}
					catch(NullPointerException ne){
						continue;
					}
				}
				
				//WifiData neighbor ip address
				if(readedWifiDataLine.contains("Sterlite_WifiData_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedWifiDataLine.replace("Sterlite_WifiData_Neighbour_Ip_Address", ipAddress);
						wifiDataOutputLines.add(tempNeighborIp);
					}
				}
				//WifiData QUAD-WIFI ip address
				if(readedWifiDataLine.contains("Sterlite_WifiData_QuadFirstIp_Address")){
					for(String quadIpAddress: quadWifiIpAddress){
						String tempQuadIp;
						//get Quad-Wifi ipAddress -1 value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(quadIpAddress);
						String quadFirstIp = subnetIpAddress.getInfo().getLowAddress();
						String subnet[] = subnetIpAddress.getInfo().getLowAddress().split("\\/");
						String subnetValue = "";
						for(int sub=0; sub<subnet.length; sub++){
							subnetValue = subnet[0];
						}
						String low[] = subnetValue.split("\\.");
						int lowValue = Integer.parseInt(low[low.length-1]);
						String subLow = quadFirstIp.substring(0, quadFirstIp.lastIndexOf('.'));
						
						String quadFirstValue = subLow+"."+(lowValue-1);
						// ipAddress / value
						String ss[] = quadIpAddress.split("\\/");
						
						tempQuadIp = readedWifiDataLine.replace("Sterlite_WifiData_QuadFirstIp_Address", quadFirstValue+"/"+ss[1]);
						wifiDataOutputLines.add(tempQuadIp);
					}
				}
				
				//Sterlite_EthernetPort_WifiDataValue.Sterlite_EthernetPort_WifiDataUnitNo
				if(readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") && !readedWifiDataLine.contains("Sterlite_Uplink_WifiDataInterface") ){
							tempInterfaceReadLine = readedWifiDataLine.replace("Sterlite_EthernetPort_WifiDataValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiDataUnitNo", uplinkInterface.getUplink_unit_no());
							wifiDataOutputLines.add(tempInterfaceReadLine);
						}
						if(readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") && readedWifiDataLine.contains("Sterlite_Uplink_WifiDataInterface") ){
							tempInterfaceReadLine = readedWifiDataLine.replace("Sterlite_EthernetPort_WifiDataValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiDataUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_WifiDataInterface",  uplinkInterface.getUplink_interface());
							wifiDataOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//WifiData static lines only
				if(readedWifiDataLine.contains(contextWifiData) && !readedWifiDataLine.contains("Sterlite_WifiData_QuadFirstIp_Address") && !readedWifiDataLine.contains("Sterlite_WifiData_DhcpServer_IpAddress") && !readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && !readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") && !readedWifiDataLine.contains("Sterlite_WifiData_Bng_As_No") && !readedWifiDataLine.contains("Sterlite_WifiData_Neighbour_Ip_Address") ){
					wifiDataOutputLines.add(readedWifiDataLine);
				}
				
			}//End if WifiData contains
			else{
				//Sterlite_EthernetPort_WifiOffloadValue.Sterlite_EthernetPort_WifiOffloadUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") && !readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataIp_Address") ){
						tempInterfaceReadLine = readedWifiDataLine.replace("Sterlite_EthernetPort_WifiDataValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiDataUnitNo", uplinkInterface.getUplink_unit_no());
						wifiDataOutputLines.add(tempInterfaceReadLine);
					}
					if(readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") && readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataIp_Address") ){
						tempInterfaceReadLine = readedWifiDataLine.replace("Sterlite_EthernetPort_WifiDataValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiDataUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiDataIp_Address", uplinkInterface.getWan_ip_address());
						wifiDataOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				//WifiData QUAD-WIFI ip address
				if(readedWifiDataLine.contains("Sterlite_WifiData_QuadIp_Address")){
					for(String quadIpAddress: quadWifiIpAddress){
						String tempQuadIp;
						//get Quad-Wifi ipAddress value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(quadIpAddress);
						tempQuadIp = readedWifiDataLine.replace("Sterlite_WifiData_QuadIp_Address", subnetIpAddress.getInfo().getLowAddress());
						wifiDataOutputLines.add(tempQuadIp);
					}
				}
				
				
				//WifiData StaticLine
				if(!readedWifiDataLine.contains(contextWifiData) && !readedWifiDataLine.contains("Sterlite_WifiData_QuadIp_Address") && !readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataValue") && !readedWifiDataLine.contains("Sterlite_EthernetPort_WifiDataUnitNo") ){
					wifiDataOutputLines.add(readedWifiDataLine);
				}//End if StaticLines
				
			}
			
		}//End for wifiDataOutputLines
		
		for(String wifiDataOutputLine: wifiDataOutputLines) {
			try {
				br.write(wifiDataOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("Wifi-Data File Write Catch Block: " + e);
			}
		}
		log.info("Wifi-Data File Write End");
	}//WriteWifiDataData
	
//	*************** Wifi-Data Code End ************
	
//	*************** Prepaid Code Starts ************
//	Read Prepaid text added into list(readedPrepaidLines)
	List<String> readedPrepaidLines = new ArrayList<>();
	public void readPrepaidTextFile(){
		//Static Prepaid text file
		InputStream prepaidConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("prepaid.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(prepaidConfigFile);
		while (scannerFile.hasNextLine()) {
			readedPrepaidLines.add(scannerFile.nextLine());
		}
	}
	
//	get Prepaid values and added into list (prepaidOutputLines)
	private List<String> prepaidOutputLines = new ArrayList<>();
	public void writePrepaidData(){
		log.info("Prepaid ppbb.bsnl.in File Write Starts");
		String contextPrepaid = "ppbb.bsnl.in";
		pools = new ArrayList<>();
		readWithInTheContext(contextPrepaid);
		
		for(String readedPrepaidLine: readedPrepaidLines){
			if(readedPrepaidLine.contains(contextPrepaid)){
				for(Pool pool: pools){
					//Sterlite_ri_Prepaid_address_pool, Sterlite_ri_Prepaid_name_pool
					if(readedPrepaidLine.contains("Sterlite_ri_Prepaid_name_pool") && readedPrepaidLine.contains("Sterlite_ri_Prepaid_address_pool")){
						String tempNamePoolNameAddress = readedPrepaidLine;
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_Prepaid_name_pool", pool.getRi_name_pool());
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_Prepaid_address_pool", pool.getRi_address_pool());
						prepaidOutputLines.add(tempNamePoolNameAddress);
					}
					//Sterlite_ri_Prepaid_pool_low
					if(readedPrepaidLine.contains("Sterlite_ri_Prepaid_name_pool") && readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_low")){
						String tempNamePoolLow = readedPrepaidLine;
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_Prepaid_name_pool", pool.getRi_name_pool());
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_Prepaid_pool_low", pool.getRi_pool_low());
						prepaidOutputLines.add(tempNamePoolLow);
					}
					//Sterlite_ri_Prepaid_pool_high
					if(readedPrepaidLine.contains("Sterlite_ri_Prepaid_name_pool") && readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_high")){
						String tempNamePoolHigh = readedPrepaidLine;
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_Prepaid_name_pool", pool.getRi_name_pool());
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_Prepaid_pool_high", pool.getRi_pool_high());
						prepaidOutputLines.add(tempNamePoolHigh);
					}
					//Sterlite_ri_Prepaid_address_pool only
					if(readedPrepaidLine.contains("Sterlite_ri_Prepaid_address_pool") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_name_pool") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_low") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_high")){
						String tempNamePoolName = readedPrepaidLine;
						tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_Prepaid_address_pool", pool.getRi_address_pool());
						prepaidOutputLines.add(tempNamePoolName);
					}
					
				}//End for pools
				
				//Prepaid static lines only
				if(readedPrepaidLine.contains(contextPrepaid) && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_name_pool") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_address_pool") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_low") && !readedPrepaidLine.contains("Sterlite_ri_Prepaid_pool_high") ){
					prepaidOutputLines.add(readedPrepaidLine);
				}
				
			}//End if Prepaid contains
			else{
				for(Pool pool: pools){
					//loop back, ri pool first ip address
					if(!readedPrepaidLine.contains("contextPrepaid") && readedPrepaidLine.contains("Sterlite_ri_pool_first_Prepaidip")){
						String tempNameLoopBackPoolFirstIp = readedPrepaidLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_Prepaidip", pool.getRi_pool_first_ip());
						prepaidOutputLines.add(tempNameLoopBackPoolFirstIp);
					}
				}//End for pools
				
				//Prepaid ppbbIpAddress
				if(readedPrepaidLine.contains("Sterlite_Ppbb_Loopback_IpAddress")){
					String temPppbbIpAddress = readedPrepaidLine.replace("Sterlite_Ppbb_Loopback_IpAddress", ppbbIpAddress);
					prepaidOutputLines.add(temPppbbIpAddress);
				}
				
				//Prepaid StaticLine
				if(!readedPrepaidLine.contains(contextPrepaid) && !readedPrepaidLine.contains("Sterlite_Ppbb_Loopback_IpAddress") && !readedPrepaidLine.contains("Sterlite_ri_pool_first_Prepaidip") ){
					prepaidOutputLines.add(readedPrepaidLine);
				}//End if StaticLines
				
			}
			
		}//End for prepaidOutputLines
		
		for(String prepaidOutputLine: prepaidOutputLines) {
			try {
				br.write(prepaidOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("Prepaid File Write Catch Block: " + e);
			}
		}
		log.info("Prepaid File Write End");
	}//WritePrepaidData
	
//	*************** Prepaid Code Ends ************	
	
//	*************** ftth.lfmt.in Code Starts ************
//	Read ftth.lfmt.in text added into list(readeFtthLfmtInLines)
	List<String> readedFtthLfmtInLines = new ArrayList<>();
	public void readedFtthLfmtInTextFile(){
		//Static ftth.lfmt.in text file
		InputStream ftthLfmtInConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("ftth_lfmt_in.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(ftthLfmtInConfigFile);
		while (scannerFile.hasNextLine()) {
			readedFtthLfmtInLines.add(scannerFile.nextLine());
		}
	}
	
//	get ftth.lfmt.in values and added into list (ftthLfmtInOutputLines)
	private List<String> ftthLfmtInOutputLines = new ArrayList<>();
	public void writeFtthLfmtInData(){
		log.info("ftth.lfmt.in File Write Starts");
		String contextFtthLfmtIn = "ftth.lfmt.in";
		pools = new ArrayList<>();
		readWithInTheContext(contextFtthLfmtIn);
		
		for(String readedFtthLfmtInLine: readedFtthLfmtInLines){
			if(readedFtthLfmtInLine.contains(contextFtthLfmtIn)){
				for(Pool pool: pools){
					//Sterlite_ri_Prepaid_address_pool, Sterlite_ri_Prepaid_name_pool
					if(readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_name_pool") && readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_address_pool")){
						String tempNamePoolNameAddress = readedFtthLfmtInLine;
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_FfthLfmtIn_name_pool", pool.getRi_name_pool());
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_FfthLfmtIn_address_pool", pool.getRi_address_pool());
						ftthLfmtInOutputLines.add(tempNamePoolNameAddress);
					}
					//Sterlite_ri_Prepaid_pool_low
					if(readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_name_pool") && readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_low")){
						String tempNamePoolLow = readedFtthLfmtInLine;
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_FfthLfmtIn_name_pool", pool.getRi_name_pool());
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_FfthLfmtIn_pool_low", pool.getRi_pool_low());
						ftthLfmtInOutputLines.add(tempNamePoolLow);
					}
					//Sterlite_ri_Prepaid_pool_high
					if(readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_name_pool") && readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_high")){
						String tempNamePoolHigh = readedFtthLfmtInLine;
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_FfthLfmtIn_name_pool", pool.getRi_name_pool());
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_FfthLfmtIn_pool_high", pool.getRi_pool_high());
						ftthLfmtInOutputLines.add(tempNamePoolHigh);
					}
					//Sterlite_ri_Prepaid_address_pool only
					if(readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_address_pool") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_name_pool") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_low") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_high")){
						String tempNamePoolName = readedFtthLfmtInLine;
						tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_FfthLfmtIn_address_pool", pool.getRi_address_pool());
						ftthLfmtInOutputLines.add(tempNamePoolName);
					}
					
				}//End for pools
				
				//ftth.lfmt.in static lines only
				if(readedFtthLfmtInLine.contains(contextFtthLfmtIn) && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_name_pool") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_address_pool") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_low") && !readedFtthLfmtInLine.contains("Sterlite_ri_FfthLfmtIn_pool_high") ){
					ftthLfmtInOutputLines.add(readedFtthLfmtInLine);
				}
				
			}//End if ftth.lfmt.in contains
			else{
				for(Pool pool: pools){
					//loop back, ri pool first ip address
					if(!readedFtthLfmtInLine.contains("contextPrepaid") && readedFtthLfmtInLine.contains("Sterlite_ri_pool_first_FfthLfmtIn_ip")){
						String tempNameLoopBackPoolFirstIp = readedFtthLfmtInLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_FfthLfmtIn_ip", pool.getRi_pool_first_ip());
						ftthLfmtInOutputLines.add(tempNameLoopBackPoolFirstIp);
					}
				}//End for pools
				
				//ftth.lfmt.in StaticLine
				if(!readedFtthLfmtInLine.contains(contextFtthLfmtIn) && !readedFtthLfmtInLine.contains("Sterlite_ri_pool_first_FfthLfmtIn_ip") ){
					ftthLfmtInOutputLines.add(readedFtthLfmtInLine);
				}//End if StaticLines
				
			}
			
		}//End for readedFtthLfmtInLines
		
		for(String ftthLfmtInOutputLine: ftthLfmtInOutputLines) {
			try {
				br.write(ftthLfmtInOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("ftth.lfmt.in File Write Catch Block: " + e);
			}
		}
		log.info("ftth.lfmt.in File Write End");
	}//WriteFtthLfmtInData
	
//	*************** ftth.lfmt.in Code Ends ************	
	
//	*************** ftth.bsnl.in Code Starts ************
//	Read ftth.bsnl.in text added into list(readeFtthLfmtInLines)
	List<String> readedFtthBsnlInLines = new ArrayList<>();
	public void readedFtthBsnlInTextFile(){
		//Static ftth.bsnl.in text file
		InputStream ftthBsnlInConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("ftth_bsnl_in.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(ftthBsnlInConfigFile);
		while (scannerFile.hasNextLine()) {
			readedFtthBsnlInLines.add(scannerFile.nextLine());
		}
	}
	
//	get ftth.bsnl.in values and added into list (ftthBsnlInOutputLines)
	private List<String> ftthBsnlInOutputLines = new ArrayList<>();
	public void writeFtthBsnlInData(){
		log.info("ftth.bsnl.in File Write Starts");
		String contextFtthBsnlIn = "ftth.bsnl.in";
		pools = new ArrayList<>();
		readWithInTheContext(contextFtthBsnlIn);
		
		for(String readedFtthBsnlInLine: readedFtthBsnlInLines){
			if(readedFtthBsnlInLine.contains(contextFtthBsnlIn)){
				String tempPool = null;
				for(Pool pool: pools){
					//Sterlite_ri_Prepaid_address_pool, Sterlite_ri_Prepaid_name_pool
					if(readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_address_pool")){
						String tempNamePoolNameAddress = readedFtthBsnlInLine;
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_FfthBsnlIn_name_pool", pool.getRi_name_pool());
						tempNamePoolNameAddress = tempNamePoolNameAddress.replace("Sterlite_ri_FfthBsnlIn_address_pool", pool.getRi_address_pool());
						ftthBsnlInOutputLines.add(tempNamePoolNameAddress);
					}
					//Sterlite_ri_Prepaid_pool_low
					if(readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_low")){
						String tempNamePoolLow = readedFtthBsnlInLine;
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_FfthBsnlIn_name_pool", pool.getRi_name_pool());
						tempNamePoolLow = tempNamePoolLow.replace("Sterlite_ri_FfthBsnlIn_pool_low", pool.getRi_pool_low());
						ftthBsnlInOutputLines.add(tempNamePoolLow);
					}
					//Sterlite_ri_Prepaid_pool_high
					if(readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_high")){
						String tempNamePoolHigh = readedFtthBsnlInLine;
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_FfthBsnlIn_name_pool", pool.getRi_name_pool());
						tempNamePoolHigh = tempNamePoolHigh.replace("Sterlite_ri_FfthBsnlIn_pool_high", pool.getRi_pool_high());
						ftthBsnlInOutputLines.add(tempNamePoolHigh);
					}
					//Sterlite_ri_Prepaid_address_pool only
					if(readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_address_pool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_low") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_high")){
						String tempNamePoolName = readedFtthBsnlInLine;
						tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_FfthBsnlIn_address_pool", pool.getRi_address_pool());
						ftthBsnlInOutputLines.add(tempNamePoolName);
					}
					
					//Sterlite_ri_FfthBsnlIn_name_OnePool link Sterlite_ri_FfthBsnlIn_name_TwoPool
					
					if(tempPool!=null){
						if(readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_OnePool") && readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_TwoPool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_low") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_high")){
							String tempNamePoolName = readedFtthBsnlInLine;
							tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_FfthBsnlIn_name_OnePool", tempPool);
							tempNamePoolName = tempNamePoolName.replace("Sterlite_ri_FfthBsnlIn_name_TwoPool", pool.getRi_name_pool());
							ftthBsnlInOutputLines.add(tempNamePoolName);
						}
					}
					tempPool = pool.getRi_name_pool();
				}//End for pools
				
				//ftth.bsnl.in static lines only
				if(readedFtthBsnlInLine.contains(contextFtthBsnlIn) && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_OnePool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_TwoPool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_name_pool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_address_pool") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_low") && !readedFtthBsnlInLine.contains("Sterlite_ri_FfthBsnlIn_pool_high") ){
					ftthBsnlInOutputLines.add(readedFtthBsnlInLine);
				}
				
			}//End if ftth.bsnl.in contains
			else{
				for(Pool pool: pools){
					//loop back, ri pool first ip address
					if(!readedFtthBsnlInLine.contains("contextPrepaid") && readedFtthBsnlInLine.contains("Sterlite_ri_pool_first_FfthBsnlIn_ip")){
						String tempNameLoopBackPoolFirstIp = readedFtthBsnlInLine;
						tempNameLoopBackPoolFirstIp = tempNameLoopBackPoolFirstIp.replace("Sterlite_ri_pool_first_FfthBsnlIn_ip", pool.getRi_pool_first_ip());
						ftthBsnlInOutputLines.add(tempNameLoopBackPoolFirstIp);
					}
				}//End for pools
				
				//ftth.bsnl.in StaticLine
				if(!readedFtthBsnlInLine.contains(contextFtthBsnlIn) && !readedFtthBsnlInLine.contains("Sterlite_ri_pool_first_FfthBsnlIn_ip") ){
					ftthBsnlInOutputLines.add(readedFtthBsnlInLine);
				}//End if StaticLines
			}
			
		}//End for ftthBsnlInOutputLines
		
		for(String ftthBsnlInOutputLine: ftthBsnlInOutputLines) {
			try {
				br.write(ftthBsnlInOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("ftth.bsnl.in File Write Catch Block: " + e);
			}
		}
		log.info("ftth.bsnl.in File Write End");
	}//writeFtthBsnlInData
	
//	*************** ftth.bsnl.in Code Ends ************	
	
//	*************** wifi-mgmt Code Starts ************
//	Read wifi-mgmt text added into list(readedWifiMgmtLines)
	List<String> readedWifiMgmtLines = new ArrayList<>();
	public void readedWifiMgmtTextFile(){
		//Static Wifi-Mgmt text file
		InputStream wifiMgmtConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("wifi_mgmt.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(wifiMgmtConfigFile);
		while (scannerFile.hasNextLine()) {
			readedWifiMgmtLines.add(scannerFile.nextLine());
		}
	}
	
//	get wifi-mgmt values and added into list (wifiMgmtOutputLines)
	private List<String> wifiMgmtOutputLines = new ArrayList<>();
	public void writeWifiMgmtData(){
		log.info("wifi-mgmt File Write Starts");
		String contextWifiMgmt = "wifi-mgmt";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextWifiMgmt);
		readUplinkInterfaceOverAll(contextWifiMgmt);
		readMapForWanIpAddress(contextWifiMgmt);
		
		for(String readedWifiMgmtLine: readedWifiMgmtLines){
			if(readedWifiMgmtLine.contains(contextWifiMgmt)){
				
				//wifi-mgmt bng_as_no
				if(readedWifiMgmtLine.contains("Sterlite_WifiMgmt_Bng_As_No")){
					String tempWifiMgmtBngAsNo = readedWifiMgmtLine.replace("Sterlite_WifiMgmt_Bng_As_No", bngAsNo);
					wifiMgmtOutputLines.add(tempWifiMgmtBngAsNo);
				}
				
				//wifi-mgmt neighbor ip address
				if(readedWifiMgmtLine.contains("Sterlite_WifiMgmt_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedWifiMgmtLine.replace("Sterlite_WifiMgmt_Neighbour_Ip_Address", ipAddress);
						wifiMgmtOutputLines.add(tempNeighborIp);
					}
				}
				
				//Sterlite_EthernetPort_WifiMgmtValue.Sterlite_EthernetPort_WifiMgmtUnitNo
				if(readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						
						if(readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo") && readedWifiMgmtLine.contains("Sterlite_Uplink_WifiMgmtInterface") ){
							tempInterfaceReadLine = readedWifiMgmtLine.replace("Sterlite_EthernetPort_WifiMgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiMgmtUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_WifiMgmtInterface",  uplinkInterface.getUplink_interface());
							wifiMgmtOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//wifi-mgmt static lines only
				if(readedWifiMgmtLine.contains(contextWifiMgmt) && !readedWifiMgmtLine.contains("Sterlite_Uplink_WifiMgmtInterface") && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo") && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && !readedWifiMgmtLine.contains("Sterlite_WifiMgmt_Neighbour_Ip_Address") && !readedWifiMgmtLine.contains("Sterlite_WifiMgmt_Bng_As_No") ){
					wifiMgmtOutputLines.add(readedWifiMgmtLine);
				}
				
			}//End if Prepaid contains
			else{
				//Sterlite_EthernetPort_WifiMgmtValue.Sterlite_EthernetPort_WifiMgmtUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo") && readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtIp_Address") ){
						tempInterfaceReadLine = readedWifiMgmtLine.replace("Sterlite_EthernetPort_WifiMgmtValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiMgmtUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiMgmtIp_Address", uplinkInterface.getWan_ip_address());
						wifiMgmtOutputLines.add(tempInterfaceReadLine);
					}
					if(readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo") && !readedWifiMgmtLine.contains("Sterlite_Uplink_WifiMgmtInterface") && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtIp_Address") ){
						tempInterfaceReadLine = readedWifiMgmtLine.replace("Sterlite_EthernetPort_WifiMgmtValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_WifiMgmtUnitNo", uplinkInterface.getUplink_unit_no());
						wifiMgmtOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				//wifi-mgmt StaticLine
				if(!readedWifiMgmtLine.contains(contextWifiMgmt) && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtValue") && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtUnitNo") && !readedWifiMgmtLine.contains("Sterlite_EthernetPort_WifiMgmtIp_Address") ){
					wifiMgmtOutputLines.add(readedWifiMgmtLine);
				}//End if StaticLines
				
			}
			
		}//End for wifiMgmtOutputLines
		
		for(String wifiMgmtOutputLine: wifiMgmtOutputLines) {
			try {
				br.write(wifiMgmtOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("wifi-mgmt File Write Catch Block: " + e);
			}
		}
		log.info("wifi-mgmt File Write End");
	}//wifiMgmtOutputLines
	
//	*************** wifi-mgmt Code Ends ************	

//	*************** bb-ill Code Starts ************
//	Read bb-ill text added into list(readedBbIllLines)
	List<String> readedBbIllLines = new ArrayList<>();
	public void readedBbIllTextFile(){
		//Static bb-ill text file
		InputStream wifiMgmtConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("bb_ill.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(wifiMgmtConfigFile);
		while (scannerFile.hasNextLine()) {
			readedBbIllLines.add(scannerFile.nextLine());
		}
	}
	
//	get bb-ill values and added into list (bbIllOutputLines)
	private List<String> bbIllOutputLines = new ArrayList<>();
	public void writeBbIllData(){
		log.info("bb-ill File Write Starts");
		String contextBbIll = "bb-ill";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextBbIll);
		readUplinkInterfaceOverAll(contextBbIll);
		readMapForWanIpAddress(contextBbIll);
		
		for(String readedBbIllLine: readedBbIllLines){
			if(readedBbIllLine.contains(contextBbIll)){
				//bb-ill bng_as_no
				if(readedBbIllLine.contains("Sterlite_BbIll_Bng_As_No")){
					String tempBngAsNo = readedBbIllLine.replace("Sterlite_BbIll_Bng_As_No", bngAsNo);
					bbIllOutputLines.add(tempBngAsNo);
				}
				//bb-ill neighbor ip address
				if(readedBbIllLine.contains("Sterlite_BbIll_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedBbIllLine.replace("Sterlite_BbIll_Neighbour_Ip_Address", ipAddress);
						bbIllOutputLines.add(tempNeighborIp);
					}
				}
				
				//Sterlite_EthernetPort_BbIllValue.Sterlite_EthernetPort_BbIllUnitNo
				if(readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						
						if(readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo") && readedBbIllLine.contains("Sterlite_Uplink_BbIllInterface") ){
							tempInterfaceReadLine = readedBbIllLine.replace("Sterlite_EthernetPort_BbIllValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbIllUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_BbIllInterface",  uplinkInterface.getUplink_interface());
							bbIllOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//bb-ill static lines only
				if(readedBbIllLine.contains(contextBbIll) && !readedBbIllLine.contains("Sterlite_Uplink_BbIllInterface") && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo") && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && !readedBbIllLine.contains("Sterlite_BbIll_Neighbour_Ip_Address") && !readedBbIllLine.contains("Sterlite_BbIll_Bng_As_No") ){
					bbIllOutputLines.add(readedBbIllLine);
				}
				
			}//End if bb-ill
			else{
				//Sterlite_EthernetPort_WifiMgmtValue.Sterlite_EthernetPort_WifiMgmtUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo") && readedBbIllLine.contains("Sterlite_EthernetPort_BbIllIp_Address") ){
						tempInterfaceReadLine = readedBbIllLine.replace("Sterlite_EthernetPort_BbIllValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbIllUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbIllIp_Address", uplinkInterface.getWan_ip_address());
						bbIllOutputLines.add(tempInterfaceReadLine);
					}
					if(readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo") && !readedBbIllLine.contains("Sterlite_Uplink_BbIllInterface") && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllIp_Address")){
						tempInterfaceReadLine = readedBbIllLine.replace("Sterlite_EthernetPort_BbIllValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbIllUnitNo", uplinkInterface.getUplink_unit_no());
						bbIllOutputLines.add(tempInterfaceReadLine);
					}
				}//End for uplinkInterfaces
				//bb-ill StaticLine
				if(!readedBbIllLine.contains(contextBbIll) && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllValue") && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllUnitNo") && !readedBbIllLine.contains("Sterlite_EthernetPort_BbIllIp_Address") ){
					bbIllOutputLines.add(readedBbIllLine);
				}//End if StaticLines
				
			}
			
		}//End for ftthBsnlInOutputLines
		
		for(String bbIllOutputLine: bbIllOutputLines) {
			try {
				br.write(bbIllOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("bb-ill File Write Catch Block: " + e);
			}
		}
		log.info("bb-ill File Write End");
	}//writeBbIllData
	
//	*************** bb-ill Code Ends ************	
	
//	*************** BWSP-WIFI Code Starts ************
//	Read BWSP-WIFI text added into list(readedBWSPWIFILines)
	List<String> readedBWSPWIFILines = new ArrayList<>();
	public void readedBWSPWIFITextFile(){
		//Static BWSP-WIFI text file
		InputStream bwspWifiConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("bwsp-wifi.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(bwspWifiConfigFile);
		while (scannerFile.hasNextLine()) {
			readedBWSPWIFILines.add(scannerFile.nextLine());
		}
	}
	
//	get BWSP-WIFI values and added into list (bwspWifiOutputLines)
	private List<String> bwspWifiOutputLines = new ArrayList<>();
	public void writeBwspWifiData(){
		log.info("bwsp-wifi File Write Starts");
		String contextBwspWifi = "BWSP-WIFI";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextBwspWifi);
		readUplinkInterfaceOverAll(contextBwspWifi);
		readMapForWanIpAddress(contextBwspWifi);
		
		for(String readedBWSPWIFILine: readedBWSPWIFILines){
			if(readedBWSPWIFILine.contains(contextBwspWifi)){
				//bwspWifi bng_as_no
				if(readedBWSPWIFILine.contains("Sterlite_BwspWifi_Bng_As_No")){
					String tempBngAsNo = readedBWSPWIFILine.replace("Sterlite_BwspWifi_Bng_As_No", bngAsNo);
					bwspWifiOutputLines.add(tempBngAsNo);
				}
				//bwspWifi neighbor ip address
				if(readedBWSPWIFILine.contains("Sterlite_BwspWifi_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedBWSPWIFILine.replace("Sterlite_BwspWifi_Neighbour_Ip_Address", ipAddress);
						bwspWifiOutputLines.add(tempNeighborIp);
					}
				}
				
				//Sterlite_EthernetPort_BwspWifiValue.Sterlite_EthernetPort_BwspWifiUnitNo
				if(readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo") && readedBWSPWIFILine.contains("Sterlite_Uplink_BwspWifiInterface") ){
							tempInterfaceReadLine = readedBWSPWIFILine.replace("Sterlite_EthernetPort_BwspWifiValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BwspWifiUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_BwspWifiInterface",  uplinkInterface.getUplink_interface());
							bwspWifiOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//bwspWifi static lines only
				if(readedBWSPWIFILine.contains(contextBwspWifi) && !readedBWSPWIFILine.contains("Sterlite_Uplink_BwspWifiInterface") && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo") && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && !readedBWSPWIFILine.contains("Sterlite_BwspWifi_Neighbour_Ip_Address") && !readedBWSPWIFILine.contains("Sterlite_BwspWifi_Bng_As_No") ){
					bwspWifiOutputLines.add(readedBWSPWIFILine);
				}
				
			}//End if bwspWifi contains
			else{
				//Sterlite_EthernetPort_WifiMgmtValue.Sterlite_EthernetPort_WifiMgmtUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo") && readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiIp_Address") ){
						tempInterfaceReadLine = readedBWSPWIFILine.replace("Sterlite_EthernetPort_BwspWifiValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BwspWifiUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BwspWifiIp_Address", uplinkInterface.getWan_ip_address());
						bwspWifiOutputLines.add(tempInterfaceReadLine);
					}
					if(readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo") && !readedBWSPWIFILine.contains("Sterlite_Uplink_BwspWifiInterface") && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiIp_Address")){
						tempInterfaceReadLine = readedBWSPWIFILine.replace("Sterlite_EthernetPort_BwspWifiValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BwspWifiUnitNo", uplinkInterface.getUplink_unit_no());
						bwspWifiOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				//bwspWifi StaticLine
				if(!readedBWSPWIFILine.contains(contextBwspWifi) && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiValue") && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiUnitNo") && !readedBWSPWIFILine.contains("Sterlite_EthernetPort_BwspWifiIp_Address") ){
					bwspWifiOutputLines.add(readedBWSPWIFILine);
				}//End if StaticLines
				
			}
			
		}//End for readedBWSPWIFILines
		
		for(String bwspWifiOutputLine: bwspWifiOutputLines) {
			try {
				br.write(bwspWifiOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("BWSP-WIFI File Write Catch Block: " + e);
			}
		}
		log.info("BWSP-WIFI File Write End");
	}//writeBwspWifiData
	
//	*************** BWSP-WIFI Code Ends ************	
	//nofnIpAddress
	
//	*************** NOFN Code Starts ************
//	Read NOFN text added into list(readedNofnLines)
	List<String> readedNofnLines = new ArrayList<>();
	public void readedNofnTextFile(){
		//Static NOFN text file
		InputStream nofnConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("nofn.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(nofnConfigFile);
		while (scannerFile.hasNextLine()) {
			readedNofnLines.add(scannerFile.nextLine());
		}
	}
	
//	get NOFN values and added into list (nofnOutputLines)
	private List<String> nofnOutputLines = new ArrayList<>();
	public void writeNofnData(){
		log.info("NOFN File Write Starts");
		String contextNofn = "NOFN";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextNofn);
		readUplinkInterfaceOverAll(contextNofn);
		readMapForWanIpAddress(contextNofn);
		
		for(String readedNofnLine: readedNofnLines){
			if(readedNofnLine.contains(contextNofn)){
				//NOFN bng_as_no
				if(readedNofnLine.contains("Sterlite_Nofn_Bng_As_No")){
					String tempBngAsNo = readedNofnLine.replace("Sterlite_Nofn_Bng_As_No", bngAsNo);
					nofnOutputLines.add(tempBngAsNo);
				}
				//NOFN neighbor ip address
				if(readedNofnLine.contains("Sterlite_Nofn_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedNofnLine.replace("Sterlite_Nofn_Neighbour_Ip_Address", ipAddress);
						nofnOutputLines.add(tempNeighborIp);
					}
				}
				//NOFN DSLAM ip address
				if(readedNofnLine.contains("Sterlite_Nofn_DslamFirstIp_Address")){
					for(String nofnAddress: nofnIpAddress){
						String tempDslamIp;
						//get DSLAM ipAddress -1 value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(nofnAddress);
						String dslamFirstIp = subnetIpAddress.getInfo().getLowAddress();
						String subnet[] = subnetIpAddress.getInfo().getLowAddress().split("\\/");
						String subnetValue = "";
						for(int sub=0; sub<subnet.length; sub++){
							subnetValue = subnet[0];
						}
						String low[] = subnetValue.split("\\.");
						int lowValue = Integer.parseInt(low[low.length-1]);
						String subLow = dslamFirstIp.substring(0, dslamFirstIp.lastIndexOf('.'));
						
						String dslamFirstValue = subLow+"."+(lowValue-1);
						// ipAddress / value
						String ss[] = nofnAddress.split("\\/");
						
						tempDslamIp = readedNofnLine.replace("Sterlite_Nofn_DslamFirstIp_Address", dslamFirstValue+"/"+ss[1]);
						nofnOutputLines.add(tempDslamIp);
					}
				}
				
				//Sterlite_EthernetPort_NofnValue.Sterlite_EthernetPort_NofnUnitNo
				if(readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						
						if(readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo") && readedNofnLine.contains("Sterlite_Uplink_NofnInterface") ){
							tempInterfaceReadLine = readedNofnLine.replace("Sterlite_EthernetPort_NofnValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_NofnUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_NofnInterface",  uplinkInterface.getUplink_interface());
							nofnOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//NOFN static lines only
				if(readedNofnLine.contains(contextNofn) && !readedNofnLine.contains("Sterlite_Nofn_DslamFirstIp_Address") && !readedNofnLine.contains("Sterlite_Uplink_NofnInterface") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && !readedNofnLine.contains("Sterlite_Nofn_Neighbour_Ip_Address") && !readedNofnLine.contains("Sterlite_Nofn_Bng_As_No") ){
					nofnOutputLines.add(readedNofnLine);
				}
				
			}//End if NOFN contains
			else{
				//Sterlite_EthernetPort_NofnValue.Sterlite_EthernetPort_NofnUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo") && readedNofnLine.contains("Sterlite_EthernetPort_NofnIp_Address") ){
						tempInterfaceReadLine = readedNofnLine.replace("Sterlite_EthernetPort_NofnValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_NofnUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_NofnIp_Address", uplinkInterface.getWan_ip_address());
						nofnOutputLines.add(tempInterfaceReadLine);
					}
					if(readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo") && !readedNofnLine.contains("Sterlite_Uplink_NofnInterface") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnIp_Address") ){
						tempInterfaceReadLine = readedNofnLine.replace("Sterlite_EthernetPort_NofnValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_NofnUnitNo", uplinkInterface.getUplink_unit_no());
						nofnOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				//WifiData NOFN ip address
				if(readedNofnLine.contains("Sterlite_Nofn_DslamIp_Address")){
					for(String nofnAddress: nofnIpAddress){
						String tempNofnIp;
						//get NOFN ipAddress value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(nofnAddress);
						tempNofnIp = readedNofnLine.replace("Sterlite_Nofn_DslamIp_Address", subnetIpAddress.getInfo().getLowAddress());
						nofnOutputLines.add(tempNofnIp);
					}
				}
				
				//NOFN StaticLine
				if(!readedNofnLine.contains(contextNofn) && !readedNofnLine.contains("Sterlite_Nofn_DslamIp_Address") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnValue") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnUnitNo") && !readedNofnLine.contains("Sterlite_EthernetPort_NofnIp_Address") ){
					nofnOutputLines.add(readedNofnLine);
				}//End if StaticLines
				
			}
			
		}//End for readedNofnLines
		
		for(String nofnOutputLine: nofnOutputLines) {
			try {
				br.write(nofnOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("NOFN File Write Catch Block: " + e);
			}
		}
		log.info("NOFN File Write End");
	}//writeNofnData
	
//	*************** NOFN Code Ends ************
	
	//Bbnlinbandll

//	*************** bbnlinband-ll Code Starts ************
//	Read bbnlinband-ll text added into list(readedBbnlinbandllLines)
	List<String> readedBbnlinbandllLines = new ArrayList<>();
	public void readedBbnlinbandllTextFile(){
		//Static bbnlinband-ll text file
		InputStream bbnlinbandllConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("bbnlinband-ll.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(bbnlinbandllConfigFile);
		while (scannerFile.hasNextLine()) {
			readedBbnlinbandllLines.add(scannerFile.nextLine());
		}
	}
	
//	get bbnlinband-ll values and added into list (nofnOutputLines)
	private List<String> bbnlinbandllOutputLines = new ArrayList<>();
	public void writeBbnlinbandllData(){
		log.info("Bbnlinbandll File Write Starts");
		String contextBbnlinbandll = "bbnlinband-ll";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextBbnlinbandll);
		readUplinkInterfaceOverAll(contextBbnlinbandll);
		readMapForWanIpAddress(contextBbnlinbandll);
		
		for(String readedBbnlinbandllLine: readedBbnlinbandllLines){
			if(readedBbnlinbandllLine.contains(contextBbnlinbandll)){
				//bbnlinband-ll bng_as_no
				if(readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Bng_As_No")){
					String tempBngAsNo = readedBbnlinbandllLine.replace("Sterlite_Bbnlinbandll_Bng_As_No", bngAsNo);
					bbnlinbandllOutputLines.add(tempBngAsNo);
				}
				//bbnlinband-ll neighbor ip address
				if(readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedBbnlinbandllLine.replace("Sterlite_Bbnlinbandll_Neighbour_Ip_Address", ipAddress);
						bbnlinbandllOutputLines.add(tempNeighborIp);
					}
				}
				//bbnlinband-ll ip address
				if(readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_FirstIp_Address")){
					for(String bbnlinbandLLIpAddress: bbnlinbandllIpAddress){
						String tempBbnlinbandllIp;
						//get DSLAM ipAddress -1 value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(bbnlinbandLLIpAddress);
						String bbnlinbandllFirstIp = subnetIpAddress.getInfo().getLowAddress();
						String subnet[] = subnetIpAddress.getInfo().getLowAddress().split("\\/");
						String subnetValue = "";
						for(int sub=0; sub<subnet.length; sub++){
							subnetValue = subnet[0];
						}
						String low[] = subnetValue.split("\\.");
						int lowValue = Integer.parseInt(low[low.length-1]);
						String subLow = bbnlinbandllFirstIp.substring(0, bbnlinbandllFirstIp.lastIndexOf('.'));
						
						String bbnlinbandllFirstValue = subLow+"."+(lowValue-1);
						// ipAddress / value
						String ss[] = bbnlinbandLLIpAddress.split("\\/");
						
						tempBbnlinbandllIp = readedBbnlinbandllLine.replace("Sterlite_Bbnlinbandll_FirstIp_Address", bbnlinbandllFirstValue+"/"+ss[1]);
						bbnlinbandllOutputLines.add(tempBbnlinbandllIp);
					}
				}
				
				//Sterlite_EthernetPort_BbnlinbandllValue.Sterlite_EthernetPort_BbnlinbandllUnitNo
				if(readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo") && readedBbnlinbandllLine.contains("Sterlite_Uplink_BbnlinbandllInterface") ){
							tempInterfaceReadLine = readedBbnlinbandllLine.replace("Sterlite_EthernetPort_BbnlinbandllValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbnlinbandllUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_BbnlinbandllInterface",  uplinkInterface.getUplink_interface());
							bbnlinbandllOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//bbnlinband-ll static lines only
				if(readedBbnlinbandllLine.contains(contextBbnlinbandll) && !readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_FirstIp_Address") && !readedBbnlinbandllLine.contains("Sterlite_Uplink_BbnlinbandllInterface") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && !readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Neighbour_Ip_Address") && !readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Bng_As_No") ){
					bbnlinbandllOutputLines.add(readedBbnlinbandllLine);
				}
				
			}//End if bbnlinband-ll contains
			else{
				//Sterlite_EthernetPort_BbnlinbandllValue.Sterlite_EthernetPort_BbnlinbandllUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo") && readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllIp_Address") ){
						tempInterfaceReadLine = readedBbnlinbandllLine.replace("Sterlite_EthernetPort_BbnlinbandllValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbnlinbandllUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbnlinbandllIp_Address", uplinkInterface.getWan_ip_address());
						bbnlinbandllOutputLines.add(tempInterfaceReadLine);
					}
					if(readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo") && !readedBbnlinbandllLine.contains("Sterlite_Uplink_BbnlinbandllInterface") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllIp_Address")){
						tempInterfaceReadLine = readedBbnlinbandllLine.replace("Sterlite_EthernetPort_BbnlinbandllValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_BbnlinbandllUnitNo", uplinkInterface.getUplink_unit_no());
						bbnlinbandllOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				//WifiData bbnlinband-ll ip address
				if(readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Ip_Address")){
					for(String nofnAddress: nofnIpAddress){
						String tempNofnIp;
						//get NOFN ipAddress value
						SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(nofnAddress);
						tempNofnIp = readedBbnlinbandllLine.replace("Sterlite_Bbnlinbandll_Ip_Address", subnetIpAddress.getInfo().getLowAddress());
						bbnlinbandllOutputLines.add(tempNofnIp);
					}
				}
				
				//bbnlinband-ll StaticLine
				if(!readedBbnlinbandllLine.contains(contextBbnlinbandll) && !readedBbnlinbandllLine.contains("Sterlite_Bbnlinbandll_Ip_Address") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllValue") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllUnitNo") && !readedBbnlinbandllLine.contains("Sterlite_EthernetPort_BbnlinbandllIp_Address") ){
					bbnlinbandllOutputLines.add(readedBbnlinbandllLine);
				}//End if StaticLines
				
			}
			
		}//End for readedNofnLines
		
		for(String bbnlinbandllOutputLine: bbnlinbandllOutputLines) {
			try {
				br.write(bbnlinbandllOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("bbnlinband-ll File Write Catch Block: " + e);
			}
		}
		log.info("bbnlinband-ll File Write End");
	}//writeNofnData
	
//	*************** bbnlinband-ll Code Ends ************

//	*************** iptax Code Starts ************
//	Read iptax text added into list(readedIptaxLines)
	List<String> readedIptaxLines = new ArrayList<>();
	public void readedIptaxTextFile(){
		//Static Iptax text file
		InputStream iptaxConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("iptax.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(iptaxConfigFile);
		while (scannerFile.hasNextLine()) {
			readedIptaxLines.add(scannerFile.nextLine());
		}
	}
	
//	get iptax values and added into list (iptaxOutputLines)
	private List<String> iptaxOutputLines = new ArrayList<>();
	public void writeIptaxData(){
		log.info("Iptax File Write Starts");
		String contextIptax = "iptax";
		neighborIpAddress = new ArrayList<>();

		readWithInTheContext(contextIptax);
		readUplinkInterfaceOverAll(contextIptax);
		readMapForWanIpAddress(contextIptax);
		
		for(String readedIptaxLine: readedIptaxLines){
			if(readedIptaxLine.contains(contextIptax)){
				//iptax bng_as_no
				if(readedIptaxLine.contains("Sterlite_Iptax_Bng_As_No")){
					String tempBngAsNo = readedIptaxLine.replace("Sterlite_Iptax_Bng_As_No", bngAsNo);
					iptaxOutputLines.add(tempBngAsNo);
				}
				//iptax neighbor ip address
				if(readedIptaxLine.contains("Sterlite_Iptax_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedIptaxLine.replace("Sterlite_Iptax_Neighbour_Ip_Address", ipAddress);
						iptaxOutputLines.add(tempNeighborIp);
					}
				}
				//Sterlite_EthernetPort_IptaxValue.Sterlite_EthernetPort_IptaxUnitNo
				if(readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo") && readedIptaxLine.contains("Sterlite_Uplink_IptaxInterface") ){
							tempInterfaceReadLine = readedIptaxLine.replace("Sterlite_EthernetPort_IptaxValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_IptaxInterface",  uplinkInterface.getUplink_interface());
							iptaxOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//iptax static lines only
				if(readedIptaxLine.contains(contextIptax) && !readedIptaxLine.contains("Sterlite_Uplink_IptaxInterface") && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo") && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && !readedIptaxLine.contains("Sterlite_Iptax_Neighbour_Ip_Address") && !readedIptaxLine.contains("Sterlite_Iptax_Bng_As_No") ){
					iptaxOutputLines.add(readedIptaxLine);
				}
				
			}//End if iptax contains
			else{
				//Sterlite_EthernetPort_IptaxValue.Sterlite_EthernetPort_IptaxUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo") && readedIptaxLine.contains("Sterlite_EthernetPort_IptaxIp_Address") ){
						tempInterfaceReadLine = readedIptaxLine.replace("Sterlite_EthernetPort_IptaxValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxIp_Address", uplinkInterface.getWan_ip_address());
						iptaxOutputLines.add(tempInterfaceReadLine);
					}
					if(readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo") && !readedIptaxLine.contains("Sterlite_Uplink_IptaxInterface") && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxIp_Address")){
						tempInterfaceReadLine = readedIptaxLine.replace("Sterlite_EthernetPort_IptaxValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxUnitNo", uplinkInterface.getUplink_unit_no());
						iptaxOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				
				//iptax StaticLine
				if(!readedIptaxLine.contains(contextIptax) && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxValue") && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxUnitNo") && !readedIptaxLine.contains("Sterlite_EthernetPort_IptaxIp_Address") ){
					iptaxOutputLines.add(readedIptaxLine);
				}//End if StaticLines
				
			}
			
		}//End for readedIptaxLines
		
		for(String iptaxOutputLine: iptaxOutputLines) {
			try {
				br.write(iptaxOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("iptax File Write Catch Block: " + e);
			}
		}
		log.info("iptax File Write End");
	}//writeIptax
	
//	*************** iptax Code Ends ************
	
	
//	*************** iptax-mgmt Code Starts ************
//	Read iptax-mgmt text added into list(readedIptaxMgmtLines)
	List<String> readedIptaxMgmtLines = new ArrayList<>();
	public void readedIptaxMgmtTextFile(){
		//Static Iptax-mgmt text file
		InputStream iptaxMgmtConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("iptax-mgmt.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(iptaxMgmtConfigFile);
		while (scannerFile.hasNextLine()) {
			readedIptaxMgmtLines.add(scannerFile.nextLine());
		}
	}
	
//	get iptax-mgmt values and added into list (iptaxMgmtOutputLines)
	private List<String> iptaxMgmtOutputLines = new ArrayList<>();
	public void writeIptaxMgmtData(){
		log.info("Iptax-mgmt File Write Starts");
		String contextIptaxMgmt = "iptax-mgmt";
		neighborIpAddress = new ArrayList<>();
		bngAsNo = null;
		
		readWithInTheContext(contextIptaxMgmt);
		readUplinkInterfaceOverAll(contextIptaxMgmt);
		readMapForWanIpAddress(contextIptaxMgmt);
		
		for(String readedIptaxMgmtLine: readedIptaxMgmtLines){
			if(readedIptaxMgmtLine.contains(contextIptaxMgmt)){
				//iptax bng_as_no
				if(readedIptaxMgmtLine.contains("Sterlite_IptaxMgmt_Bng_As_No")){
					try{
					String tempBngAsNo = readedIptaxMgmtLine.replace("Sterlite_IptaxMgmt_Bng_As_No", bngAsNo);
					iptaxMgmtOutputLines.add(tempBngAsNo);
					}
					catch(NullPointerException np){
						continue;
					}
				}
				//iptax neighbor ip address
				if(readedIptaxMgmtLine.contains("Sterlite_IptaxMgmt_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedIptaxMgmtLine.replace("Sterlite_IptaxMgmt_Neighbour_Ip_Address", ipAddress);
						iptaxMgmtOutputLines.add(tempNeighborIp);
					}
				}
				//Sterlite_EthernetPort_IptaxMgmtValue.Sterlite_EthernetPort_IptaxMgmtUnitNo
				if(readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo") && readedIptaxMgmtLine.contains("Sterlite_Uplink_IptaxMgmtInterface") ){
							tempInterfaceReadLine = readedIptaxMgmtLine.replace("Sterlite_EthernetPort_IptaxMgmtValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxMgmtUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_IptaxMgmtInterface",  uplinkInterface.getUplink_interface());
							iptaxMgmtOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				
				//iptax-mgmt static lines only
				if(readedIptaxMgmtLine.contains(contextIptaxMgmt) && !readedIptaxMgmtLine.contains("Sterlite_Uplink_IptaxMgmtInterface") && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo") && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && !readedIptaxMgmtLine.contains("Sterlite_IptaxMgmt_Neighbour_Ip_Address") && !readedIptaxMgmtLine.contains("Sterlite_IptaxMgmt_Bng_As_No") ){
					iptaxMgmtOutputLines.add(readedIptaxMgmtLine);
				}
				
			}//End if iptax-mgmt contains
			else{
				//Sterlite_EthernetPort_IptaxMgmtValue.Sterlite_EthernetPort_IptaxMgmtUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo") && readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtIp_Address") ){
						tempInterfaceReadLine = readedIptaxMgmtLine.replace("Sterlite_EthernetPort_IptaxMgmtValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxMgmtUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxMgmtIp_Address", uplinkInterface.getWan_ip_address());
						iptaxMgmtOutputLines.add(tempInterfaceReadLine);
					}
					if(readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo") && !readedIptaxMgmtLine.contains("Sterlite_Uplink_IptaxMgmtInterface") && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtIp_Address")){
						tempInterfaceReadLine = readedIptaxMgmtLine.replace("Sterlite_EthernetPort_IptaxMgmtValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_IptaxMgmtUnitNo", uplinkInterface.getUplink_unit_no());
						iptaxMgmtOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				
				//iptax StaticLine
				if(!readedIptaxMgmtLine.contains(contextIptaxMgmt) && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtValue") && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtUnitNo") && !readedIptaxMgmtLine.contains("Sterlite_Uplink_IptaxMgmtInterface") && !readedIptaxMgmtLine.contains("Sterlite_EthernetPort_IptaxMgmtIp_Address") ){
					iptaxMgmtOutputLines.add(readedIptaxMgmtLine);
				}//End if StaticLines
			}
			
		}//End for readedIptaxMgmtLines
		
		for(String iptaxMgmtOutputLine: iptaxMgmtOutputLines) {
			try {
				br.write(iptaxMgmtOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("iptax-mgmt File Write Catch Block: " + e);
			}
		}
		log.info("iptax-mgmt File Write End");
	}//writeIptaxMgmt
	
//	*************** iptax-mgmt Code Ends ************
	
	
//	*************** l2tpvpn Code Starts ************
//	Read l2tpvpn text added into list(readedL2tpvpnLines)
	List<String> readedL2tpvpnLines = new ArrayList<>();
	public void readedL2tpvpnTextFile(){
		//Static l2tpvpn text file
		InputStream l2tpvpnConfigFile = BaseAccessConfigRWCode.class.getClassLoader().getResourceAsStream("l2tpvpn.txt");
		@SuppressWarnings("resource")
		Scanner scannerFile = new Scanner(l2tpvpnConfigFile);
		while (scannerFile.hasNextLine()) {
			readedL2tpvpnLines.add(scannerFile.nextLine());
		}
	}
	
//	get l2tpvpn values and added into list (l2tpvpnOutputLines)
	private List<String> l2tpvpnOutputLines = new ArrayList<>();
	public void writeL2tpvpnData(){
		log.info("l2tpvpn File Write Starts");
		String contextL2tpvpn = "l2tpvpn";
		neighborIpAddress = new ArrayList<>();
		bngAsNo = null;
		
		readWithInTheContext(contextL2tpvpn);
		readUplinkInterfaceOverAll(contextL2tpvpn);
		readMapForWanIpAddress(contextL2tpvpn);
		
		for(String readedL2tpvpnLine: readedL2tpvpnLines){
			if(readedL2tpvpnLine.contains(contextL2tpvpn)){
				//l2tpvpn bng_as_no
				if(readedL2tpvpnLine.contains("Sterlite_L2tpvpn_Bng_As_No")){
					String tempBngAsNo = readedL2tpvpnLine.replace("Sterlite_L2tpvpn_Bng_As_No", bngAsNo);
					l2tpvpnOutputLines.add(tempBngAsNo);
				}
				//l2tpvpn neighbor ip address
				if(readedL2tpvpnLine.contains("Sterlite_L2tpvpn_Neighbour_Ip_Address")){
					for(String ipAddress: neighborIpAddress){
						String tempNeighborIp;
						tempNeighborIp = readedL2tpvpnLine.replace("Sterlite_L2tpvpn_Neighbour_Ip_Address", ipAddress);
						l2tpvpnOutputLines.add(tempNeighborIp);
					}
				}
				//Sterlite_EthernetPort_L2tpvpnValue.Sterlite_EthernetPort_L2tpvpnUnitNo
				if(readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo")){
					String tempInterfaceReadLine;
					for(UplinkInterface uplinkInterface: uplinkInterfaces){
						String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
						if(readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo") && readedL2tpvpnLine.contains("Sterlite_Uplink_L2tpvpnInterface") ){
							tempInterfaceReadLine = readedL2tpvpnLine.replace("Sterlite_EthernetPort_L2tpvpnValue", portValue);
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_L2tpvpnUnitNo", uplinkInterface.getUplink_unit_no());
							tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_Uplink_L2tpvpnInterface",  uplinkInterface.getUplink_interface());
							l2tpvpnOutputLines.add(tempInterfaceReadLine);
						}
						
					}//End for uplinkInterfaces
				}
				//Sterlite_l2tpvpnLoopback_IpAddress
				//l2tpvpnLoopbackIpAddress, l2tpvpnLoopbackBsnlInIpAddress
				//l2tpvpnLoopbackIpAddress
				if(readedL2tpvpnLine.contains("Sterlite_l2tpvpnLoopback_IpAddress")){
					for(String l2tpvpnLoopbackAddress: l2tpvpnLoopbackIpAddress){
						String templ2tpvpnLoopbackIp;
						templ2tpvpnLoopbackIp = readedL2tpvpnLine.replace("Sterlite_l2tpvpnLoopback_IpAddress", l2tpvpnLoopbackAddress);
						l2tpvpnOutputLines.add(templ2tpvpnLoopbackIp);
					}
				}
				//l2tpvpnLoopbackBsnlInIpAddress
				if(readedL2tpvpnLine.contains("Sterlite_l2tpvpnLoopback_BsnlIn_IpAddress")){
					for(String l2tpvpnLoopbackBsnlIpAddress: l2tpvpnLoopbackBsnlInIpAddress){
						String templ2tpvpnLoopbackBsnlIp;
						templ2tpvpnLoopbackBsnlIp = readedL2tpvpnLine.replace("Sterlite_l2tpvpnLoopback_BsnlIn_IpAddress", l2tpvpnLoopbackBsnlIpAddress);
						l2tpvpnOutputLines.add(templ2tpvpnLoopbackBsnlIp);
					}
				}
				
				
				
				//l2tpvpn static lines only
				if(readedL2tpvpnLine.contains(contextL2tpvpn) && !readedL2tpvpnLine.contains("Sterlite_l2tpvpnLoopback_BsnlIn_IpAddress") && !readedL2tpvpnLine.contains("Sterlite_l2tpvpnLoopback_IpAddress") && !readedL2tpvpnLine.contains("Sterlite_Uplink_L2tpvpnInterface") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && !readedL2tpvpnLine.contains("Sterlite_L2tpvpn_Neighbour_Ip_Address") && !readedL2tpvpnLine.contains("Sterlite_L2tpvpn_Bng_As_No") ){
					l2tpvpnOutputLines.add(readedL2tpvpnLine);
				}
				
			}//End if l2tpvpn contains
			else{
				//Sterlite_EthernetPort_L2tpvpnValue.Sterlite_EthernetPort_L2tpvpnUnitNo
				String tempInterfaceReadLine;
				for(UplinkInterface uplinkInterface: uplinkInterfaces){
					String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
					if(readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo") && readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnIp_Address") ){
						tempInterfaceReadLine = readedL2tpvpnLine.replace("Sterlite_EthernetPort_L2tpvpnValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_L2tpvpnUnitNo", uplinkInterface.getUplink_unit_no());
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_L2tpvpnIp_Address", uplinkInterface.getWan_ip_address());
						l2tpvpnOutputLines.add(tempInterfaceReadLine);
					}
					if(readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo") && !readedL2tpvpnLine.contains("Sterlite_Uplink_L2tpvpnInterface") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnIp_Address")){
						tempInterfaceReadLine = readedL2tpvpnLine.replace("Sterlite_EthernetPort_L2tpvpnValue", portValue);
						tempInterfaceReadLine = tempInterfaceReadLine.replace("Sterlite_EthernetPort_L2tpvpnUnitNo", uplinkInterface.getUplink_unit_no());
						l2tpvpnOutputLines.add(tempInterfaceReadLine);
					}
					
				}//End for uplinkInterfaces
				
				
				//hostName, Sterlite_HostName
				if(readedL2tpvpnLine.contains("Sterlite_HostName")){
					String tempHostName;
					tempHostName = readedL2tpvpnLine.replace("Sterlite_HostName", hostName);
					l2tpvpnOutputLines.add(tempHostName);
				}
				
				//l2tpvpn StaticLine
				if(!readedL2tpvpnLine.contains(contextL2tpvpn) && !readedL2tpvpnLine.contains("Sterlite_HostName") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnValue") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnUnitNo") && !readedL2tpvpnLine.contains("Sterlite_Uplink_L2tpvpnInterface") && !readedL2tpvpnLine.contains("Sterlite_EthernetPort_L2tpvpnIp_Address") ){
					l2tpvpnOutputLines.add(readedL2tpvpnLine);
				}//End if StaticLines
			}
			
		}//End for readedIptaxMgmtLines
		
		for(String l2tpvpnOutputLine: l2tpvpnOutputLines) {
			try {
				br.write(l2tpvpnOutputLine);
				br.write(System.getProperty("line.separator"));
			} catch (IOException e) {
				log.error("l2tpvpn File Write Catch Block: " + e);
			}
		}
		log.info("l2tpvpn File Write End");
	}//writeIptaxMgmt
	
//	*************** iptax-mgmt Code Ends ************
	
	
	
	
	
	
	
	
	
	
	//Writing Logic End
	
	
//	******** L3vpn logic Ends	********	//
	
	
}