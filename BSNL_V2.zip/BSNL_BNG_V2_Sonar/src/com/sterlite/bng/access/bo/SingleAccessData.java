/**
 * 
 */
package com.sterlite.bng.access.bo;

/**
 * @author ravi.divvela
 *
 */
public class SingleAccessData {
	private String outerUnitNo;
	private String description;
	private String innerUnitStart;
	private String innerUnitStop;
	private String bindValue;
	private String contextName;
	private String bindIpAddress;
	/**
	 * @return the outerUnitNo
	 */
	public String getOuterUnitNo() {
		return outerUnitNo;
	}
	/**
	 * @param outerUnitNo the outerUnitNo to set
	 */
	public void setOuterUnitNo(String outerUnitNo) {
		this.outerUnitNo = outerUnitNo;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param desccription the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the innerUnitStart
	 */
	public String getInnerUnitStart() {
		return innerUnitStart;
	}
	/**
	 * @param innerUnitStart the innerUnitStart to set
	 */
	public void setInnerUnitStart(String innerUnitStart) {
		this.innerUnitStart = innerUnitStart;
	}
	/**
	 * @return the innerUnitStop
	 */
	public String getInnerUnitStop() {
		return innerUnitStop;
	}
	/**
	 * @param innerUnitStop the innerUnitStop to set
	 */
	public void setInnerUnitStop(String innerUnitStop) {
		this.innerUnitStop = innerUnitStop;
	}
	//
	/**
	 * @return the bindValue
	 */
	public String getBindValue() {
		return bindValue;
	}
	/**
	 * @param bindValue the bindValue to set
	 */
	public void setBindValue(String bindValue) {
		this.bindValue = bindValue;
	}
	/**
	 * @return the contextName
	 */
	public String getContextName() {
		return contextName;
	}
	/**
	 * @param contextName the contextName to set
	 */
	public void setContextName(String contextName) {
		this.contextName = contextName;
	}
	/**
	 * @return the bindIpAddress
	 */
	public String getBindIpAddress() {
		return bindIpAddress;
	}
	/**
	 * @param bindIpAddress the bindIpAddress to set
	 */
	public void setBindIpAddress(String bindIpAddress) {
		this.bindIpAddress = bindIpAddress;
	}
	//
	//dot1qPVCSingleList
	public SingleAccessData(String outerUnitNo, String description, String innerUnitStart, String innerUnitStop, 
			String bindValue, String contextName, String bindIpAddress) {
		this.outerUnitNo = outerUnitNo;
		this.description = description;
		this.innerUnitStart = innerUnitStart;
		this.innerUnitStop = innerUnitStop;
		this.bindValue = bindValue;
		this.contextName = contextName;
		this.bindIpAddress = bindIpAddress;
	}
	public SingleAccessData() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AccessData [outerUnitNo=" + outerUnitNo + ", description=" + description + ", innerUnitStart="
				+ innerUnitStart + ", innerUnitStop=" + innerUnitStop + ", bindValue=" + bindValue + ", contextName="
				+ contextName + ", bindIpAddress=" + bindIpAddress + "]";
	}
	
	
}
