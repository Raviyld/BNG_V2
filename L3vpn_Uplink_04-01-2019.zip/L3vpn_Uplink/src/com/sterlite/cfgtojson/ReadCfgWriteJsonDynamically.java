/**
 * 
 */
package com.sterlite.cfgtojson;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
/**
 * @author ravi.divvela
 *
 */
public class ReadCfgWriteJsonDynamically {
	/**
	 * @param args
	 */
//	Variables Declarations 
	private static final DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");//yyyy/MM/dd HH:mm:ss
	private final String NAME_HOSTNAME = "hostname";
	private final String NAME_SYSTEM = "system";
	private final String NAME_PVC = "pvc";
	private final String NAME_PORT = "port";
	private final String NAME_INTERFACE = "interface";
	private final String NAME_MULTIBIND = "multibind";
	private final String NAME_UPLINK = "UPLINK-";
	private final String NAME_LOOPBACK = "loopback";
	private final String NAME_ADDRESS = "address";
	private final String NAME_NAME = "name";
	private final String NAME_POOL = "pool";
	private final String NAME_IP = "ip"; 
	private final String NAME_DNS = "dns";
	private final String NAME_PRIMARY = "primary";
	private final String NAME_SECONDARY = "secondary";
	private final String NAME_DOMAIN = "domain";
	private final String NAME_NEIGHBOR = "neighbor";
	private final String NAME_EXTERNAL = "external";
	private final String NAME_ACCESS_GROUP = "access-group";
	private final String NAME_IN = "in";
	private final String NAME_OUT = "out";
	private final String NAME_ROUTER = "router";
	private final String NAME_BGP = "bgp";
	private final String NAME_REMOTE_AS = "remote-as";
	private final String NAME_PIM = "pim";
	private final String NAME_RP_ADDRESS = "rp-address";
	//List variables
	private List<UplinkInterface> uplinkInterfaces = null;
	private List<String> neighbor_ip_address = new ArrayList<String>();
	private List<String> ILL_network_address = new ArrayList<String>();
	//neighbor_ip_address, ILL_network_address
	private String systemName = "";
	private String service = "";
	private String serviceId = "";
	private String ri_name = "";
	private String customer = "";
	private String uplink_pvcValue = "";
	private String uplink_portValue = "";
	private String uplink_wanIp = "";
	private int portCount = 0;
	private int pvcCount = 0;
	private String loopBack = "";
	private boolean add_pool = false;
	private String pool_type = "";
	private String ri_name_pool="";
	private String ri_address_pool="";
	private String ri_address_pool_first_ip = "";
	private String ri_address_pool_low = "";
	private String ri_address_pool_high = "";
//	ri_address_pool_range_name // same as ri_name_pool 
//	private String ri_address_pool_range_name = "";
	private String primary_dns_server = "";
	private String secondary_dns_server = "";
	private boolean nsentries = false;
	private String domain="";
	private boolean virus_dns_fw_filter = false;
	private String bng_as_no = "";
	private String neighbor_as_no = "";
	private boolean pim = false;
	private String rp_address = "";
	private boolean ILL_service = false;
	
	
/*	------------------------------------------------	*/
//	Logic Implementation Starts
// 	Read CFG file and hold each and every line in to Map - readedCFGLines// raipur-10.238.56.129
//	private String cfgFilePath = null; /*"D://Data//Ahmedabad-bdr1-10.238.53.1.cfg";*/// Hard Code Path
//	private String cfgFilePath = "D://Data//raipur-10.238.56.129.cfg";
//	private String cfgFilePath = "D://Data//enk-01.txt";
	
	private Map<Integer, String> readedCFGLines = new HashMap<Integer, String>();
	public boolean ReadCFGLines(String cfgFilePath){
		//System.out.println("cfgFilePath: " + cfgFilePath);
		
		String cfgFile = cfgFilePath.substring(cfgFilePath.lastIndexOf(".")+1);
		//System.out.println("cfgFile: " + cfgFile);
		if(cfgFile.equals("cfg") || cfgFile.equals("txt") || cfgFile.equals("log")){
			try {
				//System.out.println("try bolck ");
				List<String> allLines = Files.readAllLines(Paths.get(cfgFilePath));
				int i = 0;
				for (String line : allLines) {
					i++;
					readedCFGLines.put(i, line); // Adding each line by line in to map(key is line no, value is line)
				}
				readCFgTxt = true;
				//System.out.println("ReadCFGLines readCFgTxt: " + readCFgTxt);
			} catch (IOException e) {
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
				System.out.println("No Such File In That Location, Please Provide Exact File Name&Location..! ");
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
				e.printStackTrace();
				System.exit(1);
			}
		}
		else{
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.out.println("Given File Extension: "+ cfgFile + " Please Provide CFG/TXT/LOG File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.exit(1);
		}
		return readCFgTxt;
	}
	
// 	Read CFG GET Context to Context Line No's
	private String context = "context";
	private TreeMap<Integer, String> contextsWithLineNo = new TreeMap<Integer, String>();
	public void ReadMapToGetContextLineNo(){
		// To find the number of Contexts in the CFG file and added it to (contextsWithLineNo - map)
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			int previousLineNo = 0;
			int nextLineNo = 0;
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo < currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(context)){
						//Swap lineNo's
						if(previousLineNo!=0){
							nextLineNo = previousLineNo;
						}
						previousLineNo = currentLineNo;// Don't change
						previousLineNo = previousLineNo + nextLineNo;
						nextLineNo = previousLineNo - nextLineNo;
						previousLineNo = previousLineNo - nextLineNo;
						contextsWithLineNo.put(nextLineNo, currentLineWords[clNo+1]);
					}// End If Context
				}// End For currentLineWords.length
			}// End If length==2
		}//End For - added map values end
		//System.out.println("Contexts: " + contextsWithLineNo);
	}// END ReadCFGToGetContextLineNo
	
/*	------------------------------------------------	*/
	
// 	Read With in the context Only. for getting the values
	@SuppressWarnings("unused")
	public void ReadMapWithInContext(String contextName){
		add_pool = false;
		neighbor_ip_address = new ArrayList<String>();
		Integer startContextLineNo = 0;
		Integer endContextLineNo = 0;
		// To find context start and end line no's.
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo< currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(context) && contextName.equals(currentLineWords[clNo+1])){
						startContextLineNo = currentLineNo;
						endContextLineNo = getNextContextLineNo(currentLineNo);
					}// End currentWord
				}// End currentLineWords.length
			}// End if currentLineWords.length
		}// start and end line no's
		
		//interfaceCount = 0;// ILL_service using
		for(int inContextLineNo = startContextLineNo+1; inContextLineNo < endContextLineNo; inContextLineNo++){
			String[] inContextWords = readedCFGLines.get(inContextLineNo).split(" ");
			// primary_dns_server, secondary_dns_server
			for(int inNo=0; inNo<inContextWords.length; inNo++){
				String inContextWord = inContextWords[inNo];
				// primary_dns_server 
				if(inContextWord.equals(NAME_DNS) && NAME_PRIMARY.equals(inContextWords[inNo+1])){
					primary_dns_server = inContextWords[inNo+2];
				}
				// secondary_dns_server
				if(inContextWord.equals(NAME_DNS) && NAME_SECONDARY.equals(inContextWords[inNo+1])){
					secondary_dns_server = inContextWords[inNo+2];
				}
				//domain
				if(inContextWords.length==3){
					if(inContextWord.equals(NAME_DOMAIN)){
						domain = inContextWords[inNo+1];
					}
				}
				// neighbor_ip_address multiple values
				if(inContextWord.equals(NAME_NEIGHBOR) && NAME_EXTERNAL.equals(inContextWords[inNo+2])){
					neighbor_ip_address.add(inContextWords[inNo+1]);
				}
				// bng_as_no
				if(inContextWord.equals(NAME_ROUTER) && NAME_BGP.equals(inContextWords[inNo+1])){
					bng_as_no = inContextWords[inNo+2];
				}
				// neighbor_as_no
				if(inContextWord.equals(NAME_REMOTE_AS)){
					neighbor_as_no = inContextWords[inNo+1];
				}
				//pim, rp-address 
				if(inContextWords.length==4){
					if(inContextWord.equals(NAME_PIM) && NAME_RP_ADDRESS.equals(inContextWords[inNo+1])){
						rp_address = inContextWords[inNo+2];
						if(rp_address!=null && rp_address!=""){
							pim = true;
						}
					}
				}
				//	virus_dns_fw_filter in/out
				if(!virus_dns_fw_filter){
					if(inContextWord.equals(NAME_IP) && NAME_ACCESS_GROUP.equals(inContextWords[inNo+1]) && NAME_IN.equals(inContextWords[inNo+3])){
						virus_dns_fw_filter = true;
					}
				}
				if(!virus_dns_fw_filter){
					if(inContextWord.equals(NAME_IP) && NAME_ACCESS_GROUP.equals(inContextWords[inNo+1]) && NAME_OUT.equals(inContextWords[inNo+3])){
						virus_dns_fw_filter = true;
					}
				}
				
				// ILL_service **
				if(inContextWords.length==4){
					//String nextToNextString = inContextWords[inNo+2];
					if(inContextWord.equals(NAME_INTERFACE)){
						//System.out.println("241 - inContextWord: " + inContextWord);
						String nextToNextString = null;
						try{
							if(inContextWords[inNo+2]!=null){
								nextToNextString = inContextWords[inNo+2];
							}
						}
						catch(ArrayIndexOutOfBoundsException aib){
							nextToNextString = "";
						}
						//System.out.println("\n " + "  : nextToNextString: " + nextToNextString);
						if(nextToNextString.contains(NAME_MULTIBIND)){
							//System.out.println("name_multibind: " + nextToNextString);
						}
						else if(nextToNextString.contains(NAME_LOOPBACK)){
							//System.out.println("name_loopback: " + nextToNextString);
						}
						else if(nextToNextString!=null){
							//System.out.println("!= loopback / multibind: " + nextToNextString);
							ILL_service = true;
						}
					}// End if NAME_INTERFACE
				}// End if inContextWords==4
				
				// inContextWords<4
				if(inContextWords.length<4){
					//String nextToNextString = inContextWords[inNo+2];
					if(inContextWord.equals(NAME_INTERFACE)){
						String nextString = inContextWords[inNo+1];
						//System.out.println("\n " + "nextString: "+ nextString );
						if(nextString.contains(NAME_UPLINK) ){
							//System.out.println("\n if 245== \n " + ILL_service + " :nextString:  "+ nextString);
						}
						else if(nextString!=null){
							//System.out.println("Uplink else: " + nextString);
							ILL_service = true;
						}
					}// End NAME_INTERFACE
				}//End if inContextWords<4
					
			}// End for loop inContextWords.length 
			
			
			// String 'interface', next to next String 'multibind' based search
			if(inContextWords.length==4){
				for(int inNo=0; inNo<inContextWords.length; inNo++){
					String inContextWord = inContextWords[inNo];
					//System.out.println(inContextLineNo + " - inContextWords.length: " + inContextWords.length + " : " + inContextWord);
					// String 'interface', next to next String 'multibind' based search
					if(inContextWord.equals(NAME_INTERFACE) && NAME_MULTIBIND.equals(inContextWords[inNo+2])){
						//ILL_service = true;
						//ip pool next string is ipAddress & pool_type
						for(int ipAddNo=inContextLineNo+1; ipAddNo<endContextLineNo; ipAddNo++){
							String[] ipAddressPoolWords = readedCFGLines.get(ipAddNo).split(" ");
							// add_pool value
							for(int addPoolNo=0; addPoolNo < ipAddressPoolWords.length; addPoolNo++){
								String poolIp = ipAddressPoolWords[addPoolNo];
								//System.out.println(ipAddNo + " -no:309: poolIp: " + poolIp);
								// add_pool condition
								if(poolIp.equals(NAME_IP) && NAME_ADDRESS.equals(ipAddressPoolWords[addPoolNo+1])){
									add_pool = true;
								}// End if - ip, address - ipAddress for pool_type
							}// End for - add_pool	
								
							// pool_type
							for(int addPoolNo=0; addPoolNo < ipAddressPoolWords.length; addPoolNo++){
								String poolIp = ipAddressPoolWords[addPoolNo];
								if(poolIp.equals(NAME_IP) && NAME_POOL.equals(ipAddressPoolWords[addPoolNo+1])){
									//System.out.println("ip pool: " + ipAddressPoolWords[addPoolNo+2]);
									String[] ipWords = ipAddressPoolWords[addPoolNo+2].split("/");
									for(int ipVNo = 0; ipVNo<ipWords.length; ipVNo++){
										String ipWord = ipWords[ipVNo+1];
										//System.out.println(inContextLineNo + " - ipValue 326: " + ipWords[ipVNo] + " / " + ipWords[ipVNo+1]);
										Integer ipValue = Integer.parseInt(ipWord);
										if(ipValue==30){
											pool_type = "static";
										}
										else{
											pool_type = "dynamic";
										}
										break;
									}
								}//End if NAME_IP, NAME_POOL
								
							}// End for - pool_type
							//break;
						}
						
						//	ri_name-pool - first condition and ri_name_pool - second condition 
						for(int q=inContextLineNo+2; q<endContextLineNo; q++){
							String[] riNamePoolWords = readedCFGLines.get(q).split(" ");
							for(int riPoolNo=0; riPoolNo < riNamePoolWords.length; riPoolNo++){
								String riNamePoolWord = riNamePoolWords[riPoolNo];
								//System.out.println("riNamePoolWords.length: " + riNamePoolWords.length);
								// ri_address_pool
								if(riNamePoolWords.length==5){
									if(riNamePoolWord.equals(NAME_IP) && NAME_POOL.equals(riNamePoolWords[riPoolNo+1])){
										ri_name_pool = inContextWords[inNo+1];
										ri_address_pool = riNamePoolWords[riPoolNo+2];
									}
								}
								else if(riNamePoolWords.length>5){
									if(riNamePoolWord.equals(NAME_IP) && NAME_POOL.equals(riNamePoolWords[riPoolNo+1])){
										if(NAME_NAME.equals(riNamePoolWords[riPoolNo+3])){
											ri_name_pool = riNamePoolWords[riPoolNo+4];// next word is ri_name_pool
										}
										ri_address_pool = riNamePoolWords[riPoolNo+2];
									}
								}
							}// End for riNamePoolWords.length
						}// End ri_name-pool for both conditions
					
					}// End if name_Interface, name_name_multibind.
				}
			}
		}
	}
	
//	Read Inside Context for adding the ILL_network_address
	public void ReadInContextILL_network_address(String contextName) {
		//ILL_network_address = null;
		Integer startContextLineNo = 0;
		Integer endContextLineNo = 0;
		// To find context start and end line no's.
		for (int currentLineNo = 1; currentLineNo <= readedCFGLines.size(); currentLineNo++) {
			String currentLine = readedCFGLines.get(currentLineNo);
			String[] currentLineWords = currentLine.split(" ");
			if(currentLineWords.length==2){
				for(int clNo=0; clNo< currentLineWords.length; clNo++){
					String currentWord = currentLineWords[clNo];
					if(currentWord.equals(context) && contextName.equals(currentLineWords[clNo+1])){
						startContextLineNo = currentLineNo;
						endContextLineNo = getNextContextLineNo(currentLineNo);
					}
				}
			}
		}// End For loop startContextLineNo, endContextLineNo no's
		
		//int interfaceCount = 0;// ILL_service using
		for(int inContextLineNo = startContextLineNo+1; inContextLineNo < endContextLineNo; inContextLineNo++){
			String[] inContextWords = readedCFGLines.get(inContextLineNo).split(" ");
			// ILL_network_address
			if(ILL_service){
			//if(inContextWords.length==4){
				for(int inNo=0; inNo<inContextWords.length; inNo++){
					String inContextWord = inContextWords[inNo];
					if(inContextWords.length==4){
						//String nextToNextString = inContextWords[inNo+2];
						if(inContextWord.equals(NAME_INTERFACE)){
							//String nextString = inContextWords[inNo+1];
							String nextToNextString = inContextWords[inNo+2];
							if(nextToNextString.contains(NAME_MULTIBIND)){
								//System.out.println("name_multibind: " + interfaceCount);
							}
							else if(nextToNextString.contains(NAME_LOOPBACK)){
								//System.out.println("name_loopback: " + interfaceCount);
							}
							else if(nextToNextString!=null){
								//System.out.println("328:- " + inContextLineNo );
								String[] illServiceAddressWords = readedCFGLines.get(inContextLineNo+2).split(" ");
								for(int illserAddNo=0; illserAddNo<illServiceAddressWords.length; illserAddNo++){
									if(NAME_IP.equals(illServiceAddressWords[illserAddNo]) && NAME_ADDRESS.equals(illServiceAddressWords[illserAddNo+1])){
										//System.out.println("service Address: " + illServiceAddressWords[illserAddNo+2]);
										ILL_network_address.add(illServiceAddressWords[illserAddNo+2]);
									}
								}
							}
						}// End if NAME_INTERFACE
					}// End if inContextWords.length==4
					
					if(inContextWords.length<4){
						//String nextToNextString = inContextWords[inNo+2];
						if(inContextWord.equals(NAME_INTERFACE)){
							String nextString = inContextWords[inNo+1];
							//System.out.println(inContextLineNo + " : " + inContextWords[inNo+1]);
							if(nextString.contains(NAME_UPLINK) ){
								//System.out.println("\n if 309== \n " + ILL_service + " : "+ interfaceCount);
							}
							else if(nextString!=null){
								//System.out.println("328:- " + inContextLineNo );
								String[] nextStringWords = readedCFGLines.get(inContextLineNo+2).split(" ");
								for(int nextStringNo=0; nextStringNo<nextStringWords.length; nextStringNo++){
									if(NAME_IP.equals(nextStringWords[nextStringNo]) && NAME_ADDRESS.equals(nextStringWords[nextStringNo+1])){
										//System.out.println("nextStringWords[nextStringNo+2]: " + nextStringWords[nextStringNo+2]);
										ILL_network_address.add(nextStringWords[nextStringNo+2]);
									}
								}
							}// End else if nextString!=null
						}// End if NAME_INTERFACE
					}// End if inContextWords.length<4
				}// End for loop inContextWords.length
			}// End if ILL_service == true
		}// End if ILL_network_address
		
	}// End ReadInContextILL_network_address()
	
	
// 	Read Over all file(CFG) for getting the values 
	public void ReadMapOverAll(String contextName){
		uplinkInterfaces = new ArrayList<UplinkInterface>();
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				if (mapword.equals(NAME_HOSTNAME)) {// Finding hostName, systemName logic
					String systemWord = mapOverWords[j - 1];
					if (systemWord.equals(NAME_SYSTEM)) {
						systemName = mapOverWords[j + 1]; 
					}
				}//End if - hostName, systemName
				// Finding Interfaces
				String uplink = "UPLINK-";
				String uplink0 = "UPLINK-0";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink0 + i;
							//With out wan
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplink_pvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												System.out.println("portWords: " + portWords[l + 1] + " : " + portWords[l + 2]);
												uplink_portValue = portWords[l + 1] + " " + portWords[l + 2];
												//System.out.println("uplink_portValue: " + uplink_portValue + " :contextName: " +contextName );
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
								if(uplinkInterface!=null){
									uplinkInterface.setUplink_portValue(uplink_portValue);
									uplinkInterface.setUplink_unit_no(uplink_pvcValue);
									uplinkInterface.setUplink_vlan_id(uplink_pvcValue);
								}
								else if(uplinkInterface==null){
									UplinkInterface upInterface = new UplinkInterface(finalUplink, uplink_portValue, uplink_pvcValue, uplink_pvcValue, "");
									uplinkInterfaces.add(upInterface);
								}
							}
						}	
						else{
							finalUplink = uplink + i;
							if(finalUplink.equals(mapOverWords[j-1])){
								for (int k = mapOverLineNo; k > 1; k--) {// Now we search reverse order searching
									String[] portWords = readedCFGLines.get(k).split(" ");
									for (int l = 0; l < portWords.length; l++) {
										String portWord = portWords[l];
										if (pvcCount < 1) {
											if (portWord.equals(NAME_PVC)) {
												uplink_pvcValue = portWords[l + 1];
												pvcCount++;
											}
										} // End pvcCount
										if (portCount < 1) {
											if (portWord.equals(NAME_PORT)) {
												uplink_portValue = portWords[l + 1] + " " + portWords[l + 2];
												portCount++;
											}
										} // End PortCount
									} // End portWords for loop
								} // End for loop
								pvcCount = 0;
								portCount = 0;
								UplinkInterface upInterface = new UplinkInterface(finalUplink, uplink_portValue, uplink_pvcValue, uplink_pvcValue, "");
								uplinkInterfaces.add(upInterface);
							}
						}
					}
				}
			}
		}
	}
	
//	Read wan_ip_address Values based on UPLINK value
	public void ReadMapForWanIpAddress(String contextName){
		for (int mapOverLineNo = 1; mapOverLineNo <= readedCFGLines.size(); mapOverLineNo++) {
			String[] mapOverWords = readedCFGLines.get(mapOverLineNo).split(" ");
			for (int j = 0; j < mapOverWords.length; j++) {
				String mapword = mapOverWords[j];
				String uplink = "UPLINK-";
				String uplink0 = "UPLINK-0";
				String finalUplink ="";
				if (mapword.equals(contextName)) { // Context Check
					for(int i = 1; i<=99; i++){
						if(i<10){
							finalUplink = uplink0 + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(context)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									//System.out.println("nextContextLineNo: " + nextContextLineNo);
									if(nextContextLineNo==null){
										nextContextLineNo = readedCFGLines.size();
									}
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplink_wanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplink_wanIpWords.length; wan++){
															uplink_wanIp = uplink_wanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplink_wanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplink_wanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End if
						else{
							finalUplink = uplink + i;
							String contextWord = mapOverWords[j-1];
							if(contextWord.equals(context)){
								if(mapOverWords.length==2){
									Integer nextContextLineNo = getNextContextLineNo(mapOverLineNo);
									for(int contextLineNo = mapOverLineNo+1; contextLineNo < nextContextLineNo; contextLineNo++){
										String[] interfaceIpWords = readedCFGLines.get(contextLineNo).split(" ");
										for(int pNo=0; pNo<interfaceIpWords.length; pNo++){
											String interfaceIpWord = interfaceIpWords[pNo];
											if(interfaceIpWord.equals(NAME_INTERFACE) && finalUplink.equals(interfaceIpWords[pNo+1]) ){
												String[] interfaceIpAddress = readedCFGLines.get(contextLineNo+2).split(" ");
												for(int ipAddNo=0; ipAddNo < interfaceIpAddress.length; ipAddNo++){
													if(NAME_IP.equals(interfaceIpAddress[ipAddNo]) && interfaceIpAddress[ipAddNo+1].equals(NAME_ADDRESS)){
														// uplink_wanIp : 172.22.163.41/30 to remove '/' after
														String[] uplink_wanIpWords = interfaceIpAddress[ipAddNo+2].split("/");
														for(int wan=0; wan<uplink_wanIpWords.length; wan++){
															uplink_wanIp = uplink_wanIpWords[0];
														}
														UplinkInterface uplinkInterface = getUplinkInterface(finalUplink);
														if(uplinkInterface!=null){
															uplinkInterface.setWan_ip_address(uplink_wanIp);
														}
														else if(uplinkInterface==null){
															UplinkInterface upInterface = new UplinkInterface(finalUplink, "", "", "", uplink_wanIp);
															uplinkInterfaces.add(upInterface);
														}
													}
												}
											}
										}
									}
								}
							}
						}// End else
					}// End for up to 99 uplinks
				}// End if - contextName 
			}
		}
	}
	
//	Next Context start No Return
	public Integer getNextContextLineNo(Integer currentLineNo){
		Integer nextLineNo;
		try{
			nextLineNo = contextsWithLineNo.higherEntry(currentLineNo).getKey();
		}catch(NullPointerException npe){
			nextLineNo = 0;
		}catch (Exception exception) {
			nextLineNo = 0;
		}
		return nextLineNo;
	}
	
//	LoopBack Details get from properties file for loopBack value
	public String getLoopBackDetails(String contextName){
		Properties properties = new Properties();
		InputStream input = null;
		try {
			String filename = "LoopBack.properties";
    		input = ReadCfgWriteJsonDynamically.class.getClassLoader().getResourceAsStream(filename);
			properties.load(input);
			loopBack = properties.getProperty(contextName);
			if(loopBack==null){
				loopBack="";
			}
		}catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return loopBack;
	}
	
//	Interface Details get from properties file for interface value added it into list "interfacePropertiesMap"
	private Map<String, String> interfacePropertiesMap = null;
	public boolean ReadInterfacePropertiesFile(String interfaceFilePath){
		System.out.println("ReadInterfacePropertiesFile(): " + interfaceFilePath);
		interfacePropertiesMap = new HashMap<String, String>();
		String propertiesFile = interfaceFilePath.substring(interfaceFilePath.lastIndexOf(".")+1);
		//System.out.println("propertiesFile: " + propertiesFile);
		if(!propertiesFile.equals("properties")){
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Please Provide Exact " + "\"." + "properties File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
		}
		else{
			Properties properties = new Properties();
			InputStream input = null;
			try {
				//String filename = "interfaceFilePath";
	    		input = new FileInputStream(interfaceFilePath);
				properties.load(input);
				//System.out.println("filename: " + filename);
				
				Enumeration<?> e = properties.propertyNames();
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					String value = properties.getProperty(key);
					interfacePropertiesMap.put(key, value);
					//System.out.println("Key : " + key + ", Value : " + value);
				}
				if(interfacePropertiesMap.size()!=0){
					readProperties = true;
				}else{
					System.out.println();
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.out.println("Given Propertie file Not Containing any Mapping Details/NoData ...!");
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.exit(1);
				}
			}catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						System.out.println();
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
						System.out.println("Please Provide Exact " + "\"." + "properties File Name&Location...! ");
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
					}
				}
			}
		}
		return readProperties;
	}
	
	// Interface Properties 
	private String ethernetPort = null;
	public String getInterfaceDetails(String ethernetValue){
		//ethernetPort = null;
		System.out.println("interfacePropertiesMap.size(): " + interfacePropertiesMap.size());
		String tempEthernet = ethernetValue;
		String newEthernet = tempEthernet.replace(" ", "_");
		//System.out.println("interfacePropertiesMap.get(newEthernet): " + interfacePropertiesMap.get(newEthernet));
		ethernetPort = interfacePropertiesMap.get(newEthernet);
		
		if(ethernetPort==null){
			ethernetPort="";
		}
		//System.out.println("\n getInterfaceDetails: " + ethernetPort);
		return ethernetPort;
	}
	
//	Read All Service values from Service.properties file for service value
	private Properties serviceProperties = null;
	public Properties getServiceDetails(){
		serviceProperties = new Properties();
		InputStream serviceInput = null;
		try {
			serviceInput = ReadCfgWriteJsonDynamically.class.getClassLoader().getResourceAsStream("Service.properties");
			serviceProperties.load(serviceInput);
		}catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (serviceInput != null) {
				try {
					serviceInput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return serviceProperties;
	}
	
//	Read All Context values from Context.properties file for Context value
	private Properties contextProperties = null;
	public Properties getContextDetails(){
		contextProperties = new Properties();
		InputStream contextInput = null;
		try {
			contextInput = ReadCfgWriteJsonDynamically.class.getClassLoader().getResourceAsStream("Context.properties");
			contextProperties.load(contextInput);
		}catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (contextInput != null) {
				try {
					contextInput.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return contextProperties;
	}

//	Clean all variables
	public void resetVariables(){
		systemName = "";
		serviceId = "";
		ri_name = "";
		customer = "";
		uplink_pvcValue = "";
		uplink_portValue = "";
		uplink_wanIp = "";
		portCount = 0;
		pvcCount = 0;
		loopBack = "";
		add_pool = false;
		pool_type = "";
		ri_name_pool="";
		ri_address_pool="";
		ri_address_pool_first_ip = "";
		ri_address_pool_low = "";
		ri_address_pool_high = "";
		//ri_address_pool_range_name = "";// same as ri_name_pool 
		primary_dns_server = "";
		secondary_dns_server = "";
		nsentries = false;
		domain="";
		virus_dns_fw_filter = false;
		bng_as_no = "";
		neighbor_as_no = "";
		pim = false;
		rp_address = "";
		ILL_service = false;
		neighbor_ip_address = new ArrayList<String>();
		ILL_network_address = new ArrayList<String>();
	}
	
// 	Main InvokesMethods Starts
	private boolean readCFgTxt = false;
	private boolean readProperties = false;
	private String outputFilePath = null;
	public void mainInvokesMethods() {
		//ReadCfgWriteJsonDynamically readCfgWriteJsonDynamically = new ReadCfgWriteJsonDynamically();
		System.out.println("Provide CFG/TXT/LOG File Path Location : ");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
	    String cfgFilePath = scanner.next();
	    System.out.println("Given CFG/TXT/LOG FilePath : " + cfgFilePath);
	    readCFgTxt = ReadCFGLines(cfgFilePath);
	    if(readCFgTxt){
	    	//System.out.println("if readCFgTxt: " + readCFgTxt);
		    System.out.println();
		    System.out.println("Provide Interface Properties File Path Location : ");
			@SuppressWarnings("resource")
			Scanner interfaceScanner = new Scanner(System.in);
		    String interfaceFilePath = interfaceScanner.next();
		    System.out.println("Given Interface Properties FilePath : " + interfaceFilePath);
		    
		    readProperties = ReadInterfacePropertiesFile(interfaceFilePath);
		    System.out.println("interfacePropertiesMap: " + interfacePropertiesMap);
		    if(readProperties){
		    	// now read output path location
		    	System.out.println();
			    System.out.println("Provide Output Path Location : ");
				@SuppressWarnings("resource")
				Scanner outputScanner = new Scanner(System.in);
			    outputFilePath = outputScanner.next();
			    System.out.println("Given OutPut Path Location : " + outputFilePath);
		    	
			    //System.out.println("interfacePropertiesMap: " + interfacePropertiesMap);
				//ReadContextsInFile();// Read Contexts from context file then enable
				ReadMapToGetContextLineNo();
				
				// Read Services
				
				serviceProperties = null;
				serviceProperties = getServiceDetails();
				//System.out.println("Service properties: " + serviceProperties.size());
				Set<Entry<Object, Object>> serviceEntries = serviceProperties.entrySet();
				//System.out.println(" serviceEntries: " + serviceEntries.size());
				for (Entry<Object, Object> serviceEntry : serviceEntries) {
					//System.out.println(service.getKey() + " : " + service.getValue());
					service = (String) serviceEntry.getValue();// As of now Fix
					// Read Services
					contextProperties = null;
					contextProperties = getContextDetails();
					Set<Entry<Object, Object>> contextEntries = contextProperties.entrySet();
					//System.out.println("Context Size(): " + contextEntries.size());
					for (Entry<Object, Object> contextEntry : contextEntries) {
						//System.out.println("Service value: " + service + "  :ContextEntry Value:  " + contextEntry.getValue().toString());	
						if(service.equals(contextEntry.getValue().toString())){
							//
							String contextName = contextEntry.getKey().toString();
							//System.out.println("921 contextName: "  +contextName + " Map: " + contextsWithLineNo.size());
							for(Map.Entry<Integer, String> e: contextsWithLineNo.entrySet()){
								String con = e.getValue();
							
							if(con.equals(contextName)){
								//System.out.println("ContextName:593:  " + contextName);
								ri_name = contextName;// Context Name
								customer = contextName;// Context Name
								ReadMapOverAll(contextName);
								ReadMapForWanIpAddress(contextName);
								getLoopBackDetails(contextName);
								ReadMapWithInContext(contextName);
							
								//ILL_network_address
								if(ILL_service){
									ReadInContextILL_network_address(contextName);
								}
								
								//ri_address_pool_low, high, first values
								if(ri_address_pool!="" && ri_address_pool!=null){
									SubnetIpAddressUtils subnetIpAddress = new SubnetIpAddressUtils(ri_address_pool);
									String subnet[] = subnetIpAddress.getInfo().getLowAddress().toString().split("\\/");
									String subnetValue = "";
									for(int sub=0; sub<subnet.length; sub++){
										subnetValue = subnet[0];
									}
									
									String low[] = subnetValue.split("\\.");
									int lowValue = Integer.parseInt(low[low.length-1]);
									ri_address_pool_first_ip = subnetIpAddress.getInfo().getLowAddress();
									
									String subLow = ri_address_pool_first_ip.substring(0, ri_address_pool_first_ip.lastIndexOf('.'));
									
									ri_address_pool_low = subLow+"."+(lowValue+1);
									
									ri_address_pool_high = subnetIpAddress.getInfo().getHighAddress();
								}
								
								// JSON Method call
								CreateJsonFormat();
								}
							}
						}// End If service Value
						
						//Re-set values
						resetVariables();
						
				    }// End for contextEntries
				//Service null
				service = "";
				}// End for serviceEntries
				
		    }// End if readProperties
		    
	    }// End if readCfgTxt
	}// Main Method Ends
	
	
/*	------------------------------------------------	*/
	
	public static void main(String[] args) {
		ReadCfgWriteJsonDynamically readCfgWriteJsonDynamically = new ReadCfgWriteJsonDynamically();
		//System.out.println("Main Method: ");
		readCfgWriteJsonDynamically.mainInvokesMethods();
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("Successfully Json files Generated ...! ");
		System.out.println("---------- ---------- ---------- ---------- ");
		System.out.println("!...	Thank You	...! ");
	}
	
/*	------------------------------------------------	*/
//	JSON object creation starts
	public UplinkInterface getUplinkInterface(String searchUplink){
		UplinkInterface searchedUplinkInterface = null;
		for(UplinkInterface uplink: uplinkInterfaces){
			if(searchUplink.equals(uplink.getUplink_interface())){
				searchedUplinkInterface = uplink;
			}
		}
		return searchedUplinkInterface;
	}
	
// 	For JSON Declarations 
	JsonObjectBuilder systemBuilder = Json.createObjectBuilder();
	JsonArrayBuilder uplinkInterfaceBuilder = Json.createArrayBuilder();
	
// 	JSON creation Method
	public void CreateJsonFormat(){
		//System.out.println("Service : " + service);
		systemBuilder.add("service", service);
		systemBuilder.add("ri_name", ri_name);
		systemBuilder.add("device", systemName);
		// serviceId - 5 digits

		if(loopBack!=""){
			if(loopBack.length()==1){
				serviceId = "0000"+loopBack;
			}
			else if(loopBack.length()==2){
				serviceId = "000"+loopBack;
			}
			else if(loopBack.length()==3){
				serviceId = "00"+loopBack;
			}
		}
		systemBuilder.add("serviceId", serviceId);
		systemBuilder.add("customer", customer);
		systemBuilder.add("lo_unit_no", loopBack);
		// Interface values for dynamically based on UPLINK value
		int u = 0;
		String uplink = "UPLINK-";
		String uplink0 = "UPLINK-0";
		for(int i = 1; i<=uplinkInterfaces.size(); i++){
			JsonObjectBuilder uplinkBuilder = Json.createObjectBuilder();
			if(i<10){
				UplinkInterface uplinkInterface = getUplinkInterface(uplink0 + i);
				String uplink_interface = "uplink_interface"+"_"+u;
				String uplink_unit_no = "uplink_unit_no"+"_"+u;
				String uplink_vlan_id = "uplink_vlan_id"+"_"+u;
				String wan_ip_address = "wan_ip_address"+"_"+u;
				
				//getInterfaceDetails
				String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
				System.out.println("portValue:if<10; " + portValue + " : " + ethernetPort);
				if(portValue!=null && portValue!=""){
					uplinkBuilder.add(uplink_interface, ethernetPort);
				}else{
					uplinkBuilder.add(uplink_interface, uplinkInterface.getUplink_portValue());
				}
				uplinkBuilder.add(uplink_unit_no, uplinkInterface.getUplink_unit_no());
				uplinkBuilder.add(uplink_vlan_id, uplinkInterface.getUplink_vlan_id());
				uplinkBuilder.add(wan_ip_address, uplinkInterface.getWan_ip_address());
				uplinkInterfaceBuilder.add(uplinkBuilder);
				u++;
			}
			else{
				UplinkInterface uplinkInterface = getUplinkInterface(uplink + i);
				String uplink_interface = "uplink_interface"+"_"+u;
				String uplink_unit_no = "uplink_unit_no"+"_"+u;
				String uplink_vlan_id = "uplink_vlan_id"+"_"+u;
				String wan_ip_address = "wan_ip_address"+"_"+u;
				
				//getInterfaceDetails
				String portValue = getInterfaceDetails(uplinkInterface.getUplink_portValue());
				System.out.println("portValue:else; " + portValue + " : " + ethernetPort);
				if(portValue!=null && portValue!=""){
					uplinkBuilder.add(uplink_interface, ethernetPort);
				}else{
					uplinkBuilder.add(uplink_interface, uplinkInterface.getUplink_portValue());
				}
				uplinkBuilder.add(uplink_unit_no, uplinkInterface.getUplink_unit_no());
				uplinkBuilder.add(uplink_vlan_id, uplinkInterface.getUplink_vlan_id());
				uplinkBuilder.add(wan_ip_address, uplinkInterface.getWan_ip_address());
				uplinkInterfaceBuilder.add(uplinkBuilder);
				u++;
			}
		}
		systemBuilder.add("interfaces", uplinkInterfaceBuilder);
		//
		systemBuilder.add("add_pool", Boolean.toString(add_pool));
		systemBuilder.add("pool_type", pool_type);
		systemBuilder.add("ri_name-pool", ri_name_pool);
		systemBuilder.add("ri_address_pool", ri_address_pool);
		
		systemBuilder.add("ri_address_pool_first_ip", ri_address_pool_first_ip);
		if(pool_type!="static"){
			systemBuilder.add("ri_address_pool_low", ri_address_pool_low);
			systemBuilder.add("ri_address_pool_high", ri_address_pool_high);
		}
		systemBuilder.add("ri_address_pool_range_name", ri_name_pool);// same as ri_name_pool
		// nsentries
		nsentries = false;
		if(primary_dns_server != "" && secondary_dns_server !=""){
			nsentries = true;
		}else{
			primary_dns_server = "10.1.1.1";
			secondary_dns_server = "10.1.1.1";
		}
		systemBuilder.add("nsentries", Boolean.toString(nsentries));
		systemBuilder.add("primary_dns_server", primary_dns_server);
		systemBuilder.add("secondary_dns_server", secondary_dns_server);
		// domain
		JsonArrayBuilder dominArrayBuilder = Json.createArrayBuilder();
		dominArrayBuilder.add(customer);// ContextName we need to show
		dominArrayBuilder.add(domain);
		systemBuilder.add(NAME_DOMAIN, dominArrayBuilder);
		
		// neighbor_ip_address
		JsonArrayBuilder neighborArrayBuilder = Json.createArrayBuilder();
		for(String neighborIP: neighbor_ip_address){
			neighborArrayBuilder.add(neighborIP);
		}
		systemBuilder.add("neighbor_ip_address", neighborArrayBuilder);
		// virus_dns_fw_filter
		systemBuilder.add("virus_dns_fw_filter", Boolean.toString(virus_dns_fw_filter));
		//bng_as_no
		systemBuilder.add("bng_as_no", bng_as_no);
		//neighbor_as_no
		systemBuilder.add("neighbor_as_no", neighbor_as_no);
		// pim
		systemBuilder.add("pim", Boolean.toString(pim));
		//rp_address
		systemBuilder.add("rp_address", rp_address);
		// ILL_service // ILL_network_address
		JsonArrayBuilder illArrayBuilder = Json.createArrayBuilder();
		if(ILL_network_address!=null && ILL_network_address.size()>0){
			for(String s: ILL_network_address){
				illArrayBuilder.add(s);
			}
		}
		systemBuilder.add("ILL_service", Boolean.toString(ILL_service));
		systemBuilder.add("ILL_network_address", illArrayBuilder);
		// json object
		JsonObject jsonObject = systemBuilder.build();
		System.out.println("JSON Object-" + ri_name + " : "+ jsonObject);
		//write to file
		Date date = new Date();
        //System.out.println("Today Date: " + sdf.format(date));
	    String todayDate =  sdf.format(date);
	    //System.out.println("outputFilePath: " + outputFilePath); 
	    String outputPath = outputFilePath+"\\"+todayDate+"_Uplink"+"\\"+systemName;
	    File f = new File(outputPath);
		f.mkdirs();
		//System.out.println("systemName Output path: " + outputPath);
		OutputStream os = null;
		try {
			os = new FileOutputStream(outputPath+"\\"+systemName+"_"+ri_name+".json"); // Hard Code file path
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			System.out.println("---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Something went worng, JSON file not genarated...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ");
		}
		JsonWriter jsonWriter = Json.createWriter(os);
		jsonWriter.writeObject(jsonObject);
		jsonWriter.close();
	}// End CreateJsonFormat()

	
	
}// End Class ReadCfgWriteJsonDynamically
