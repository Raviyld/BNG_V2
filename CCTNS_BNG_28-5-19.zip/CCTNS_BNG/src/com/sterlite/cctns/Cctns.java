/**
 * 
 */
package com.sterlite.cctns;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * @author ravi.divvela
 *
 */
public class Cctns {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Cctns cctns = new Cctns();
		
		cctns.ReadCurrentDirectory();
		cctns.ReadMultipleFiles();
		cctns.WriteData();
//		cctns.inputFiles.delete();
		
		System.out.println("Given Intput path: " + cctns.inputFolderPath);
		System.out.println("Given Output path: " + cctns.outputFolderPath);
		System.out.println("Given Final path: " + cctns.sourceFolderPath);
		System.out.println("---------- ---------- ---------- ");
		System.out.println("!...	Successfully Completed	...! ");
		System.out.println("---------- ---------- ---------- ");
		System.out.println("!...	Thank You	...! ");
	}//End Main

//	Read current directory
	public void ReadCurrentDirectory(){
		String workingDir = System.getProperty("user.dir");
		//System.out.println("Current working directory : " + workingDir);
		
		File workingFiles = new File(workingDir);
		File[] listWorkingFiles = workingFiles.listFiles();
		//System.out.println("listWorkingFiles: " + listWorkingFiles.length);
		
		for(File file: listWorkingFiles){
			//System.out.println("File working: " + file);
			if (file.isFile()&&(file.getName().substring(file.getName().lastIndexOf('.')+1).equals("properties"))) {
				String inputPropertiePath = file.toString();
				//System.out.println("FileName : " + inputPropertiePath);
				ReadInputPropertieFile(inputPropertiePath);
				//dotProperties = true;
				break;
			}//End if
		}//End for
	}//End ReadCurrentDirectory
	
//	Read input properties file for current directory
	private Map<String, String> inputPathPropertieMap = new HashMap<String, String>();
	public void ReadInputPropertieFile(String inputPropertiePath){
		//System.out.println("inputPropertiePath: " + inputPropertiePath);
		String propertieFile = inputPropertiePath.substring(inputPropertiePath.lastIndexOf(".")+1);
		//System.out.println("propertiesFile: " + propertieFile);
		if(!propertieFile.equals("properties")){
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Please Provide Exact " + "\"." + "properties\" File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ");
			System.exit(1);
		}
		else{
			Properties properties = new Properties();
			InputStream inputStream = null;
			try {
	    		inputStream = new FileInputStream(inputPropertiePath);
				properties.load(inputStream);
				//System.out.println("input: " + input);
				Enumeration<?> e = properties.propertyNames();
				while (e.hasMoreElements()) {
					String key = (String) e.nextElement();
					String value = properties.getProperty(key);
					inputPathPropertieMap.put(key, value);
					//System.out.println("Key : " + key + ", Value : " + value);
				}
				if(inputPathPropertieMap.size()!=0){
					//System.out.println("map Size: " + inputPathPropertieMap.size());
					//readProperties = true;
				}else{
					System.out.println();
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.out.println("Given Propertie file Not Containing any Details/NoData ...!");
					System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
					System.exit(1);
				}
			}catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (inputStream != null) {
					try {
						inputStream.close();
					} catch (IOException e) {
						System.out.println();
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.out.println("No Such Propertie File In That Location, Please Provide Exact File in that Location..!");
						System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ----------");
						System.exit(1);
					}// End Catch
				}// End if input!=null
			}// End finally
		}// End else
	}// End ReadInputPropertieFile
	
//	Get Properties values
	public String getPropertyName(String Sterlite_BasePropertyKey){
		//System.out.println("getPropertyName() Sterlite_HostName: " + Sterlite_HostName);
		String returnValue = null;
		if(inputPathPropertieMap.containsKey(Sterlite_BasePropertyKey)){
			//System.out.println("Property Value: " + hostNamePropertiesMap.get(Sterlite_HostName));
			returnValue = inputPathPropertieMap.get(Sterlite_BasePropertyKey);
		}
		return returnValue;
	}// End getPropertyName
		
	
	
//	Variables 
	private String inputFolderPath;// = "D://BSNL-BNG-PHASE-2//Input//CCTNS//";
	private String outputFolderPath;// = "D://BSNL-BNG-PHASE-2//Input//";
	private String sourceFolderPath;// = "D://BSNL-BNG-PHASE-2//Input//";
	
	private List<String> usersList = new ArrayList<String>();
	public List<String> getUsersList() {
		return usersList;
	}
	public void setUsersList(List<String> usersList) {
		this.usersList = usersList;
	}
	
//	Read Multiple files in a particular folder, and stores the users data into usersList 
	File inputFiles;
	public void ReadMultipleFiles(){
		inputFolderPath = getPropertyName("inputPath");
		
		inputFiles = new File(inputFolderPath);
		File[] listOfInputFiles = inputFiles.listFiles();
		//System.out.println("listOfInputFiles: " + listOfInputFiles.length);
		if(listOfInputFiles.length==0){
			System.out.println("---------- ---------- ---------- ---------- ---------- ");
			System.out.println("Input Folder not contains any files, please provide...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ");
			System.exit(1);
		}
		for (File file : listOfInputFiles) {
			if (file.isFile()&&(file.getName().substring(file.getName().lastIndexOf('.')+1).equals("txt"))) {
				//String fileName = file.getName().substring(0, file.getName().lastIndexOf('.'));
				//System.out.println("fileName: " + fileName);
				//usersList.add(fileName);
				//usersList.add("USER,START_TIME");
				//Read Single file data, and stores the users data into usersList 
				ReadCctnsLines(file.toString());
				//usersList.add("");
			}
			else{
				System.out.println("---------- ---------- ---------- ---------- ---------- ----------");
				System.out.println("Input Folder Contain Other Files(Only .txt Needed), Try Again...! ");
				System.out.println("---------- ---------- ---------- ---------- ---------- ----------");
				System.exit(1);
			}
		}// End for loop listOfInputFiles
	}// End ReadMultipleFiles()
	
//	Read File and added into map and added into userList
	private Map<Integer, String> readedCctnsLines = new HashMap<Integer, String>();
	public void ReadCctnsLines(String cctnsFilePath){
		try {
			List<String> allLines = Files.readAllLines(Paths.get(cctnsFilePath));
			int lineNo = 0;
			for (String line : allLines) {
				lineNo++;
				readedCctnsLines.put(lineNo, line); // Adding each line by line in to map(key is line no, value is line)
			}
			//Read file data 
			for(int i=1; i<=readedCctnsLines.size(); i++){
				//CurrentLine Space removing 
				String currentLine = readedCctnsLines.get(i).trim().replaceAll("\\s+", " ");;
				//System.out.println("currentLine: " + currentLine);
				
				//users added into usersList
				if(!currentLine.isEmpty()){
					String[] currentLineWords = currentLine.split(" ");
					if(!currentLineWords[0].contains("root"))
						usersList.add(currentLineWords[0]);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("---------- ---------- ---------- ---------- ");
			System.out.println("Please Provide Exact File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ----------");
		}
	}//End ReadCctnsLines()
	
// 	Write Data into csv/text file
	private static final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH_mm_ss");//yyyy/MM/dd HH:mm:ss
	@SuppressWarnings("deprecation")
	public void WriteData(){
		//Date logic
		
		Date date = Calendar.getInstance().getTime();
		int iHours = (Integer)date.getHours();
		String todayDateTime =  sdf.format(date);
	    String[] dateSplit = todayDateTime.split(" ");
	    String currentDate = dateSplit[0];
	    String currentTime = dateSplit[1];
	    //System.out.println("currentDate: " + currentDate + " \t currentTime: " + currentTime);
	    
	    //output file
	    FileWriter fr = null;
        BufferedWriter br = null;
        
        outputFolderPath = getPropertyName("outputPath");
        
		File outPutFolder = new File(outputFolderPath + "//" +currentDate);
		outPutFolder.mkdirs();
        try {
        	if(iHours == 00)
        		fr = new FileWriter(outPutFolder + "//cctns_subs2.txt");
        	else
        		fr = new FileWriter(outPutFolder + "//cctns_subs2.txt", true);
        	br = new BufferedWriter(fr);
        	for(String user: usersList){
    			//System.out.println("Users: "+ user);
    			try {
    				br.write(user);
    				br.write(System.getProperty("line.separator"));
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
    		}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				//br.write(System.getProperty("line.separator"));
                br.close();
                fr.close();
                // folder copy
                
                sourceFolderPath = getPropertyName("sourcePath");
                File sourcePutFolder = new File(sourceFolderPath + "//" +currentDate + "//" + currentTime + "//");
                sourcePutFolder.mkdirs();
                //sourcePutFolder = sourcePutFolder + "Final_" + currentDate + "_" + currentTime + "//";
                //finalFolderPath = finalFolderPath + currentDate + "//" + currentTime + "//";
                //System.out.println("sourcePutFolder: " + sourcePutFolder);
                copyFolder(inputFiles, sourcePutFolder);
                
            } catch (IOException e) {
                e.printStackTrace();
            }
		}//End finally
	}//End WriteData()
	
	
//	Copy folder to another location
	public void copyFolder(File src, File dest)throws IOException{
    	if(src.isDirectory()){
    		//if directory not exists, create it
    		if(!dest.exists()){
    		   dest.mkdir();
    		   System.out.println("dest: " + dest);
    		   System.out.println("Directory copied from " + src + "  to " + dest);
    		}
    		//list all the directory contents
    		String files[] = src.list();
    		for (String file : files) {
    		   //construct the src and dest file structure
    		   File srcFile = new File(src, file);
    		   File destFile = new File(dest, file);
    		   
    		   
    		   //recursive copy
    		   copyFolder(srcFile,destFile);
    		   //After file copy, delete the source location
    		   srcFile.delete();
    		}
    	}// if
    	else{
    		//if file, then copy it
    		//Use bytes stream to support all file types
    		//System.out.println("copyFolder else block ");
    		InputStream in = new FileInputStream(src);
	        OutputStream out = new FileOutputStream(dest); 
	        byte[] buffer = new byte[1024];
	        int length;
	        //copy the file content in bytes 
	        while ((length = in.read(buffer)) > 0){
	    	   out.write(buffer, 0, length);
	        }
	        in.close();
	        out.close();
	        //System.out.println("File copied from " + src + " to " + dest);
    	}
    }//End copyFolder()
	
	
	
}//	End Class
